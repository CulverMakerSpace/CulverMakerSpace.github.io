"""Local JSON-lines TCP bridge: Godot draws, Python remains physics authority.

Start: python godot_bridge.py
Then run godot/project.godot from Godot 4. No network service or cloud required.
"""
import asyncio
import json
import time
from types import SimpleNamespace

import settings
from simulation import Simulation
from controls import change_rudder, change_stroke_rate, handle_keyboard_event

HOST = "127.0.0.1"
PORT = 28542
PHYSICS_STEP = 1.0 / 60.0
STATE_SEND_PERIOD = 1.0 / 30.0
MAX_CATCH_UP_SECONDS = 0.25
IDLE_SLEEP = 0.003


def advance_fixed_steps(simulation, elapsed, remainder):
    """Advance physics by measured real time, using fixed 60 Hz steps.

    Keep an unfinished fraction for the next update. A large scheduling pause
    is capped to avoid an unbounded catch-up loop after window suspension.
    """
    remainder += min(max(elapsed, 0.0), MAX_CATCH_UP_SECONDS)
    steps = int((remainder + 1e-10) / PHYSICS_STEP)
    for _ in range(steps):
        simulation.step(PHYSICS_STEP)
    remainder -= steps * PHYSICS_STEP
    return max(0.0, remainder)


def course_geometry(course_id="max"):
    import course
    lake = course.COURSES[course_id]
    from importlib import import_module
    lake = import_module(lake)
    return {
        "type": "course",
        "name": getattr(lake, "COURSE_NAME", {"max": "Lake Maxinkuckee", "charles": "Head of the Charles", "nathan": "Nathan Benderson Park", "milwaukee": "Milwaukee River"}[course_id]),
        "course_id": course_id,
        "setting": "urban" if course_id in ("charles", "milwaukee") else "park",
        "bridges": getattr(lake, "BRIDGE_PATHS", []),
        "shoreline": lake.LAKE_SHORELINE,
        "docks": lake.DOCK_PATHS,
        "hull_length_m": settings.SHELL_LENGTH,
        "hull_width_m": settings.SHELL_WIDTH,
        "geometric_center_m": settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS,
        "seat_offset_m": settings.ROWER_SEAT_FORWARD_OFFSET,
        "oar_span_m": settings.OAR_SPAN,
        "oar_outboard_m": settings.OAR_OUTBOARD,
        "oar_blade_length_m": settings.OAR_BLADE_GRAPHICS_LENGTH,
        "oar_max_sweep_deg": settings.OAR_DISPLAY_MAX_SWEEP_ANGLE,
        "oar_coast_sweep_deg": settings.OAR_COAST_SWEEP_ANGLE,
        "oar_raised_reach_m": settings.OAR_RAISED_REACH,
        "drive_fraction": settings.DRIVE_FRACTION,
        "rower_names": {str(k): v for k, v in settings.ROWER_DISPLAY_NAMES.items()},
        "cox_position_m": settings.COXSWAIN_POSITION,
        "seat_positions": {str(seat): section["position"] for section in settings.ROWER_SECTIONS for seat in section["rowers"]},
    }


def interpret_key(control_state, name):
    """Pass Godot key commands through exactly the same keyboard handler as Pygame."""
    from controls import pygame
    aliases = {
        "SHIFT": "K_LSHIFT", "CTRL": "K_LCTRL", "ALT": "K_LALT",
        "BACKTICK": "K_BACKQUOTE", "TAB": "K_TAB", "SPACE": "K_SPACE",
        "ENTER": "K_RETURN", "UP": "K_UP", "DOWN": "K_DOWN",
        "LEFT": "K_LEFT", "RIGHT": "K_RIGHT",
    }
    constant_name = aliases.get(name.upper(), "K_" + name.lower())
    key = getattr(pygame, constant_name, None)
    if key is None:
        return
    handle_keyboard_event(control_state, SimpleNamespace(type=pygame.KEYDOWN, key=key))


async def serve_client(reader, writer):
    simulation = Simulation("max")
    selected = False
    writer.write((json.dumps({"type": "course_list", "courses": {"max": "Lake Maxinkuckee", "charles": "Head of the Charles", "nathan": "Nathan Benderson Park", "milwaukee": "Milwaukee River"}}) + "\n").encode())
    await writer.drain()
    print("Godot connected (127.0.0.1)")

    async def read_keys():
        nonlocal selected
        while not reader.at_eof():
            raw = await reader.readline()
            if not raw:
                break
            try:
                message = json.loads(raw)
                if selected and message.get("type") == "key" and isinstance(message.get("key"), str):
                    interpret_key(simulation.controls, message["key"])
                elif message.get("type") == "reset" and selected:
                    simulation.reset()
                elif message.get("type") == "select_course":
                    course_id = message.get("course_id")
                    if course_id in ("max", "charles", "nathan", "milwaukee"):
                        simulation.load_course(course_id)
                        selected = True
                        writer.write((json.dumps(course_geometry(course_id)) + "\n").encode())
                        await writer.drain()
            except (ValueError, TypeError) as error:
                print("Ignored invalid command:", error)

    input_task = asyncio.create_task(read_keys())
    last_update_time = time.perf_counter()
    last_send_time = last_update_time - STATE_SEND_PERIOD
    physics_remainder = 0.0

    try:
        while not writer.is_closing() and not input_task.done():
            now = time.perf_counter()
            elapsed = now - last_update_time
            last_update_time = now
            if selected:
                physics_remainder = advance_fixed_steps(simulation, elapsed, physics_remainder)
            else:
                physics_remainder = 0.0

            # Godot needs visual snapshots, not every single physics step.
            # Sending fewer packets also reduces work and scheduling delay.
            if selected and now - last_send_time >= STATE_SEND_PERIOD:
                state = simulation.snapshot()
                state["type"] = "state"
                state["trail"] = state["trail"][-2000:]
                writer.write((json.dumps(state, separators=(",", ":")) + "\n").encode())
                await writer.drain()
                last_send_time = now

            await asyncio.sleep(IDLE_SLEEP)
    except (ConnectionError, BrokenPipeError):
        pass
    finally:
        input_task.cancel()
        writer.close()
        try:
            await writer.wait_closed()
        except ConnectionError:
            pass
        print("Godot disconnected")


async def main():
    server = await asyncio.start_server(serve_client, HOST, PORT)
    print(f"Python simulation listening at {HOST}:{PORT}")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
