import math
import course
import settings

# =============================================================================
# ROWER SEAT POSITION
# =============================================================================

def get_rower_forward_position(seat):
    # Match the small fore/aft seat offset used by the boat graphics.
    for section in settings.ROWER_SECTIONS:
        if seat in section["rowers"]:
            if seat % 2 == 0:
                seat_offset = -settings.ROWER_SEAT_FORWARD_OFFSET
            else:
                seat_offset = settings.ROWER_SEAT_FORWARD_OFFSET
            return section["position"] + seat_offset
    raise ValueError(f"Seat {seat} is not part of the current boat configuration.")

# =============================================================================
# SIDE COLLISION ENVELOPE
# =============================================================================

def calculate_side_collision_envelope(seats, oar_position):
    # Find the rower positions that define the forward and aft oar envelope.
    seat_positions = []
    for seat in seats:
        if seat <= settings.NUMBER_OF_ROWERS:
            seat_positions.append(get_rower_forward_position(seat))
    forward_position = max(seat_positions)
    aft_position = min(seat_positions)

    # -------------------------------------------------------------------------
    # OARS DOWN
    # -------------------------------------------------------------------------

    # Use the full visual sweep envelope so the box does not move every stroke.
    if oar_position == "down":
        maximum_sweep = math.radians(settings.OAR_DISPLAY_MAX_SWEEP_ANGLE)
        sweep_forward_distance = (settings.OAR_OUTBOARD * math.sin(maximum_sweep))
        half_width = (settings.OAR_SPAN + settings.OAR_OUTBOARD + settings.BOAT_COLLISION_PADDING)
        forward_position += (sweep_forward_distance + settings.BOAT_COLLISION_PADDING)
        aft_position -= (sweep_forward_distance + settings.BOAT_COLLISION_PADDING)

    # -------------------------------------------------------------------------
    # OARS RAISED
    # -------------------------------------------------------------------------

    # Raised oars pass above the dock, so keep the boundary close to the hull.
    else:
        half_width = (settings.SHELL_WIDTH / 2) + settings.OAR_RAISED_COLLISION_CLEARANCE
        forward_position += settings.BOAT_COLLISION_PADDING
        aft_position -= settings.BOAT_COLLISION_PADDING
    return forward_position, aft_position, half_width

# =============================================================================
# BOAT COLLISION POLYGON
# =============================================================================

def create_boat_collision_local_points(oar_positions):
    # Build a fixed tapered envelope around the hull and current oar positions.
    geometric_center = settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS
    bow = (geometric_center + (settings.SHELL_LENGTH / 2) + settings.BOAT_COLLISION_PADDING)
    stern = (geometric_center - (settings.SHELL_LENGTH / 2) - settings.BOAT_COLLISION_PADDING)
    port_forward, port_aft, port_width = calculate_side_collision_envelope(settings.PORT_SEATS, oar_positions["port"])
    starboard_forward, starboard_aft, starboard_width = (
        calculate_side_collision_envelope(settings.STARBOARD_SEATS, oar_positions["starboard"]))
    collision_points = [
        (bow, 0.0),
        (port_forward, port_width),
        (port_aft, port_width),
        (stern, 0.0),
        (starboard_aft, -starboard_width),
        (starboard_forward, -starboard_width)]
    return collision_points

# =============================================================================
# BOAT COLLISION POLYGON - WORLD COORDINATES
# =============================================================================

def get_boat_collision_world_points(local_points, x, y, heading):
    # Rotate the fixed boat-space collision polygon into world coordinates.
    heading_cosine = math.cos(heading)
    heading_sine = math.sin(heading)
    world_points = []
    for forward, sideways in local_points:
        world_x = (x + (forward * heading_cosine) - (sideways * heading_sine))
        world_y = (y + (forward * heading_sine) + (sideways * heading_cosine))
        world_points.append((world_x, world_y))
    return world_points

# =============================================================================
# BOUNDING BOX HELPERS
# =============================================================================

def get_polygon_bounds(polygon):
    # Axis-aligned bounds provide a fast rejection test before detailed geometry.
    minimum_x = min(point[0] for point in polygon)
    maximum_x = max(point[0] for point in polygon)
    minimum_y = min(point[1] for point in polygon)
    maximum_y = max(point[1] for point in polygon)
    return minimum_x, maximum_x, minimum_y, maximum_y


def get_segment_bounds(start, end):
    minimum_x = min(start[0], end[0])
    maximum_x = max(start[0], end[0])
    minimum_y = min(start[1], end[1])
    maximum_y = max(start[1], end[1])
    return minimum_x, maximum_x, minimum_y, maximum_y


def bounds_overlap(first_bounds, second_bounds):
    first_min_x, first_max_x, first_min_y, first_max_y = first_bounds
    second_min_x, second_max_x, second_min_y, second_max_y = second_bounds
    separated_x = first_max_x < second_min_x or first_min_x > second_max_x
    separated_y = first_max_y < second_min_y or first_min_y > second_max_y
    return not (separated_x or separated_y)

# =============================================================================
# DOCK COLLISION POLYGONS
# =============================================================================

def create_rectangle_around_segment(start, end, width):
    # Convert one dock centerline segment into its visible rectangular footprint.
    start_x, start_y = start
    end_x, end_y = end
    direction_x = end_x - start_x
    direction_y = end_y - start_y
    segment_length = math.hypot(direction_x, direction_y)
    if segment_length <= settings.COLLISION_GEOMETRY_EPSILON:
        return None
    half_width = width / 2.0
    normal_x = (-direction_y / segment_length) * half_width
    normal_y = (direction_x / segment_length) * half_width
    rectangle = [
        (start_x + normal_x, start_y + normal_y),
        (end_x + normal_x, end_y + normal_y),
        (end_x - normal_x, end_y - normal_y),
        (start_x - normal_x, start_y - normal_y)]
    return rectangle


def create_square_around_point(point, width):
    # Match the square join used by the dock graphics at centerline bends.
    point_x, point_y = point
    half_width = width / 2.0
    square = [
        (point_x - half_width, point_y - half_width),
        (point_x + half_width, point_y - half_width),
        (point_x + half_width, point_y + half_width),
        (point_x - half_width, point_y + half_width)]
    return square


def create_dock_collision_polygons():
    # Build the same physical dock footprint that is drawn on screen.
    dock_polygons = []
    for dock_path in course.DOCK_PATHS:
        for index in range(len(dock_path) - 1):
            segment_start = dock_path[index]
            segment_end = dock_path[index + 1]
            rectangle = create_rectangle_around_segment(segment_start, segment_end, settings.DOCK_DISPLAY_WIDTH)
            if rectangle is not None:
                dock_polygons.append(rectangle)
        for point in dock_path[1:-1]:
            square = create_square_around_point(point, settings.DOCK_DISPLAY_WIDTH)
            dock_polygons.append(square)
    return dock_polygons
DOCK_COLLISION_POLYGONS = create_dock_collision_polygons()
DOCK_COLLISION_BOUNDS = [
    get_polygon_bounds(polygon)
    for polygon in DOCK_COLLISION_POLYGONS]

# =============================================================================
# SHORELINE COLLISION SEGMENTS
# =============================================================================

# Store each shoreline edge with its bounds so only nearby edges need detailed
# intersection tests each frame.
SHORELINE_SEGMENTS = []
shoreline_rings = (getattr(course, "WATER_POLYGONS", [course.LAKE_SHORELINE]) +
                   getattr(course, "LAND_HOLES", []))
for shoreline_ring in shoreline_rings:
    previous_shore_point = shoreline_ring[-1]
    for shore_point in shoreline_ring:
        segment_bounds = get_segment_bounds(previous_shore_point, shore_point)
        SHORELINE_SEGMENTS.append((previous_shore_point, shore_point, segment_bounds))
        previous_shore_point = shore_point

# =============================================================================
# BASIC GEOMETRY HELPERS
# =============================================================================

def cross_product(ax, ay, bx, by):
    return (ax * by) - (ay * bx)


def point_is_on_segment(point, start, end):
    # Treat points on a collision edge as touching the obstacle.
    point_x, point_y = point
    start_x, start_y = start
    end_x, end_y = end
    segment_x = end_x - start_x
    segment_y = end_y - start_y
    point_x_from_start = point_x - start_x
    point_y_from_start = point_y - start_y
    area = abs(cross_product(segment_x, segment_y, point_x_from_start, point_y_from_start))
    if area > settings.COLLISION_GEOMETRY_EPSILON:
        return False
    minimum_x = min(start_x, end_x) - settings.COLLISION_GEOMETRY_EPSILON
    maximum_x = max(start_x, end_x) + settings.COLLISION_GEOMETRY_EPSILON
    minimum_y = min(start_y, end_y) - settings.COLLISION_GEOMETRY_EPSILON
    maximum_y = max(start_y, end_y) + settings.COLLISION_GEOMETRY_EPSILON
    return (minimum_x <= point_x <= maximum_x and minimum_y <= point_y <= maximum_y)


def segments_intersect(first_start, first_end, second_start, second_end):
    # Include edge touching as a collision rather than allowing overlap by a pixel.
    a_x, a_y = first_start
    b_x, b_y = first_end
    c_x, c_y = second_start
    d_x, d_y = second_end
    ab_x = b_x - a_x
    ab_y = b_y - a_y
    ac_x = c_x - a_x
    ac_y = c_y - a_y
    ad_x = d_x - a_x
    ad_y = d_y - a_y
    cd_x = d_x - c_x
    cd_y = d_y - c_y
    ca_x = a_x - c_x
    ca_y = a_y - c_y
    cb_x = b_x - c_x
    cb_y = b_y - c_y
    first_cross_c = cross_product(ab_x, ab_y, ac_x, ac_y)
    first_cross_d = cross_product(ab_x, ab_y, ad_x, ad_y)
    second_cross_a = cross_product(cd_x, cd_y, ca_x, ca_y)
    second_cross_b = cross_product(cd_x, cd_y, cb_x, cb_y)
    epsilon = settings.COLLISION_GEOMETRY_EPSILON
    c_and_d_are_opposite = (
        (first_cross_c > epsilon and first_cross_d < -epsilon)
        or (first_cross_c < -epsilon and first_cross_d > epsilon))
    a_and_b_are_opposite = (
        (second_cross_a > epsilon and second_cross_b < -epsilon)
        or (second_cross_a < -epsilon and second_cross_b > epsilon))
    if c_and_d_are_opposite and a_and_b_are_opposite:
        return True
    if (abs(first_cross_c) <= epsilon and point_is_on_segment((c_x, c_y), first_start, first_end)):
        return True
    if (abs(first_cross_d) <= epsilon and point_is_on_segment((d_x, d_y), first_start, first_end)):
        return True
    if (abs(second_cross_a) <= epsilon and point_is_on_segment((a_x, a_y), second_start, second_end)):
        return True
    if (abs(second_cross_b) <= epsilon and point_is_on_segment((b_x, b_y), second_start, second_end)):
        return True
    return False


def point_is_inside_polygon(point, polygon, include_boundary=True):
    # Standard ray-casting test for convex or concave polygons.
    point_x, point_y = point
    inside = False
    previous_point = polygon[-1]
    for current_point in polygon:
        if include_boundary and point_is_on_segment(point, previous_point, current_point):
            return True
        current_x, current_y = current_point
        previous_x, previous_y = previous_point
        crosses_y = (current_y > point_y) != (previous_y > point_y)
        if crosses_y:
            fraction = ((point_y - previous_y) / (current_y - previous_y))
            crossing_x = (previous_x + (fraction * (current_x - previous_x)))
            if point_x < crossing_x:
                inside = not inside
        previous_point = current_point
    return inside


def polygon_edges(polygon):
    # Return each closed polygon edge as a start/end point pair.
    edges = []
    previous_point = polygon[-1]
    for current_point in polygon:
        edges.append((previous_point, current_point))
        previous_point = current_point
    return edges


def polygons_intersect(first_polygon, second_polygon):
    # Collision occurs if edges cross or either polygon contains the other.
    for first_start, first_end in polygon_edges(first_polygon):
        for second_start, second_end in polygon_edges(second_polygon):
            if segments_intersect(first_start, first_end, second_start, second_end):
                return True
    if point_is_inside_polygon(first_polygon[0], second_polygon):
        return True
    if point_is_inside_polygon(second_polygon[0], first_polygon):
        return True
    return False

# =============================================================================
# DISTANCE TO A SEGMENT
# =============================================================================

def closest_point_on_segment(point, start, end):
    point_x, point_y = point
    start_x, start_y = start
    end_x, end_y = end
    segment_x = end_x - start_x
    segment_y = end_y - start_y
    segment_length_squared = (segment_x**2) + (segment_y**2)
    if segment_length_squared <= settings.COLLISION_GEOMETRY_EPSILON:
        return start
    point_from_start_x = point_x - start_x
    point_from_start_y = point_y - start_y
    fraction = ((point_from_start_x * segment_x) + (point_from_start_y * segment_y))
    fraction /= segment_length_squared
    fraction = max(0.0, min(1.0, fraction))
    closest_x = start_x + (fraction * segment_x)
    closest_y = start_y + (fraction * segment_y)
    return closest_x, closest_y


def distance_squared(first_point, second_point):
    delta_x = first_point[0] - second_point[0]
    delta_y = first_point[1] - second_point[1]
    return (delta_x**2) + (delta_y**2)

# =============================================================================
# COLLISION NORMALS
# =============================================================================

def get_shore_collision_normal(boat_polygon):
    # Use the nearest shoreline segment, then choose its water-facing normal.
    nearest_segment = None
    nearest_distance_squared = math.inf
    boat_bounds = get_polygon_bounds(boat_polygon)
    nearby_segments = []
    for segment_start, segment_end, segment_bounds in SHORELINE_SEGMENTS:
        if bounds_overlap(boat_bounds, segment_bounds):
            nearby_segments.append((segment_start, segment_end))
    if not nearby_segments:
        nearby_segments = [
            (segment_start, segment_end)
            for segment_start, segment_end, _ in SHORELINE_SEGMENTS]
    for boat_point in boat_polygon:
        for segment_start, segment_end in nearby_segments:
            closest_point = closest_point_on_segment(boat_point, segment_start, segment_end)
            current_distance_squared = distance_squared(boat_point, closest_point)
            if current_distance_squared < nearest_distance_squared:
                nearest_distance_squared = current_distance_squared
                nearest_segment = (segment_start, segment_end)
    if nearest_segment is None:
        return 0.0, 0.0
    start, end = nearest_segment
    direction_x = end[0] - start[0]
    direction_y = end[1] - start[1]
    length = math.hypot(direction_x, direction_y)
    if length <= settings.COLLISION_GEOMETRY_EPSILON:
        return 0.0, 0.0
    normal_x = -direction_y / length
    normal_y = direction_x / length
    midpoint_x = (start[0] + end[0]) / 2.0
    midpoint_y = (start[1] + end[1]) / 2.0
    test_distance = settings.COLLISION_NORMAL_TEST_DISTANCE
    first_test_x = midpoint_x + (normal_x * test_distance)
    first_test_y = midpoint_y + (normal_y * test_distance)
    if course.is_in_water(first_test_x, first_test_y):
        return normal_x, normal_y
    return -normal_x, -normal_y


def get_dock_collision_normal(boat_x, boat_y, dock_polygon):
    # Point the normal from the nearest dock edge toward the boat center.
    boat_center = (boat_x, boat_y)
    nearest_point = None
    nearest_distance_squared = math.inf
    for edge_start, edge_end in polygon_edges(dock_polygon):
        current_point = closest_point_on_segment(boat_center, edge_start, edge_end)
        current_distance_squared = distance_squared(boat_center, current_point)
        if current_distance_squared < nearest_distance_squared:
            nearest_distance_squared = current_distance_squared
            nearest_point = current_point
    if nearest_point is None:
        return 0.0, 0.0
    normal_x = boat_x - nearest_point[0]
    normal_y = boat_y - nearest_point[1]
    normal_length = math.hypot(normal_x, normal_y)
    if normal_length > settings.COLLISION_GEOMETRY_EPSILON:
        return normal_x / normal_length, normal_y / normal_length

    # -------------------------------------------------------------------------
    # FALLBACK NORMAL
    # -------------------------------------------------------------------------

    # This is only needed if the boat center happens to lie exactly on an edge.
    polygon_center_x = sum(point[0] for point in dock_polygon) / len(dock_polygon)
    polygon_center_y = sum(point[1] for point in dock_polygon) / len(dock_polygon)
    normal_x = boat_x - polygon_center_x
    normal_y = boat_y - polygon_center_y
    normal_length = math.hypot(normal_x, normal_y)
    if normal_length <= settings.COLLISION_GEOMETRY_EPSILON:
        return 0.0, 0.0
    return normal_x / normal_length, normal_y / normal_length

# =============================================================================
# CONTACT POINT HELPERS
# =============================================================================

def world_point_to_boat_local(point, x, y, heading):
    # Convert a world-space point into the boat's forward/sideways coordinates.
    delta_x = point[0] - x
    delta_y = point[1] - y
    heading_cosine = math.cos(heading)
    heading_sine = math.sin(heading)
    forward = (delta_x * heading_cosine) + (delta_y * heading_sine)
    sideways = (-delta_x * heading_sine) + (delta_y * heading_cosine)
    return forward, sideways


def boat_local_point_to_world(local_point, x, y, heading):
    # Convert a boat-space forward/sideways point into world coordinates.
    forward, sideways = local_point
    heading_cosine = math.cos(heading)
    heading_sine = math.sin(heading)
    world_x = x + (forward * heading_cosine) - (sideways * heading_sine)
    world_y = y + (forward * heading_sine) + (sideways * heading_cosine)
    return world_x, world_y


def segment_intersection_point(first_start, first_end, second_start, second_end):
    # Return one representative intersection point for two touching segments.
    first_x = first_end[0] - first_start[0]
    first_y = first_end[1] - first_start[1]
    second_x = second_end[0] - second_start[0]
    second_y = second_end[1] - second_start[1]
    denominator = cross_product(first_x, first_y, second_x, second_y)
    epsilon = settings.COLLISION_GEOMETRY_EPSILON
    if abs(denominator) > epsilon:
        start_delta_x = second_start[0] - first_start[0]
        start_delta_y = second_start[1] - first_start[1]
        first_fraction = cross_product(start_delta_x, start_delta_y, second_x, second_y) / denominator
        second_fraction = cross_product(start_delta_x, start_delta_y, first_x, first_y) / denominator
        if (-epsilon <= first_fraction <= 1.0 + epsilon and
                -epsilon <= second_fraction <= 1.0 + epsilon):
            intersection_x = first_start[0] + (first_fraction * first_x)
            intersection_y = first_start[1] + (first_fraction * first_y)
            return intersection_x, intersection_y
        return None
    # Collinear or endpoint-only contact: average any endpoints shared by both segments.
    shared_points = []
    for point in (first_start, first_end, second_start, second_end):
        if point_is_on_segment(point, first_start, first_end) and point_is_on_segment(point, second_start, second_end):
            shared_points.append(point)
    if not shared_points:
        return None
    average_x = sum(point[0] for point in shared_points) / len(shared_points)
    average_y = sum(point[1] for point in shared_points) / len(shared_points)
    return average_x, average_y


def find_polygon_contact_point(boat_polygon, obstacle_polygon):
    # Prefer actual edge intersections; otherwise use the nearest boat point.
    intersection_points = []
    for boat_start, boat_end in polygon_edges(boat_polygon):
        for obstacle_start, obstacle_end in polygon_edges(obstacle_polygon):
            intersection = segment_intersection_point(boat_start, boat_end, obstacle_start, obstacle_end)
            if intersection is not None:
                intersection_points.append(intersection)
    if intersection_points:
        contact_x = sum(point[0] for point in intersection_points) / len(intersection_points)
        contact_y = sum(point[1] for point in intersection_points) / len(intersection_points)
        return contact_x, contact_y
    nearest_boat_point = boat_polygon[0]
    nearest_distance_squared = math.inf
    for boat_point in boat_polygon:
        for obstacle_start, obstacle_end in polygon_edges(obstacle_polygon):
            obstacle_point = closest_point_on_segment(boat_point, obstacle_start, obstacle_end)
            current_distance_squared = distance_squared(boat_point, obstacle_point)
            if current_distance_squared < nearest_distance_squared:
                nearest_distance_squared = current_distance_squared
                nearest_boat_point = boat_point
    return nearest_boat_point


def find_shore_contact_point(boat_polygon):
    # Find where the boat first meets or crosses the shoreline polygon.
    boat_bounds = get_polygon_bounds(boat_polygon)
    nearby_segments = []
    for segment_start, segment_end, segment_bounds in SHORELINE_SEGMENTS:
        if bounds_overlap(boat_bounds, segment_bounds):
            nearby_segments.append((segment_start, segment_end))
    if not nearby_segments:
        nearby_segments = [(segment_start, segment_end) for segment_start, segment_end, _ in SHORELINE_SEGMENTS]
    intersection_points = []
    for boat_start, boat_end in polygon_edges(boat_polygon):
        for shore_start, shore_end in nearby_segments:
            intersection = segment_intersection_point(boat_start, boat_end, shore_start, shore_end)
            if intersection is not None:
                intersection_points.append(intersection)
    if intersection_points:
        contact_x = sum(point[0] for point in intersection_points) / len(intersection_points)
        contact_y = sum(point[1] for point in intersection_points) / len(intersection_points)
        return contact_x, contact_y
    outside_points = [
        point
        for point in boat_polygon
        if not course.is_in_water(*point)]
    candidate_points = outside_points if outside_points else boat_polygon
    nearest_boat_point = candidate_points[0]
    nearest_distance_squared = math.inf
    for boat_point in candidate_points:
        for shore_start, shore_end in nearby_segments:
            shore_point = closest_point_on_segment(boat_point, shore_start, shore_end)
            current_distance_squared = distance_squared(boat_point, shore_point)
            if current_distance_squared < nearest_distance_squared:
                nearest_distance_squared = current_distance_squared
                nearest_boat_point = boat_point
    return nearest_boat_point

# =============================================================================
# COURSE COLLISION TEST
# =============================================================================

def get_course_collision(local_points, x, y, heading, include_contact_point=True):
    # Test the boat envelope against each solid course boundary.
    boat_polygon = get_boat_collision_world_points(local_points, x, y, heading)
    boat_bounds = get_polygon_bounds(boat_polygon)

    # -------------------------------------------------------------------------
    # DOCKS
    # -------------------------------------------------------------------------

    # Check docks first so docking contact follows the dock edge rather than a
    # nearby shoreline when both boundaries are close together.
    for dock_polygon, dock_bounds in zip(DOCK_COLLISION_POLYGONS, DOCK_COLLISION_BOUNDS):
        if not bounds_overlap(boat_bounds, dock_bounds):
            continue
        if polygons_intersect(boat_polygon, dock_polygon):
            normal = get_dock_collision_normal(x, y, dock_polygon)
            collision = {"type": "dock", "normal": normal}
            if include_contact_point:
                contact_world = find_polygon_contact_point(boat_polygon, dock_polygon)
                collision["contact_local_point"] = world_point_to_boat_local(contact_world, x, y, heading)
            return collision

    # -------------------------------------------------------------------------
    # SHORELINE
    # -------------------------------------------------------------------------

    # Every boat point must remain inside the lake and no boat edge may cross
    # the shoreline. The shoreline itself is the collision boundary.
    shoreline_collision = False
    for boat_point in boat_polygon:
        if not course.is_in_water(*boat_point):
            shoreline_collision = True
            break
    nearby_shore_segments = []
    if not shoreline_collision:
        for segment_start, segment_end, segment_bounds in SHORELINE_SEGMENTS:
            if bounds_overlap(boat_bounds, segment_bounds):
                nearby_shore_segments.append((segment_start, segment_end))
        for boat_start, boat_end in polygon_edges(boat_polygon):
            for shore_start, shore_end in nearby_shore_segments:
                if segments_intersect(boat_start, boat_end, shore_start, shore_end):
                    shoreline_collision = True
                    break
            if shoreline_collision:
                break
    if shoreline_collision:
        normal = get_shore_collision_normal(boat_polygon)
        collision = {"type": "shore", "normal": normal}
        if include_contact_point:
            contact_world = find_shore_contact_point(boat_polygon)
            collision["contact_local_point"] = world_point_to_boat_local(contact_world, x, y, heading)
        return collision
    return None

# =============================================================================
# POSE HELPERS
# =============================================================================

def shortest_angle_change(start_heading, end_heading):
    # Return the signed smallest rotation between two wrapped headings.
    return ((end_heading - start_heading + math.pi) % (2 * math.pi) - math.pi)


def interpolate_pose(start_pose, end_pose, fraction):
    start_x, start_y, start_heading = start_pose
    end_x, end_y, end_heading = end_pose
    x = start_x + ((end_x - start_x) * fraction)
    y = start_y + ((end_y - start_y) * fraction)
    heading_change = shortest_angle_change(start_heading, end_heading)
    heading = start_heading + (heading_change * fraction)
    heading %= 2 * math.pi
    return x, y, heading


def find_last_safe_pose(local_points, start_pose, end_pose):
    # Binary-search the frame movement to find the last non-colliding pose.
    start_collision = get_course_collision(local_points, *start_pose, include_contact_point=False)
    if start_collision is not None:
        return start_pose, 0.0
    low_fraction = 0.0
    high_fraction = 1.0
    for _ in range(settings.COLLISION_SEARCH_ITERATIONS):
        middle_fraction = (low_fraction + high_fraction) / 2.0
        middle_pose = interpolate_pose(start_pose, end_pose, middle_fraction)
        collision = get_course_collision(local_points, *middle_pose, include_contact_point=False)
        if collision is None:
            low_fraction = middle_fraction
        else:
            high_fraction = middle_fraction
    safe_pose = interpolate_pose(start_pose, end_pose, low_fraction)
    return safe_pose, low_fraction

# =============================================================================
# COLLISION SPEED
# =============================================================================

def calculate_contact_point_velocity(boat, local_contact_point):
    # Point velocity is the center-of-mass velocity plus the rotational velocity.
    contact_world = boat_local_point_to_world(local_contact_point, boat.x, boat.y, boat.heading)
    relative_x = contact_world[0] - boat.x
    relative_y = contact_world[1] - boat.y
    point_velocity_x = boat.velocity_x - (boat.angular_velocity * relative_y)
    point_velocity_y = boat.velocity_y + (boat.angular_velocity * relative_x)
    return point_velocity_x, point_velocity_y


def calculate_collision_speed(boat, local_contact_point, collision_normal):
    # Measure only the contact point's velocity directed into the obstacle.
    normal_x, normal_y = collision_normal
    normal_length = math.hypot(normal_x, normal_y)
    if normal_length <= settings.COLLISION_GEOMETRY_EPSILON:
        return boat.get_speed()
    normal_x /= normal_length
    normal_y /= normal_length
    point_velocity_x, point_velocity_y = calculate_contact_point_velocity(boat, local_contact_point)
    normal_speed = (point_velocity_x * normal_x) + (point_velocity_y * normal_y)
    return max(0.0, -normal_speed)

# =============================================================================
# CONTACT-POINT COLLISION IMPULSE
# =============================================================================

def apply_collision_impulse(boat, local_contact_point, collision_normal, restitution):
    # Apply the normal impulse at the actual contact point so translation and
    # rotation emerge from the same collision calculation.
    normal_x, normal_y = collision_normal
    normal_length = math.hypot(normal_x, normal_y)
    if normal_length <= settings.COLLISION_GEOMETRY_EPSILON:
        return 0.0
    normal_x /= normal_length
    normal_y /= normal_length
    contact_world = boat_local_point_to_world(local_contact_point, boat.x, boat.y, boat.heading)
    relative_x = contact_world[0] - boat.x
    relative_y = contact_world[1] - boat.y
    point_velocity_x, point_velocity_y = calculate_contact_point_velocity(boat, local_contact_point)
    normal_speed = (point_velocity_x * normal_x) + (point_velocity_y * normal_y)
    if normal_speed >= 0.0:
        return 0.0
    lever_cross_normal = (relative_x * normal_y) - (relative_y * normal_x)
    inverse_effective_mass = ((1.0 / boat.mass) + ((lever_cross_normal**2) / boat.moment_of_inertia))
    if inverse_effective_mass <= settings.COLLISION_GEOMETRY_EPSILON:
        return 0.0
    restitution = max(0.0, min(1.0, restitution))
    impulse_magnitude = -((1.0 + restitution) * normal_speed) / inverse_effective_mass
    impulse_x = impulse_magnitude * normal_x
    impulse_y = impulse_magnitude * normal_y
    boat.velocity_x += impulse_x / boat.mass
    boat.velocity_y += impulse_y / boat.mass
    angular_impulse = (relative_x * impulse_y) - (relative_y * impulse_x)
    boat.angular_velocity += angular_impulse / boat.moment_of_inertia
    return impulse_magnitude


# =============================================================================
# POST-COLLISION MOTION
# =============================================================================

def advance_after_collision(boat, local_points, remaining_time):
    # Continue through the unused part of the frame with the post-impact linear
    # and angular velocities. Stop only if the new motion would penetrate an
    # obstacle.
    if remaining_time <= 0.0:
        return

    start_pose = (boat.x, boat.y, boat.heading)

    target_x = boat.x + (boat.velocity_x * remaining_time)
    target_y = boat.y + (boat.velocity_y * remaining_time)
    target_heading = (boat.heading + (boat.angular_velocity * remaining_time)) % (2 * math.pi)

    target_pose = (target_x, target_y, target_heading)
    target_collision = get_course_collision(local_points, *target_pose, include_contact_point=False)

    if target_collision is None:
        boat.x, boat.y, boat.heading = target_pose
        return

    safe_pose, _ = find_last_safe_pose(local_points, start_pose, target_pose)
    boat.x, boat.y, boat.heading = safe_pose


# =============================================================================
# CONTACT COLLISION
# =============================================================================

def resolve_contact_collision(boat, local_points, collision, safe_pose, safe_fraction, dt):
    # Gentle contact uses zero restitution. The inward motion of the contact
    # point is removed, while tangential motion and the angular response from an
    # off-center impact remain.
    boat.x, boat.y, boat.heading = safe_pose

    restitution = getattr(settings, "COLLISION_CONTACT_RESTITUTION", 0.0)

    apply_collision_impulse(
        boat,
        collision["contact_local_point"],
        collision["normal"],
        restitution)

    remaining_time = dt * (1.0 - safe_fraction)
    advance_after_collision(boat, local_points, remaining_time)


def resolve_bump_collision(boat, local_points, collision, safe_pose, safe_fraction, dt):
    # A bump uses the same contact-point impulse with a small elastic rebound,
    # then continues through the unused part of the frame.
    boat.x, boat.y, boat.heading = safe_pose

    restitution = getattr(settings, "COLLISION_BUMP_RESTITUTION", 0.15)

    apply_collision_impulse(
        boat,
        collision["contact_local_point"],
        collision["normal"],
        restitution)

    remaining_time = dt * (1.0 - safe_fraction)
    advance_after_collision(boat, local_points, remaining_time)


# =============================================================================
# RESOLVE COURSE COLLISIONS
# =============================================================================

def resolve_course_collisions(boat, local_points, previous_pose, dt):
    # Classify the collision by inward contact-point speed, then apply the
    # matching contact-point impulse response.
    target_pose = (boat.x, boat.y, boat.heading)
    collision = get_course_collision(local_points, *target_pose)

    if collision is None:
        return None

    local_contact_point = collision["contact_local_point"]

    # Collision severity uses only the inward velocity of the actual contact
    # point. The 5-second rolling average is reserved for deciding when docking
    # is complete in main.py.
    inbound_speed = calculate_collision_speed(boat, local_contact_point, collision["normal"])
    average_speed = boat.get_average_speed()

    safe_pose, safe_fraction = find_last_safe_pose(local_points, previous_pose, target_pose)

    if inbound_speed < settings.COLLISION_CONTACT_MAX_SPEED:
        collision_level = "contact"

        resolve_contact_collision(
            boat,
            local_points,
            collision,
            safe_pose,
            safe_fraction,
            dt)

    elif inbound_speed < settings.COLLISION_BUMP_MAX_SPEED:
        collision_level = "bump"

        resolve_bump_collision(
            boat,
            local_points,
            collision,
            safe_pose,
            safe_fraction,
            dt)

    else:
        collision_level = "crash"
        boat.x, boat.y, boat.heading = safe_pose

    return {
        "level": collision_level,
        "type": collision["type"],
        "impact_speed": inbound_speed,
        "average_speed": average_speed}
