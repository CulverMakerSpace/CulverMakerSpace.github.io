# Coxswain Simulator — v3.9-pygame

A two-dimensional rowing and coxswain-training simulator with **one shared Python physics engine** and two desktop renderers: **Pygame** and **Godot**.

**v3.9-pygame is a performance-focused Pygame update.** It preserves the v3.8 file structure, shared physics, controls, courses, and Godot interface. The Pygame renderer now uses fixed-timestep physics with an interpolated display pose and more efficient shoreline and texture processing. Its course menu is simpler. See [`docs/V3.9_PERFORMANCE.md`](docs/V3.9_PERFORMANCE.md). The high-zoom
rendering fix is documented in [`docs/V3.9_HIGH_ZOOM_FIX.md`](docs/V3.9_HIGH_ZOOM_FIX.md).

## Start the Pygame simulator

Open a terminal in the **project root** (the folder containing `main.py`).

```powershell
py -m pip install -r requirements.txt
py main.py
```

Choose Lake Maxinkuckee, Head of the Charles, Nathan Benderson Park, or Milwaukee River. For keyboard controls, see [`docs/reference/CONTROLS.txt`](docs/reference/CONTROLS.txt).

## Start the Godot simulator

The Godot renderer runs locally and communicates with the same Python engine.

1. From the **project root**, start the Python bridge: `py godot_bridge.py`.
2. In Godot 4, open **`godot_graphics/project.godot`**.
3. Run the Godot project and select a course.

The TCP address is `127.0.0.1:28542`. The JSON message protocol is unchanged in v3.8. Godot does not require Pygame to be installed, because the shared controls have a fallback for Pygame key symbols.

## Where to find things

```text
Coxswain_Simulator_v3.9/
│
├── docs/                        User guides, architecture, coding conventions
├── source_data/                 Four course definitions, registry, and visual geometry
│   ├── courses/                 Python course modules and course selection
│   ├── geojson/                 Original OSM/GeoJSON reference data
│   └── visual_geometry.py       Display-only shoreline and bridge outlines
├── physics_engine/              Boat state, simulation, crew controls, stroke clock
│   └── physics/                 Rowing, water/air forces, collisions, dock grabbing
├── pygame_graphics/             Pygame camera, boat, HUD, scenery, trails, menu
│   └── assets/                  Water, grass, city, and wood textures
├── godot_graphics/              Godot project, scene, and overhead GDScript
├── tests/                       Unit, physics-regression, and bridge integration tests
│
├── main.py                      Start the Pygame edition
├── godot_bridge.py              Start the Godot physics connection
├── settings.py                  Shared configuration and physical constants
└── requirements.txt             Pygame desktop dependency
```

Physics lives exclusively in `physics_engine/`; neither graphics folder should update the boat motion. `source_data/visual_geometry.py` changes **display shapes only**. Physical shorelines and collisions remain based on the original course data.

For individual modules and design decisions, see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md). For your agreed readable-code formatting, see [`docs/CODING_STYLE.md`](docs/CODING_STYLE.md). For changes from the prior folder names, see [`docs/V3.8_MIGRATION.md`](docs/V3.8_MIGRATION.md).

## Run automated tests

```powershell
py -m unittest discover -s tests -v
```

Includes four-course deterministic physics comparisons, raised-oar docking tests, source layout checks, bridge/shoreside visual geometry checks, and a local TCP exchange with the Godot bridge.

## Performance diagnostic

Press **F3** while playing to toggle an FPS and drawing-time overlay. This release targets smoother 60 FPS rendering, but exact performance depends on the hardware and has not been measured here.

## Publishing notes

The Pygame edition can be prepared for GitHub Pages through Pygbag. The Godot desktop edition still uses a local Python TCP server; its existing desktop Godot project is **not** a standalone browser build. When publishing source code or extracting this ZIP, keep the package folders together and **do not overlay them on the older v2.4 tree** (the renamed modules can conflict with leftover files).
