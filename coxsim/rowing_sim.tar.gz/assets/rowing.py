import math

import settings


# =============================================================================
# STROKE TIMING
# =============================================================================

def get_stroke_period(stroke_rate):
    stroke_rate_per_second = stroke_rate / 60.0
    stroke_period = 1.0 / stroke_rate_per_second

    return stroke_period


def get_drive_time(stroke_rate):
    stroke_period = get_stroke_period(stroke_rate)
    drive_time = stroke_period * settings.DRIVE_FRACTION

    return drive_time


def get_stroke_phase(simulation_time, stroke_rate):
    stroke_period = get_stroke_period(stroke_rate)
    drive_time = get_drive_time(stroke_rate)
    cycle_time = simulation_time % stroke_period

    if cycle_time < drive_time:
        return "drive"

    return "recovery"


def is_drive_phase(simulation_time, stroke_rate):
    return get_stroke_phase(simulation_time, stroke_rate) == "drive"


# =============================================================================
# STROKE-RATE SCALING
# =============================================================================

def calculate_stroke_rate_scale(stroke_rate):
    stroke_rate_scale = stroke_rate / settings.REFERENCE_STROKE_RATE

    return stroke_rate_scale


# =============================================================================
# BLADE TRAVEL
# =============================================================================

def calculate_blade_travel():
    stroke_angle_radians = math.radians(settings.OAR_STROKE_ANGLE)
    blade_travel = settings.OAR_OUTBOARD * stroke_angle_radians

    return blade_travel


# =============================================================================
# REFERENCE WORK PER STROKE
# =============================================================================

def calculate_reference_work_per_stroke():
    reference_stroke_rate_per_second = settings.REFERENCE_STROKE_RATE / 60.0
    reference_work_per_stroke = settings.ROWER_POWER / reference_stroke_rate_per_second

    return reference_work_per_stroke


# =============================================================================
# MAXIMUM FORCE PER ROWER
# =============================================================================

def calculate_max_force_per_rower(efficiency, stroke_rate):
    reference_work_per_stroke = calculate_reference_work_per_stroke()
    useful_reference_work = reference_work_per_stroke * efficiency
    blade_travel = calculate_blade_travel()

    reference_maximum_force = useful_reference_work / blade_travel
    stroke_rate_scale = calculate_stroke_rate_scale(stroke_rate)
    maximum_force = reference_maximum_force * stroke_rate_scale

    return maximum_force


# =============================================================================
# USEFUL DRIVE POWER
# =============================================================================

def calculate_useful_drive_power(efficiency, stroke_rate):
    stroke_rate_scale = calculate_stroke_rate_scale(stroke_rate)
    rower_power = settings.ROWER_POWER * stroke_rate_scale
    useful_average_power = rower_power * efficiency
    useful_drive_power = useful_average_power / settings.DRIVE_FRACTION

    return useful_drive_power


# =============================================================================
# POWER-LIMITED FORCE PER ROWER
# =============================================================================

def calculate_power_limited_force(boat, efficiency, stroke_rate):
    maximum_force = calculate_max_force_per_rower(efficiency, stroke_rate)
    useful_drive_power = calculate_useful_drive_power(efficiency, stroke_rate)

    velocity_forward, velocity_sideways = boat.get_velocity_components()
    speed_forward = abs(velocity_forward)


    # -------------------------------------------------------------------------
    # LOW SPEED
    # -------------------------------------------------------------------------
    # P = Fv cannot determine force at zero speed, so use the force limit.
    if speed_forward <= 0.0:
        return maximum_force


    # -------------------------------------------------------------------------
    # POWER LIMIT
    # -------------------------------------------------------------------------
    power_limited_force = useful_drive_power / speed_forward
    force_per_rower = min(maximum_force, power_limited_force)

    return force_per_rower


# =============================================================================
# FORWARD ROWING FORCE
# =============================================================================

def calculate_forward_force(boat, number_of_rowers, stroke_rate):
    force_per_rower = calculate_power_limited_force(boat, settings.FORWARD_EFFICIENCY, stroke_rate)
    total_force = force_per_rower * number_of_rowers

    return total_force


# =============================================================================
# REVERSE ROWING FORCE
# =============================================================================

def calculate_reverse_force(boat, number_of_rowers, stroke_rate):
    force_per_rower = calculate_power_limited_force(boat, settings.REVERSE_EFFICIENCY, stroke_rate)
    total_force = -force_per_rower * number_of_rowers

    return total_force


# =============================================================================
# HOLD-WATER FORCE LIMIT
# =============================================================================

def calculate_max_hold_force_per_rower():
    reference_maximum_force = calculate_max_force_per_rower(
        settings.FORWARD_EFFICIENCY,
        settings.REFERENCE_STROKE_RATE)

    maximum_hold_force = reference_maximum_force * settings.HOLD_FORCE_FRACTION

    return maximum_hold_force


# =============================================================================
# HOLD-WATER BLADE VELOCITY
# =============================================================================

def calculate_hold_water_blade_velocity(boat, blade_sideways):
    velocity_forward, velocity_sideways = boat.get_velocity_components()

    rotational_forward_velocity = -boat.angular_velocity * blade_sideways
    blade_forward_velocity = velocity_forward + rotational_forward_velocity

    return blade_forward_velocity


# =============================================================================
# HOLD-WATER FORCE
# =============================================================================

def calculate_hold_water_force(boat, blade_sideways):
    blade_forward_velocity = calculate_hold_water_blade_velocity(boat, blade_sideways)

    drag_magnitude = (
        0.5
        * settings.WATER_DENSITY
        * settings.OAR_BLADE_DRAG_COEFFICIENT
        * settings.OAR_BLADE_AREA
        * blade_forward_velocity**2)

    maximum_hold_force = calculate_max_hold_force_per_rower()
    hold_force_magnitude = min(drag_magnitude, maximum_hold_force)


    # -------------------------------------------------------------------------
    # DIRECTION
    # -------------------------------------------------------------------------
    if blade_forward_velocity > 0.0:
        return -hold_force_magnitude

    if blade_forward_velocity < 0.0:
        return hold_force_magnitude

    return 0.0
