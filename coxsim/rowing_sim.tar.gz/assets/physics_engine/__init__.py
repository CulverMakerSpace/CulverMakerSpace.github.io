"""Shared simulator engine (no rendering dependencies)."""
