"""Pygame-independent boat physics, command scheduling, and collision state.

Simulation.step(dt) owns one physics update, independent of either renderer.
Renderers read snapshot() and never update boat physics directly.
"""
import importlib
import math

import settings
from source_data.courses import registry as course
from physics_engine.boat import Boat, CenterOfMassTrail
from physics_engine.controls import ControlState, coast_all_rowers, oars_are_down
from physics_engine.physics.docking import apply_dock_grab_forces, is_fully_alongside_dock
from physics_engine.physics.environment import (
    calculate_coxswain_side_air_force,
    calculate_forward_air_force,
    calculate_section_side_air_force,
)
from physics_engine.physics.hydrodynamics import (
    calculate_longitudinal_drag,
    calculate_rudder_force,
    calculate_section_lateral_force,
    calculate_skeg_force,
)
from physics_engine.physics.rowing import (
    calculate_forward_force,
    calculate_hold_water_force,
    calculate_reverse_force,
)

def get_blade_sideways(seat):
    if seat in settings.PORT_SEATS:
        return settings.OAR_BLADE_CENTER_FROM_CENTERLINE
    return -settings.OAR_BLADE_CENTER_FROM_CENTERLINE


class Simulation:
    """Single source of truth for boat motion, commands, and collision state."""

    def __init__(self, course_name="max"):
        self.load_course(course_name)

    def load_course(self, course_name):
        """Select geometry and refresh the course-specific collision polygons."""
        course.activate_course(course_name)
        from physics_engine.physics import collisions
        importlib.reload(collisions)
        self.resolve_course_collisions = collisions.resolve_course_collisions
        self.course_name = course_name
        self.reset()

    def reset(self):
        self.boat = Boat()
        self.controls = ControlState()
        self.boat.x = course.START_X
        self.boat.y = course.START_Y
        self.boat.heading = math.radians(course.START_HEADING_DEGREES)
        self.com_trail = CenterOfMassTrail(self.boat.x, self.boat.y)
        self.simulation_time = 0.0
        self.warning_message = None
        self.crash_message = None
        self.dock_contact = False
        self.docked = False
        self.simulation_crashed = False

    def step(self, dt):
        if self.simulation_crashed:
            return
        self.simulation_time += dt
        boat = self.boat
        control_state = self.controls
        com_trail = self.com_trail
        resolve_course_collisions = self.resolve_course_collisions
        warning_message = self.warning_message
        crash_message = self.crash_message
        dock_contact = self.dock_contact
        docked = self.docked
        simulation_crashed = self.simulation_crashed
        # ---------------------------------------------------------------------
        # BOAT-WIDE STROKE CLOCK AND SCHEDULED COMMANDS
        # ---------------------------------------------------------------------
        active_rowers = control_state.command_manager.any_rowing()
        completed_cycles = control_state.stroke_clock.update(dt, active_rowers)
        if completed_cycles:
            control_state.command_manager.update()

        # ---------------------------------------------------------------------
        # ROWING FORCE - DRIVE PHASE ONLY
        # ---------------------------------------------------------------------
        if control_state.stroke_clock.is_drive(settings.DRIVE_FRACTION):
            for section in settings.ROWER_SECTIONS:
                for seat in section["rowers"]:
                    if not oars_are_down(control_state, seat):
                        continue

                    rowing_state = control_state.rower_states[seat]
                    blade_sideways = get_blade_sideways(seat)

                    if rowing_state == "forward":
                        rowing_force = calculate_forward_force(boat, 1, control_state.stroke_clock.stroke_rate)
                        boat.apply_force(rowing_force, 0.0, section["position"], blade_sideways)

                    elif rowing_state == "backward":
                        rowing_force = calculate_reverse_force(boat, 1, control_state.stroke_clock.stroke_rate)
                        boat.apply_force(rowing_force, 0.0, section["position"], blade_sideways)


        # ---------------------------------------------------------------------
        # HOLD WATER
        # ---------------------------------------------------------------------
        for section in settings.ROWER_SECTIONS:
            for seat in section["rowers"]:
                rowing_state = control_state.rower_states[seat]

                if rowing_state == "hold" and oars_are_down(control_state, seat):
                    blade_sideways = get_blade_sideways(seat)
                    hold_force = calculate_hold_water_force(boat, blade_sideways)

                    boat.apply_force(hold_force, 0.0, section["position"], blade_sideways)


        # ---------------------------------------------------------------------
        # DOCK GRAB - EACH RAISED OAR CAN ENGAGE BEFORE HULL CONTACT
        # ---------------------------------------------------------------------
        if not docked:
            apply_dock_grab_forces(boat, control_state, dt)
        else:
            control_state.active_dock_grab_seats.clear()


        # ---------------------------------------------------------------------
        # HYDRODYNAMICS - LONGITUDINAL DRAG
        # ---------------------------------------------------------------------
        longitudinal_drag = calculate_longitudinal_drag(boat)
        boat.apply_force(longitudinal_drag, 0.0)


        # ---------------------------------------------------------------------
        # HYDRODYNAMICS - HULL LATERAL FORCES
        # ---------------------------------------------------------------------
        for section in settings.HULL_SECTIONS:
            lateral_force = calculate_section_lateral_force(boat, section)
            boat.apply_force(0.0, lateral_force, section["position"], 0.0)


        # ---------------------------------------------------------------------
        # RUDDER
        # ---------------------------------------------------------------------
        rudder_force = calculate_rudder_force(boat, control_state.rudder_angle)
        boat.apply_force(0.0, rudder_force, settings.STEERING_LEVER_ARM, 0.0)


        # ---------------------------------------------------------------------
        # SKEG
        # ---------------------------------------------------------------------
        skeg_force = calculate_skeg_force(boat)
        boat.apply_force(0.0, skeg_force, settings.STEERING_LEVER_ARM, 0.0)


        # ---------------------------------------------------------------------
        # AERODYNAMICS - FORWARD
        # ---------------------------------------------------------------------
        forward_air_force = calculate_forward_air_force(boat)
        boat.apply_force(forward_air_force, 0.0, 0.0, 0.0)


        # ---------------------------------------------------------------------
        # AERODYNAMICS - HULL SECTIONS SIDEWAYS
        # ---------------------------------------------------------------------
        for section in settings.HULL_SECTIONS:
            side_air_force = calculate_section_side_air_force(boat, section)
            boat.apply_force(0.0, side_air_force, section["position"], 0.0)


        # ---------------------------------------------------------------------
        # AERODYNAMICS - COXSWAIN SIDEWAYS
        # ---------------------------------------------------------------------
        coxswain_side_air_force = calculate_coxswain_side_air_force(boat)
        boat.apply_force(0.0, coxswain_side_air_force, settings.COXSWAIN_POSITION, 0.0)


        # ---------------------------------------------------------------------
        # UPDATE BOAT STATE
        # ---------------------------------------------------------------------
        previous_x = boat.x
        previous_y = boat.y
        previous_pose = (boat.x, boat.y, boat.heading)

        boat.update(dt)


        # ---------------------------------------------------------------------
        # COURSE COLLISIONS
        # ---------------------------------------------------------------------
        collision_result = resolve_course_collisions(boat, control_state.boat_collision_local_points, previous_pose, dt)


        # ---------------------------------------------------------------------
        # SPEED HISTORY
        # ---------------------------------------------------------------------
        # Record the resolved movement for the 5-second rolling average.
        # This average is used only to decide when a gentle dock contact has
        # settled enough to count as DOCKED.
        distance_travelled = math.hypot(boat.x - previous_x, boat.y - previous_y)

        boat.record_speed_history(dt, distance_travelled)
        com_trail.record(boat.x, boat.y)

        average_speed = boat.get_average_speed()


        # ---------------------------------------------------------------------
        # COLLISION BEHAVIOR
        # ---------------------------------------------------------------------
        if collision_result is not None:
            collision_level = collision_result["level"]
            collision_type = collision_result["type"]
            inbound_speed = collision_result["impact_speed"]

            # Collision severity is classified in collisions.py using the
            # inward speed of the actual contact point.
            if collision_level == "contact":
                coast_all_rowers(control_state)

                if collision_type == "dock":
                    dock_contact = True

            elif collision_level == "bump":
                dock_contact = False

                coast_all_rowers(control_state)
                control_state.rudder_angle = 0.0

                if collision_type == "dock":
                    warning_message = f"WARNING: Dock collision at {inbound_speed:.2f} m/s"

                else:
                    warning_message = f"WARNING: Shore collision at {inbound_speed:.2f} m/s"

            elif collision_level == "crash":
                dock_contact = False

                if collision_type == "dock":
                    crash_message = f"CRASH: Dock collision at {inbound_speed:.2f} m/s"

                else:
                    crash_message = f"CRASH: Shore collision at {inbound_speed:.2f} m/s"

                simulation_crashed = True


        # ---------------------------------------------------------------------
        # SUCCESSFUL DOCKING
        # ---------------------------------------------------------------------
        # Docking requires every raised-oar section on the same side to
        # reach the dock edge. A single bow/stern contact is not sufficient.
        # Evaluate forward speed directly, not the 5-second total-speed HUD.
        forward_speed = (boat.velocity_x * math.cos(boat.heading)
                         + boat.velocity_y * math.sin(boat.heading))
        if (not simulation_crashed and is_fully_alongside_dock(boat, control_state)
                and abs(forward_speed) < settings.COLLISION_DOCKED_MAX_SPEED):
            docked = True


        self.warning_message = warning_message
        self.crash_message = crash_message
        self.dock_contact = dock_contact
        self.docked = docked
        self.simulation_crashed = simulation_crashed

    def _seat_command_status(self):
        """Visible remaining strokes for each rower, matching the Pygame HUD."""
        completed = self.controls.stroke_clock.completed_strokes
        result = {}
        for seat, instruction in self.controls.command_manager.pending.items():
            if instruction is None or instruction.mode not in ("in", "for"):
                continue
            if instruction.mode == "in":
                remaining = max(0, instruction.start_at - completed)
            else:
                remaining = max(0, instruction.finish_at - max(completed, instruction.start_at))
            result[str(seat)] = {"mode": instruction.mode.upper(), "remaining": remaining}
        return result


    def _collision_box_world_points(self):
        boat = self.boat
        world_points = []
        cosine = math.cos(boat.heading)
        sine = math.sin(boat.heading)
        for forward, sideways in self.controls.boat_collision_local_points:
            world_x = boat.x + (forward * cosine) - (sideways * sine)
            world_y = boat.y + (forward * sine) + (sideways * cosine)
            world_points.append([world_x, world_y])
        return world_points

    def snapshot(self):
        boat = self.boat
        controls = self.controls
        return {
            "x": boat.x, "y": boat.y, "heading": boat.heading,
            "speed": boat.get_speed(),
            "average_speed_5s": boat.get_average_speed(),
            "distance_m": self.com_trail.distance_m,
            "stroke_count": controls.stroke_clock.completed_strokes,
            "stroke_phase": controls.stroke_clock.phase,
            "stroke_rate": controls.stroke_rate,
            "rudder_angle": controls.rudder_angle,
            "oar_positions": dict(controls.oar_positions),
            "seat_commands": self._seat_command_status(),
            "rower_states": {str(k): v for k, v in controls.rower_states.items()},
            "trail": self.com_trail.visible_points(),
            "collision_box": self._collision_box_world_points(),
            "prepared": controls.get_prepared_text(),
            "warning": self.warning_message,
            "crash": self.crash_message,
            "docked": self.docked,
        }
