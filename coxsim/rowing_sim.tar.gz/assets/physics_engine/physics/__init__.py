"""Rowing forces, water and air forces, and contact handling."""
