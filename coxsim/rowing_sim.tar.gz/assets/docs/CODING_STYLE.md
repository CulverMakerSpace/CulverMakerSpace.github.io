# Coxswain Simulator coding conventions

These conventions apply to new code and future refactors.

## Human readability first

- Prefer descriptive `snake_case` names for functions and local variables; uppercase constants in `settings.py`.
- Use explicit intermediate variables when they make physical meaning, units, or coordinate frames clearer.
- Keep physics calculations step-by-step and add units (m, m/s, N, rad) where useful.
- Use a large `# =============================================================================` heading for major sections, and a smaller `# -------------------------------------------------------------------------` divider within long functions or classes.
- Leave whitespace between distinct ideas, not gratuitous blank lines inside short calculations.
- Follow the single-responsibility principle when placing files: simulations in `physics_engine`, Pygame drawing in `pygame_graphics`, Godot drawing in `godot_graphics`, and mapped data in `source_data`.

## Line width and wrapping

- **Hard maximum:** 140 characters.
- **Preferred:** around 80; up to about 110 is reasonable if the line stays readable.
- Keep equations, function definitions, and calls on one line whenever the resulting line fits naturally.
- For a longer call, align parameters in a single column and keep the closing parenthesis with the final parameter when appropriate.
- Split long equations at an additive `+` or `-` boundary, preserving the order of operations.
- Do not collapse physical calculations into nested one-line expressions merely to save lines.

## Safe changes

1. Add a test if you are changing behavior, especially docking or rowing physics.
2. Run `py -m unittest discover -s tests -v`.
3. Re-run all four course physics baselines if reorganizing modules.
4. Check the Godot JSON bridge if relocating shared code.
5. Treat Pygame and Godot graphics as independent consumers of the shared physics. Neither should own physical movement.

Do not change scientific constants or physics functions during a formatting-only refactor. Do not commit `__pycache__`, `.pyc`, Pygbag generated files, or Godot's generated `.godot` cache.
