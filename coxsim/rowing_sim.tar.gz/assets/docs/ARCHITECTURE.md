# v3.8 project architecture

## One Python physics engine, two independent renderers

```text
                 main.py                            godot_bridge.py
                    │                                     │
                    ▼                                     ▼
              pygame_graphics/                    godot_graphics/
                  (draws)                          (Godot TCP client)
                    │                                     │
                    └───────────────┬─────────────────────┘
                                    ▼
                       physics_engine/simulation.py
                                    │
                 ┌──────────────────┼─────────────────┐
                 ▼                  ▼                 ▼
       physics_engine/boat.py    controls.py      physics_engine/physics/
                              commands.py       (force/collision modules)
                                    │
                                    ▼
                          source_data/courses/
```

`Simulation.step(dt)` remains the **only authoritative motion update**. The renderers consume the state, but must never determine the boat's force, location, docking outcome, or course collisions.

## Directory responsibilities

| Location | Responsibility |
|---|---|
| `docs/` | Architecture, readable-code conventions, controls, and previous-release notes |
| `source_data/courses/registry.py` | Active course ID and importable course selection |
| `source_data/courses/course_*.py` | Physical shoreline, dock, start, bridge, and other mapped course inputs |
| `source_data/geojson/` | Original mapping reference files; not required to be parsed every frame |
| `source_data/visual_geometry.py` | Precomputed, bounded shoreline detail and merged visual bridge outlines |
| `physics_engine/boat.py` | Boat motion, mass/inertia calculations, and center-of-mass history |
| `physics_engine/controls.py` | Crew/oar states and prepared keyboard commands |
| `physics_engine/commands.py` | Shared stroke clock and scheduled `FOR`/`IN` commands |
| `physics_engine/simulation.py` | Step ordering, collision handling, docking completion, and read-only snapshots |
| `physics_engine/physics/rowing.py` | Drive, reverse, and hold-water force models |
| `physics_engine/physics/hydrodynamics.py` | Longitudinal/lateral drag, skeg, and rudder forces |
| `physics_engine/physics/environment.py` | Wind and other environmental forces |
| `physics_engine/physics/collisions.py` | Physical collision boundaries and impulses |
| `physics_engine/physics/docking.py` | Individual raised-oar dock grabbing and four-section docking completion |
| `pygame_graphics/camera.py` | Follow-camera and overview coordinate transforms |
| `pygame_graphics/scenery.py` | Cached textured world scenery, docks, and bridges |
| `pygame_graphics/boat.py` | Shell, rowers, oars, collision envelope, and wake rendering |
| `pygame_graphics/trails.py` | Temporary wake path and 100 m heading-reference geometry |
| `pygame_graphics/hud.py` | Stroke/rower status, split, rudder, distance, and docking/crash notices |
| `pygame_graphics/menu.py` | Startup course selection |
| `pygame_graphics/assets/` | PNG scenery materials, anchored to world coordinates |
| `godot_graphics/overhead.gd` | Godot overhead display, HUD, and TCP input/state presentation |
| `godot_bridge.py` | Shared simulator startup, course JSON messages, keyboard translation, and periodic snapshots |
| `tests/` | Regression tests for physics, input, Godot messages, and rendering constraints |

## Import rules

- Refer to the active course as `from source_data.courses import registry as course`.
- Import shared physics as `from physics_engine.simulation import Simulation` and `from physics_engine.physics...`.
- Import Pygame visuals as `from pygame_graphics...` only from the launcher or Pygame renderer modules.
- Godot owns its `.gd`, `.tscn`, and `.godot` files **inside `godot_graphics/`**; its scene paths use `res://` relative to that project folder.
- Raw source GeoJSON remains separated in `source_data/geojson/` and is not required in the hot render loop.

## Course switching and collision geometry

`Simulation.load_course()` switches the registry's active course and **reloads the physical collision module** because its dock and boundary polygons depend on the active course. Preserve that reload until collision inputs can be passed explicitly and tested.

The shoreline subdivision and bridge merging are **display-only**. They are prepared once per course and bounded to avoid high redraw or Godot TCP message costs. Rendering does not alter the original collision coordinates.

## Godot compatibility

Godot still consumes `course_list`, `course`, and `state` messages and sends `select_course`, `key`, and `reset`. The TCP address, course IDs, state field names, and scene resource IDs are unchanged. The scene folder was renamed, not rewritten.

## Rendering performance

Keep scenery textures locked to world coordinates. Reuse Pygame buffers and cached rotations. Avoid per-frame polygon-containment sweeps and unbounded map-wide texture generation. The full map must remain responsive on both renderers.
