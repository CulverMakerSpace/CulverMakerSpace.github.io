"""Renderer-independent tracking of the boat center of mass.

Distances use the resolved world positions after collision handling, not
instantaneous velocity or distance from the starting point.
"""
import math


class CenterOfMassTrail:
    def __init__(self, x, y, minimum_point_spacing=0.5):
        self.points = [(float(x), float(y))]
        self.distance_m = 0.0
        self.minimum_point_spacing = minimum_point_spacing
        self.last_position = (float(x), float(y))

    def record(self, x, y):
        position = (float(x), float(y))
        step_distance = math.dist(self.last_position, position)
        self.distance_m += step_distance
        self.last_position = position

        if math.dist(self.points[-1], position) >= self.minimum_point_spacing:
            self.points.append(position)

    def visible_points(self):
        # Include the current position even if it has not crossed the drawing threshold.
        if self.points[-1] == self.last_position:
            return self.points
        return [*self.points, self.last_position]
