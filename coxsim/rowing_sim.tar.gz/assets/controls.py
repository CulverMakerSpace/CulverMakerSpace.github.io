try:
    import pygame  # type: ignore[reportMissingImports]
except ImportError:
    from types import SimpleNamespace
    _key_names = "LSHIFT RSHIFT LCTRL RCTRL LALT RALT q p c g BACKQUOTE TAB w s SPACE RETURN KP_ENTER u j UP DOWN LEFT RIGHT 0 1 2 3 4 5 6 7 8 9".split()
    pygame = SimpleNamespace(KEYDOWN="KEYDOWN", **{"K_" + name: name for name in _key_names})
    # Only the input adapter uses these symbolic values when pygame is unavailable.

import settings
from command_engine import CommandManager, StrokeClock

from collisions import create_boat_collision_local_points


# =============================================================================
# CONTROL STATE
# =============================================================================
class ControlState:
    def __init__(self):
        # Prep commands select which rowers receive the next command.
        self.selected_group = None

        self.rower_states = {}

        for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
            self.rower_states[seat] = "coast"

        # Oar height is tracked separately from each rower's rowing state.
        self.oar_positions = {
            "port": "down",
            "starboard": "down"}

        # The local collision shape changes only when oars are raised or lowered.
        self.boat_collision_local_points = create_boat_collision_local_points(self.oar_positions)

        self.stroke_clock = StrokeClock(settings.DEFAULT_STROKE_RATE)
        self.command_manager = CommandManager(self.rower_states, self.stroke_clock)
        self.stroke_rate = settings.DEFAULT_STROKE_RATE
        self.command_mode = "continuous"
        self.command_count = 0
        self.awaiting_second_digit = False
        self.prepared_action = None
        self.follow_up_group = None
        self.follow_up_action = None
        self.awaiting_follow_up = False
        self.rudder_angle = 0.0

    def get_prepared_text(self):
        return get_prepared_command_text(self)


# =============================================================================
# PREPARED COMMAND HUD AND STAGING
# =============================================================================
ACTION_LABELS = {"forward": "forward", "backward": "reverse", "coast": "coast", "hold": "hold"}


def get_prepared_command_text(control_state):
    """Describe the unexecuted instruction in natural rowing language."""
    if control_state.selected_group is None:
        return ""

    parts = [control_state.selected_group.title()]
    if control_state.command_mode != "continuous":
        parts.append(control_state.command_mode)
        if control_state.command_count:
            parts.append(str(control_state.command_count))

    if control_state.prepared_action is not None:
        parts.append(ACTION_LABELS[control_state.prepared_action])

    if control_state.awaiting_follow_up:
        parts.append("then")
        if control_state.follow_up_group is not None:
            parts.append(control_state.follow_up_group.title())
        if control_state.follow_up_action is not None:
            parts.append(ACTION_LABELS[control_state.follow_up_action])

    return " ".join(parts)


def clear_prepared_command(control_state):
    """Clear staged input only; never cancel already executing instructions."""
    control_state.selected_group = None
    control_state.command_mode = "continuous"
    control_state.command_count = 0
    control_state.awaiting_second_digit = False
    control_state.prepared_action = None
    control_state.follow_up_group = None
    control_state.follow_up_action = None
    control_state.awaiting_follow_up = False


def execute_prepared_command(control_state):
    """Commit the entire sequence only after G is pressed."""
    if control_state.selected_group is None or control_state.prepared_action is None:
        return False
    if control_state.command_mode != "continuous" and not 1 <= control_state.command_count <= 20:
        return False
    if control_state.awaiting_follow_up and (control_state.follow_up_group is None or
                                             control_state.follow_up_action is None):
        return False

    seats = get_selected_seats(control_state)
    if control_state.awaiting_follow_up:
        if control_state.command_mode != "for":
            return False
        follow_seats = seats_for_group(control_state.follow_up_group)

    control_state.command_manager.send(seats, control_state.prepared_action,
                                       control_state.command_mode, control_state.command_count)
    if control_state.awaiting_follow_up:
        control_state.command_manager.set_follow_up(follow_seats, control_state.follow_up_action)

    clear_prepared_command(control_state)
    return True


def seats_for_group(group):
    if group == "all":
        return list(range(1, settings.NUMBER_OF_ROWERS + 1))
    if group == "port":
        return list(settings.PORT_SEATS)
    if group == "starboard":
        return list(settings.STARBOARD_SEATS)
    return []


# =============================================================================
# PREP COMMAND
# ============================================================================= 
def set_prep_command(control_state, key):
    # Select the group that will receive the next rowing or oar command.
    if key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
        control_state.selected_group = "all"

    elif key == pygame.K_q:
        control_state.selected_group = "port"

    elif key == pygame.K_p:
        control_state.selected_group = "starboard"


# =============================================================================
# SELECTED SEATS
# =============================================================================
def get_selected_seats(control_state):
    # Convert the selected group into the individual seat numbers.
    if control_state.selected_group == "all":
        return list(range(1, settings.NUMBER_OF_ROWERS + 1))

    elif control_state.selected_group == "port":
        return settings.PORT_SEATS

    elif control_state.selected_group == "starboard":
        return settings.STARBOARD_SEATS

    else:
        return []


# =============================================================================
# SELECTED SIDES
# =============================================================================
def get_selected_sides(control_state):
    # Convert the prep command into the side or sides whose oars will move.
    if control_state.selected_group == "all":
        return ["port", "starboard"]

    elif control_state.selected_group == "port":
        return ["port"]

    elif control_state.selected_group == "starboard":
        return ["starboard"]

    else:
        return []


# =============================================================================
# ROWING COMMAND
# =============================================================================
def apply_rowing_command(control_state, rowing_state):
    """Stage an action, replacing any previously selected action."""
    if control_state.awaiting_follow_up:
        if control_state.follow_up_group is not None:
            control_state.follow_up_action = rowing_state
    elif control_state.selected_group is not None:
        control_state.prepared_action = rowing_state


# =============================================================================
# COAST ALL ROWERS
# =============================================================================
def coast_all_rowers(control_state):
    # Stop all rowing commands without changing the current oar positions.
    for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
        control_state.rower_states[seat] = "coast"

    control_state.command_manager.cancel(control_state.rower_states)
    control_state.selected_group = None
    clear_prepared_command(control_state)


# =============================================================================
# OAR HEIGHT COMMAND
# =============================================================================
def apply_oar_position_command(control_state, oar_position):
    # Raise or lower the selected oars and update their rowing/collision state.
    selected_sides = get_selected_sides(control_state)
    oar_position_changed = False

    for side in selected_sides:
        current_oar_position = control_state.oar_positions[side]


        # ---------------------------------------------------------------------
        # COAST AFFECTED ROWERS
        # ---------------------------------------------------------------------
        # Raising or lowering oars leaves that side waiting for a new command.
        if side == "port":
            selected_seats = settings.PORT_SEATS

        else:
            selected_seats = settings.STARBOARD_SEATS

        for seat in selected_seats:
            if seat <= settings.NUMBER_OF_ROWERS:
                control_state.rower_states[seat] = "coast"
                control_state.command_manager.cancel([seat])


        # ---------------------------------------------------------------------
        # OAR POSITION
        # ---------------------------------------------------------------------
        if current_oar_position != oar_position:
            control_state.oar_positions[side] = oar_position
            oar_position_changed = True

    if oar_position_changed:
        control_state.boat_collision_local_points = create_boat_collision_local_points(control_state.oar_positions)

    control_state.selected_group = None


# =============================================================================
# OAR POSITION FOR A SEAT
# =============================================================================
def get_oar_position_for_seat(control_state, seat):
    # Look up whether this rower's oar is down in the water plane or raised.
    if seat in settings.PORT_SEATS:
        return control_state.oar_positions["port"]

    return control_state.oar_positions["starboard"]


def oars_are_down(control_state, seat):
    # Only lowered oars can create rowing or hold-water force.
    return get_oar_position_for_seat(control_state, seat) == "down"


# =============================================================================
# STROKE RATE
# =============================================================================
def change_stroke_rate(control_state, change):
    # Change the rate, then keep it inside the allowed range.
    new_stroke_rate = control_state.stroke_rate + change

    new_stroke_rate = max(settings.MIN_STROKE_RATE, min(settings.MAX_STROKE_RATE, new_stroke_rate))

    control_state.stroke_clock.request_rate(new_stroke_rate)
    control_state.stroke_rate = new_stroke_rate


# =============================================================================
# RUDDER
# =============================================================================
def change_rudder(control_state, change):
    # Change the angle, then keep it inside the physical rudder limits.
    new_rudder_angle = control_state.rudder_angle + change

    new_rudder_angle = max(-settings.MAX_RUDDER_ANGLE, min(settings.MAX_RUDDER_ANGLE, new_rudder_angle))

    control_state.rudder_angle = new_rudder_angle


# =============================================================================
# KEYBOARD EVENT
# =============================================================================
def handle_keyboard_event(control_state, event):
    # Ignore anything that is not a key press.
    if event.type != pygame.KEYDOWN:
        return


    # -------------------------------------------------------------------------
    # CLEAR / GO
    # -------------------------------------------------------------------------
    if event.key == pygame.K_c:
        clear_prepared_command(control_state)
        return

    if event.key == pygame.K_g:
        execute_prepared_command(control_state)
        return

    # -------------------------------------------------------------------------
    # PREP SELECTION (REPEATED KEYS REPLACE THE PREVIOUS GROUP)
    # -------------------------------------------------------------------------
    groups = {pygame.K_LSHIFT: "all", pygame.K_RSHIFT: "all",
              pygame.K_q: "port", pygame.K_p: "starboard"}
    if event.key in groups:
        if control_state.awaiting_follow_up:
            control_state.follow_up_group = groups[event.key]
        else:
            control_state.selected_group = groups[event.key]
        return

    # -------------------------------------------------------------------------
    # MODE / COUNT (THE LAST SELECTION WINS)
    # -------------------------------------------------------------------------
    if not control_state.awaiting_follow_up and control_state.selected_group is not None:
        if event.key in (pygame.K_LCTRL, pygame.K_RCTRL):
            control_state.command_mode = "for"
            return
        if event.key in (pygame.K_LALT, pygame.K_RALT):
            control_state.command_mode = "in"
            return
        # Backtick treats the current single-digit value as the tens digit.
        # The next digit completes a two-digit value; later digits replace it.
        # Examples: 1 ` 4 = 14, 2 ` 0 = 20, 1 ` 4 8 = 8.
        if event.key == pygame.K_BACKQUOTE and control_state.command_mode != "continuous":
            if 1 <= control_state.command_count <= 9:
                control_state.awaiting_second_digit = True
            return

        digit_keys = {pygame.K_0: 0, pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3,
                      pygame.K_4: 4, pygame.K_5: 5, pygame.K_6: 6, pygame.K_7: 7,
                      pygame.K_8: 8, pygame.K_9: 9}
        if event.key in digit_keys and control_state.command_mode != "continuous":
            digit = digit_keys[event.key]
            if control_state.awaiting_second_digit:
                control_state.command_count = (control_state.command_count * 10) + digit
                control_state.awaiting_second_digit = False
            else:
                control_state.command_count = digit if digit else 10
            return

    # -------------------------------------------------------------------------
    # ONE CONTINUOUS FOLLOW-UP FOR A FOR COMMAND
    # -------------------------------------------------------------------------
    if event.key == pygame.K_TAB:
        if (control_state.selected_group is not None and control_state.prepared_action is not None and
                control_state.command_mode == "for" and control_state.command_count > 0):
            control_state.awaiting_follow_up = True
            control_state.follow_up_group = None
            control_state.follow_up_action = None
        return

    # -------------------------------------------------------------------------
    # STAGE ACTION, DO NOT EXECUTE UNTIL G
    # -------------------------------------------------------------------------
    actions = {pygame.K_w: "forward", pygame.K_s: "backward", pygame.K_SPACE: "coast",
               pygame.K_RETURN: "hold", pygame.K_KP_ENTER: "hold"}
    if event.key in actions:
        apply_rowing_command(control_state, actions[event.key])
        return

    # Oar-lifting commands retain their existing immediate behavior.
    if control_state.selected_group is not None and not control_state.awaiting_follow_up:
        if event.key == pygame.K_u:
            apply_oar_position_command(control_state, "up")
            return
        if event.key == pygame.K_j:
            apply_oar_position_command(control_state, "down")
            return

    # -------------------------------------------------------------------------
    # STROKE RATE
    # -------------------------------------------------------------------------
    if event.key == pygame.K_UP:
        change_stroke_rate(control_state, 1)

    elif event.key == pygame.K_DOWN:
        change_stroke_rate(control_state, -1)


    # -------------------------------------------------------------------------
    # RUDDER
    # -------------------------------------------------------------------------
    elif event.key == pygame.K_LEFT:
        change_rudder(control_state, settings.RUDDER_STEP)

    elif event.key == pygame.K_RIGHT:
        change_rudder(control_state, -settings.RUDDER_STEP)
