import pygame  # type: ignore[reportMissingImports]

import settings

from collisions import create_boat_collision_local_points


# =============================================================================
# CONTROL STATE
# =============================================================================
class ControlState:
    def __init__(self):
        # Prep commands select which rowers receive the next command.
        self.selected_group = None

        self.rower_states = {}

        for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
            self.rower_states[seat] = "coast"

        # Oar height is tracked separately from each rower's rowing state.
        self.oar_positions = {
            "port": "down",
            "starboard": "down"}

        # The local collision shape changes only when oars are raised or lowered.
        self.boat_collision_local_points = create_boat_collision_local_points(self.oar_positions)

        self.stroke_rate = settings.DEFAULT_STROKE_RATE
        self.rudder_angle = 0.0


# =============================================================================
# PREP COMMAND
# =============================================================================
def set_prep_command(control_state, key):
    # Select the group that will receive the next rowing or oar command.
    if key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
        control_state.selected_group = "all"

    elif key == pygame.K_q:
        control_state.selected_group = "port"

    elif key == pygame.K_p:
        control_state.selected_group = "starboard"


# =============================================================================
# SELECTED SEATS
# =============================================================================
def get_selected_seats(control_state):
    # Convert the selected group into the individual seat numbers.
    if control_state.selected_group == "all":
        return list(range(1, settings.NUMBER_OF_ROWERS + 1))

    elif control_state.selected_group == "port":
        return settings.PORT_SEATS

    elif control_state.selected_group == "starboard":
        return settings.STARBOARD_SEATS

    else:
        return []


# =============================================================================
# SELECTED SIDES
# =============================================================================
def get_selected_sides(control_state):
    # Convert the prep command into the side or sides whose oars will move.
    if control_state.selected_group == "all":
        return ["port", "starboard"]

    elif control_state.selected_group == "port":
        return ["port"]

    elif control_state.selected_group == "starboard":
        return ["starboard"]

    else:
        return []


# =============================================================================
# ROWING COMMAND
# =============================================================================
def apply_rowing_command(control_state, rowing_state):
    # Apply one rowing state to every currently selected seat.
    selected_seats = get_selected_seats(control_state)

    for seat in selected_seats:
        if seat <= settings.NUMBER_OF_ROWERS:
            control_state.rower_states[seat] = rowing_state

    control_state.selected_group = None


# =============================================================================
# COAST ALL ROWERS
# =============================================================================
def coast_all_rowers(control_state):
    # Stop all rowing commands without changing the current oar positions.
    for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
        control_state.rower_states[seat] = "coast"

    control_state.selected_group = None


# =============================================================================
# OAR HEIGHT COMMAND
# =============================================================================
def apply_oar_position_command(control_state, oar_position):
    # Raise or lower the selected oars and update their rowing/collision state.
    selected_sides = get_selected_sides(control_state)
    oar_position_changed = False

    for side in selected_sides:
        current_oar_position = control_state.oar_positions[side]


        # ---------------------------------------------------------------------
        # COAST AFFECTED ROWERS
        # ---------------------------------------------------------------------
        # Raising or lowering oars leaves that side waiting for a new command.
        if side == "port":
            selected_seats = settings.PORT_SEATS

        else:
            selected_seats = settings.STARBOARD_SEATS

        for seat in selected_seats:
            if seat <= settings.NUMBER_OF_ROWERS:
                control_state.rower_states[seat] = "coast"


        # ---------------------------------------------------------------------
        # OAR POSITION
        # ---------------------------------------------------------------------
        if current_oar_position != oar_position:
            control_state.oar_positions[side] = oar_position
            oar_position_changed = True

    if oar_position_changed:
        control_state.boat_collision_local_points = create_boat_collision_local_points(control_state.oar_positions)

    control_state.selected_group = None


# =============================================================================
# OAR POSITION FOR A SEAT
# =============================================================================
def get_oar_position_for_seat(control_state, seat):
    # Look up whether this rower's oar is down in the water plane or raised.
    if seat in settings.PORT_SEATS:
        return control_state.oar_positions["port"]

    return control_state.oar_positions["starboard"]


def oars_are_down(control_state, seat):
    # Only lowered oars can create rowing or hold-water force.
    return get_oar_position_for_seat(control_state, seat) == "down"


# =============================================================================
# STROKE RATE
# =============================================================================
def change_stroke_rate(control_state, change):
    # Change the rate, then keep it inside the allowed range.
    new_stroke_rate = control_state.stroke_rate + change

    new_stroke_rate = max(settings.MIN_STROKE_RATE, min(settings.MAX_STROKE_RATE, new_stroke_rate))

    control_state.stroke_rate = new_stroke_rate


# =============================================================================
# RUDDER
# =============================================================================
def change_rudder(control_state, change):
    # Change the angle, then keep it inside the physical rudder limits.
    new_rudder_angle = control_state.rudder_angle + change

    new_rudder_angle = max(-settings.MAX_RUDDER_ANGLE, min(settings.MAX_RUDDER_ANGLE, new_rudder_angle))

    control_state.rudder_angle = new_rudder_angle


# =============================================================================
# KEYBOARD EVENT
# =============================================================================
def handle_keyboard_event(control_state, event):
    # Ignore anything that is not a key press.
    if event.type != pygame.KEYDOWN:
        return


    # -------------------------------------------------------------------------
    # PREP COMMANDS
    # -------------------------------------------------------------------------
    if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT, pygame.K_q, pygame.K_p):

        set_prep_command(control_state, event.key)
        return


    # -------------------------------------------------------------------------
    # PREP + EXECUTION COMMANDS
    # -------------------------------------------------------------------------
    if control_state.selected_group is not None:
        if event.key == pygame.K_w:
            apply_rowing_command(control_state, "forward")
            return

        elif event.key == pygame.K_s:
            apply_rowing_command(control_state, "backward")
            return

        elif event.key == pygame.K_SPACE:
            apply_rowing_command(control_state, "coast")
            return

        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            apply_rowing_command(control_state, "hold")
            return

        elif event.key == pygame.K_u:
            apply_oar_position_command(control_state, "up")
            return

        elif event.key == pygame.K_j:
            apply_oar_position_command(control_state, "down")
            return


    # -------------------------------------------------------------------------
    # STROKE RATE
    # -------------------------------------------------------------------------
    if event.key == pygame.K_UP:
        change_stroke_rate(control_state, 1)

    elif event.key == pygame.K_DOWN:
        change_stroke_rate(control_state, -1)


    # -------------------------------------------------------------------------
    # RUDDER
    # -------------------------------------------------------------------------
    elif event.key == pygame.K_LEFT:
        change_rudder(control_state, settings.RUDDER_STEP)

    elif event.key == pygame.K_RIGHT:
        change_rudder(control_state, -settings.RUDDER_STEP)
