"""Renderer-independent stroke clock and per-seat command scheduling.

No Pygame dependency. Input adapters submit commands through CommandManager.
"""

from dataclasses import dataclass


ACTIVE_ACTIONS = ("forward", "backward")
ACTIONS = ("forward", "backward", "coast", "hold")


class StrokeClock:
    """A common drive/recovery phase that changes rate only at cycle boundaries."""

    def __init__(self, stroke_rate):
        self.stroke_rate = stroke_rate
        self.pending_rate = stroke_rate
        self.completed_strokes = 0
        self.phase = 0.0
        self.running = False

    @property
    def stroke_period(self):
        return 60.0 / self.stroke_rate

    def request_rate(self, stroke_rate):
        self.pending_rate = stroke_rate
        if not self.running:
            self.stroke_rate = stroke_rate

    def update(self, dt, active):
        """Return the number of completed cycles, typically zero or one."""
        if not active:
            self.running = False
            self.phase = 0.0
            self.stroke_rate = self.pending_rate
            return 0

        if not self.running:
            self.running = True
            self.phase = 0.0

        completed = 0
        remaining = max(0.0, dt)
        while remaining > 1e-12:
            seconds_to_boundary = (1.0 - self.phase) * self.stroke_period
            step = min(remaining, seconds_to_boundary)
            self.phase += step / self.stroke_period
            remaining -= step
            if self.phase >= 1.0 - 1e-10:
                self.phase = 0.0
                self.completed_strokes += 1
                completed += 1
                self.stroke_rate = self.pending_rate
        return completed

    def is_drive(self, drive_fraction):
        return self.phase < drive_fraction


@dataclass
class SeatInstruction:
    action: str
    mode: str = "continuous"  # continuous, for, in
    count: int = 0
    start_at: int = 0
    finish_at: int = 0
    follow_up: str | None = None


@dataclass
class FollowUpInstruction:
    """A continuous action triggered when a prior FOR instruction finishes."""

    trigger_stroke: int
    seats: tuple
    action: str
    origin_seats: tuple


class CommandManager:
    """Each seat has one independent scheduled instruction and optional follow-up."""

    def __init__(self, rower_states, clock):
        self.rower_states = rower_states
        self.clock = clock
        self.pending = {seat: None for seat in rower_states}
        self.last_seats = ()
        self.last_instruction = None
        self.follow_ups = []
        self.last_for_finish = None

    def any_rowing(self):
        return any(state in ACTIVE_ACTIONS for state in self.rower_states.values())

    def send(self, seats, action, mode="continuous", count=0):
        if action not in ACTIONS or mode not in ("continuous", "for", "in"):
            raise ValueError("Invalid command")
        if mode != "continuous" and not 1 <= count <= 20:
            raise ValueError("Count must be between 1 and 20")

        selected = tuple(seat for seat in seats if seat in self.rower_states)
        self.last_seats = selected
        self.last_instruction = None
        self.last_for_finish = None
        # A newer instruction for any involved seat takes priority over an
        # earlier queued follow-up, whether it was a trigger or target seat.
        selected_set = set(selected)
        self.follow_ups = [follow for follow in self.follow_ups
                           if not selected_set.intersection(follow.seats) and
                           not selected_set.intersection(follow.origin_seats)]
        if not selected:
            return

        # Hold water always overrides schedules immediately, including IN commands.
        if action == "hold" and mode != "in":
            for seat in selected:
                self.pending[seat] = None
                self.rower_states[seat] = "hold"
            return

        active = self.any_rowing()
        now = self.clock.completed_strokes
        for seat in selected:
            # If no one is rowing, IN commands have no meaningful strokes to wait for.
            effective_mode = "continuous" if mode == "in" and not active else mode
            if effective_mode == "continuous" and not active:
                self.rower_states[seat] = action
                self.pending[seat] = None
                continue

            first = now + 1 if active else now
            # IN changes at the boundary following N complete future cycles.
            if effective_mode == "in":
                first = now + count
            finish = first + count if effective_mode == "for" else 0
            instruction = SeatInstruction(action, effective_mode, count, first, finish)
            self.pending[seat] = instruction
            if effective_mode == "for" and not active:
                self.rower_states[seat] = action
            if effective_mode == "for" or effective_mode == "in":
                self.last_instruction = instruction
            if effective_mode == "for":
                self.last_for_finish = finish

        # The last instruction is a marker for Tab; a follow-up applies to all last_seats.

    def set_follow_up(self, seats, action):
        """Schedule one continuous action for ANY seats after the latest FOR.

        The follow-up group is independent of the original group. At the
        finish boundary, original rowers default to coast and the follow-up
        overrides that default for its selected seats.
        """
        if action not in ACTIONS or self.last_for_finish is None:
            return False

        selected = tuple(seat for seat in seats if seat in self.rower_states)
        if not selected:
            return False

        # Replacing the follow-up selection before execution is permitted.
        self.follow_ups = [follow for follow in self.follow_ups
                           if follow.origin_seats != self.last_seats or
                           follow.trigger_stroke != self.last_for_finish]
        self.follow_ups.append(FollowUpInstruction(self.last_for_finish, selected, action, self.last_seats))
        return True

    def update(self):
        """Call at every completed boat cycle BEFORE forces for the next cycle."""
        now = self.clock.completed_strokes
        for seat, instruction in self.pending.items():
            if instruction is None:
                continue
            if instruction.mode == "for" and now >= instruction.finish_at:
                self.rower_states[seat] = "coast"
                self.pending[seat] = None
            elif now >= instruction.start_at:
                self.rower_states[seat] = instruction.action
                if instruction.mode != "for":
                    self.pending[seat] = None

        # Apply follow-ups at the SAME completed-stroke boundary. This must
        # happen after default coasting and must not be delayed by send().
        remaining = []
        for follow in self.follow_ups:
            if now >= follow.trigger_stroke:
                for seat in follow.seats:
                    self.rower_states[seat] = follow.action
                    self.pending[seat] = None
            else:
                remaining.append(follow)
        self.follow_ups = remaining

    def cancel(self, seats):
        selected = set(seats)
        self.follow_ups = [follow for follow in self.follow_ups
                           if not selected.intersection(follow.seats) and
                           not selected.intersection(follow.origin_seats)]
        for seat in selected:
            if seat in self.pending:
                self.pending[seat] = None
