extends Node2D

# ==========================================================================
# TCP CLIENT: Godot never computes boat movement.
# ==========================================================================
const HOST = "127.0.0.1"
const PORT = 28542
const METERS_TO_PIXELS = 5.0
const WATER = Color("#418cab")
const LAND = Color("#52744e")
const SHORE = Color("#b0c99f")
const DOCK = Color("#595d60")
const TRAIL = Color("#173e76")
const COLLISION_BOX = Color("#5f8fc4")
const DOCK_WIDTH_METERS = 3.0
const WATER_EDGE = Color("#75b8ca")
const WATER_HIGHLIGHT = Color(0.78, 0.91, 0.93, 0.18)
const HULL_SHADOW = Color(0.09, 0.22, 0.29, 0.40)
const HULL_DECK = Color("#d7e3e8")
const WAKE_COLOR = Color(0.87, 0.96, 0.96, 0.38)

var socket := StreamPeerTCP.new()
var received_text := ""
var shoreline: Array = []
var docks: Array = []
var bridges: Array = []
var course_setting := "park"
var course_menu: PanelContainer
var course_selected := false
var smooth_shoreline: Array = []
var hull_length_m := 17.7
var hull_width_m := 0.53
var geometric_center_m := 0.0
var seat_offset_m := 0.46
var oar_span_m := 0.85
var oar_outboard_m := 2.69
var oar_blade_length_m := 0.46
var oar_max_sweep_deg := 32.0
var oar_coast_sweep_deg := 18.0
var oar_raised_reach_m := 3.77
var drive_fraction := 0.33
var rower_names: Dictionary = {}
var cox_position_m := -6.0
var seat_positions: Dictionary = {}
var state: Dictionary = {}
var hud: Label
var hud_heading: Label
var status_text: String = "Connecting to Python bridge..."
var is_connected := false
var reconnect_elapsed := 0.0
var show_overview := false
var show_collision_box := true
var overview_center := Vector2.ZERO
var overview_map_size := Vector2.ONE

var collision_notice: PanelContainer
var collision_title: Label
var collision_detail: Label
var collision_hint: Label
var warning_close_button: Button
var dismissed_warning := ""
var previous_warning := ""



func _ready() -> void:
    hud = Label.new()
    hud.position = Vector2.ZERO
    hud.add_theme_color_override("font_color", Color.WHITE)
    hud.add_theme_color_override("font_shadow_color", Color.BLACK)
    hud.add_theme_constant_override("shadow_offset_x", 1)
    hud.add_theme_constant_override("shadow_offset_y", 1)
    hud.add_theme_font_size_override("font_size", 15)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hud)
    hud_heading = Label.new()
    hud_heading.text = "ROWING STATUS"
    hud_heading.add_theme_color_override("font_color", Color.WHITE)
    hud_heading.add_theme_color_override("font_shadow_color", Color.BLACK)
    hud_heading.add_theme_constant_override("shadow_offset_x", 1)
    hud_heading.add_theme_constant_override("shadow_offset_y", 1)
    hud_heading.add_theme_font_size_override("font_size", 18)
    var bold_heading_font = SystemFont.new()
    bold_heading_font.font_weight = 700
    hud_heading.add_theme_font_override("font", bold_heading_font)
    hud_heading.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hud_heading)
    setup_collision_notice()
    setup_course_menu()
    socket.connect_to_host(HOST, PORT)


# =========================================================================
# PYTHON BRIDGE AND FRAME UPDATES
# =========================================================================
func _process(delta: float) -> void:
    socket.poll()
    if socket.get_status() == StreamPeerTCP.STATUS_CONNECTED:
        is_connected = true
        while socket.get_available_bytes() > 0:
            received_text += socket.get_utf8_string(socket.get_available_bytes())
        var newline = received_text.find("\n")
        while newline >= 0:
            var record = received_text.substr(0, newline)
            received_text = received_text.substr(newline + 1)
            var parsed = JSON.parse_string(record)
            if parsed is Dictionary:
                if parsed.get("type") == "course":
                    bridges = parsed.get("bridges", [])
                    course_setting = str(parsed.get("setting", "park"))
                    course_selected = true
                    course_menu.visible = false
                    state.clear()
                    shoreline = parsed.get("shoreline", [])
                    docks = parsed.get("docks", [])
                    hull_length_m = float(parsed.get("hull_length_m", 17.7))
                    hull_width_m = float(parsed.get("hull_width_m", 0.53))
                    geometric_center_m = float(parsed.get("geometric_center_m", 0.0))
                    seat_offset_m = float(parsed.get("seat_offset_m", 0.46))
                    oar_span_m = float(parsed.get("oar_span_m", 0.85))
                    oar_outboard_m = float(parsed.get("oar_outboard_m", 2.69))
                    oar_blade_length_m = float(parsed.get("oar_blade_length_m", 0.46))
                    oar_max_sweep_deg = float(parsed.get("oar_max_sweep_deg", 32.0))
                    oar_coast_sweep_deg = float(parsed.get("oar_coast_sweep_deg", 18.0))
                    oar_raised_reach_m = float(parsed.get("oar_raised_reach_m", 3.77))
                    drive_fraction = float(parsed.get("drive_fraction", 0.33))
                    rower_names = parsed.get("rower_names", {})
                    cox_position_m = float(parsed.get("cox_position_m", -6.0))
                    seat_positions = parsed.get("seat_positions", {})
                    # Geometry is smoothed once in Python, never per frame.
                    smooth_shoreline = parsed.get("visual_shoreline", [])
                    if smooth_shoreline.is_empty():
                        smooth_shoreline = soften_shoreline(shoreline)
                    update_overview_bounds()
                elif parsed.get("type") == "state":
                    state = parsed
            newline = received_text.find("\n")
        status_text = "Connected — Python physics engine"
    elif socket.get_status() == StreamPeerTCP.STATUS_NONE or socket.get_status() == StreamPeerTCP.STATUS_ERROR:
        is_connected = false
        status_text = "Start Python bridge: python godot_bridge.py"
        reconnect_elapsed += delta
        if reconnect_elapsed >= 2.0:
            reconnect_elapsed = 0.0
            socket = StreamPeerTCP.new()
            socket.connect_to_host(HOST, PORT)

    hud.visible = course_selected
    hud_heading.visible = course_selected
    if not course_selected:
        collision_notice.visible = false
        queue_redraw()
        return
    update_rowing_hud()
    update_collision_notice()
    queue_redraw()


# Right-side rowing-status HUD, matching the Pygame control HUD.
# =========================================================================
# ROWING STATUS HEADS-UP DISPLAY
# =========================================================================
func update_rowing_hud() -> void:
    var lines: Array[String] = []
    var rowers: Dictionary = state.get("rower_states", {})
    var commands: Dictionary = state.get("seat_commands", {})
    for seat_number in range(1, 9):
        var seat = str(seat_number)
        var display_name = str(rower_names.get(seat, "Seat " + seat))
        var action = str(rowers.get(seat, "coast")).capitalize()
        var line = display_name + ": " + action
        if commands.has(seat):
            var instruction: Dictionary = commands[seat]
            line += " (%s %d)" % [str(instruction.get("mode", "")), int(instruction.get("remaining", 0))]
        lines.append(line)

    var positions: Dictionary = state.get("oar_positions", {})
    lines.append("")
    lines.append("Port Oars: " + str(positions.get("port", "down")).capitalize())
    lines.append("Starboard Oars: " + str(positions.get("starboard", "down")).capitalize())
    lines.append("")
    lines.append("Stroke Rate: %d spm" % int(state.get("stroke_rate", 25)))
    var rudder = float(state.get("rudder_angle", 0.0))
    if rudder > 0.0:
        lines.append("Rudder: %.0f degrees Port" % abs(rudder))
    elif rudder < 0.0:
        lines.append("Rudder: %.0f degrees Starboard" % abs(rudder))
    else:
        lines.append("Rudder: 0 degrees")

    lines.append("")
    var average_speed = float(state.get("average_speed_5s", 0.0))
    lines.append("Average Speed (5s): %.2f m/s" % average_speed)
    if average_speed > 0.01:
        var split_seconds = 500.0 / average_speed
        var minutes = int(split_seconds / 60.0)
        var seconds = int(round(fmod(split_seconds, 60.0)))
        if seconds >= 60:
            minutes += 1
            seconds = 0
        lines.append("500m Split: %d:%02d" % [minutes, seconds])
    else:
        lines.append("500m Split: --:--")
    lines.append("COM Distance: %.1f m" % float(state.get("distance_m", 0.0)))

    var prepared = str(state.get("prepared", ""))
    if prepared != "":
        lines.append("")
        lines.append("Prepared: " + prepared)

    hud.text = "\n".join(lines)
    hud.size = Vector2.ZERO
    var hud_width = hud.get_combined_minimum_size().x
    var heading_width = hud_heading.get_combined_minimum_size().x
    var right_edge = get_viewport_rect().size.x - 20.0
    hud_heading.position = Vector2(max(8.0, right_edge - heading_width), 20.0)
    hud.position = Vector2(max(8.0, right_edge - hud_width), 20.0 + hud_heading.get_combined_minimum_size().y)


# Collision notices are UI controls, not map drawings, so they stay fixed
# on screen in both camera modes. The Python simulation owns their state.
# =========================================================================
# COLLISION POPUPS
# =========================================================================
func setup_collision_notice() -> void:
    collision_notice = PanelContainer.new()
    collision_notice.visible = false
    collision_notice.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(collision_notice)

    var content = VBoxContainer.new()
    content.add_theme_constant_override("separation", 7)
    collision_notice.add_child(content)

    var heading_row = HBoxContainer.new()
    content.add_child(heading_row)

    collision_title = Label.new()
    collision_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    collision_title.add_theme_font_size_override("font_size", 19)
    collision_title.add_theme_color_override("font_color", Color.WHITE)
    heading_row.add_child(collision_title)

    warning_close_button = Button.new()
    warning_close_button.text = "X"
    warning_close_button.tooltip_text = "Dismiss collision warning"
    warning_close_button.pressed.connect(dismiss_collision_warning)
    heading_row.add_child(warning_close_button)

    collision_detail = Label.new()
    collision_detail.add_theme_color_override("font_color", Color.WHITE)
    collision_detail.add_theme_font_size_override("font_size", 15)
    content.add_child(collision_detail)

    collision_hint = Label.new()
    collision_hint.add_theme_color_override("font_color", Color.WHITE)
    collision_hint.add_theme_font_size_override("font_size", 13)
    content.add_child(collision_hint)


func dismiss_collision_warning() -> void:
    var warning_value = state.get("warning", null)
    dismissed_warning = warning_value if warning_value is String else ""
    update_collision_notice()


func update_collision_notice() -> void:
    # The Python snapshot sends JSON null when no collision occurred.
    # In Godot, str(null) is "<null>", not an empty string.
    var crash_value = state.get("crash", null)
    var warning_value = state.get("warning", null)
    var crash_message = crash_value if crash_value is String else ""
    var warning_message = warning_value if warning_value is String else ""
    var is_docked = bool(state.get("docked", false))

    if warning_message != previous_warning:
        dismissed_warning = ""
        previous_warning = warning_message

    var title = ""
    var detail = ""
    var hint = ""
    var background_color = Color("#836118")

    if crash_message != "":
        title = "CRASH - SIMULATION FROZEN"
        detail = crash_message
        hint = "Press R to reset."
        background_color = Color("#781919")
    elif warning_message != "" and warning_message != dismissed_warning:
        title = "COLLISION WARNING"
        detail = warning_message
        hint = "Dismiss with X."
        background_color = Color("#91641c")
    elif is_docked:
        title = "DOCKED"
        background_color = Color("#236e37")

    collision_notice.visible = title != ""
    if not collision_notice.visible:
        return

    collision_title.text = title
    collision_detail.text = detail
    collision_hint.text = hint
    warning_close_button.visible = title == "COLLISION WARNING"
    collision_detail.visible = detail != ""
    collision_hint.visible = hint != ""

    var panel_style = StyleBoxFlat.new()
    panel_style.bg_color = background_color
    panel_style.border_color = Color.WHITE
    panel_style.set_border_width_all(2)
    panel_style.set_corner_radius_all(5)
    panel_style.content_margin_left = 16.0
    panel_style.content_margin_right = 16.0
    panel_style.content_margin_top = 11.0
    panel_style.content_margin_bottom = 11.0
    collision_notice.add_theme_stylebox_override("panel", panel_style)

    collision_notice.custom_minimum_size.x = 460.0 if title != "DOCKED" else 220.0
    collision_notice.reset_size()
    var screen_width = get_viewport_rect().size.x
    collision_notice.position = Vector2(max(8.0, (screen_width - collision_notice.size.x) / 2.0), 64.0 if title != "DOCKED" else 12.0)


# =========================================================================
# COURSE SELECTION SCREEN
# =========================================================================
func setup_course_menu() -> void:
    course_menu = PanelContainer.new()
    course_menu.position = Vector2(340, 165)
    course_menu.custom_minimum_size = Vector2(520, 420)
    add_child(course_menu)
    var backdrop = StyleBoxFlat.new()
    backdrop.bg_color = Color("#203448")
    backdrop.set_corner_radius_all(12)
    backdrop.set_content_margin_all(28)
    course_menu.add_theme_stylebox_override("panel", backdrop)
    var layout = VBoxContainer.new()
    layout.add_theme_constant_override("separation", 16)
    course_menu.add_child(layout)
    var heading = Label.new()
    heading.text = "COXSWAIN SIMULATOR"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 29)
    heading.add_theme_color_override("font_color", Color.WHITE)
    layout.add_child(heading)
    var prompt = Label.new()
    prompt.text = "Select a course to begin"
    prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    prompt.add_theme_color_override("font_color", Color("#b8d2e6"))
    layout.add_child(prompt)
    var choices = {
        "max": "Lake Maxinkuckee",
        "charles": "Head of the Charles",
        "nathan": "Nathan Benderson Park",
        "milwaukee": "Milwaukee River"
    }
    for course_id in choices:
        var button = Button.new()
        button.text = choices[course_id]
        button.custom_minimum_size.y = 52
        button.pressed.connect(select_course.bind(course_id))
        layout.add_child(button)


func select_course(course_id: String) -> void:
    if socket.get_status() == StreamPeerTCP.STATUS_CONNECTED:
        send_message({"type": "select_course", "course_id": course_id})


# =========================================================================
# URBAN SCENERY AND BRIDGES
# =========================================================================
func draw_urban_land(dimensions: Vector2) -> void:
    # Lightweight world-anchored city blocks: scenery follows camera movement.
    # Limit drawing to the nearby map region instead of covering entire rivers.
    var boat_x = float(state.get("x", 0.0))
    var boat_y = float(state.get("y", 0.0))
    var spacing = 70.0
    var scale = max(0.2, get_overview_scale() if show_overview else METERS_TO_PIXELS * zoom_scale)
    var reach = max(dimensions.x, dimensions.y) / scale * 0.75 + spacing
    if show_overview:
        reach = max(overview_map_size.x, overview_map_size.y) * 0.55
        boat_x = overview_center.x
        boat_y = overview_center.y
    # Cap large overviews to keep scene rendering responsive.
    var start_x = int(floor((boat_x - reach) / spacing))
    var stop_x = int(ceil((boat_x + reach) / spacing))
    var start_y = int(floor((boat_y - reach) / spacing))
    var stop_y = int(ceil((boat_y + reach) / spacing))
    if (stop_x - start_x) * (stop_y - start_y) > 1600:
        return
    for ix in range(start_x, stop_x):
        for iy in range(start_y, stop_y):
            var wx = float(ix) * spacing + 8.0
            var wy = float(iy) * spacing + 8.0
            var corners = PackedVector2Array([
                to_screen([wx, wy]), to_screen([wx + 52.0, wy]),
                to_screen([wx + 52.0, wy + 50.0]), to_screen([wx, wy + 50.0])])
            var index = posmod(ix * 17 + iy * 23, 5)
            var building_color = Color("#818586") if index < 2 else Color("#a2a49d")
            draw_colored_polygon(corners, building_color)
            draw_polyline(PackedVector2Array([corners[0], corners[1], corners[2], corners[3], corners[0]]), Color("#566266"), 1.0, true)


func draw_bridges() -> void:
    # Python sends one four-corner deck for each grouped bridge structure.
    # Rendering a complete polygon avoids stripes from overlapping map ways.
    for bridge in bridges:
        var world_polygon = bridge.get("polygon", [])
        if world_polygon.size() < 3:
            continue

        var deck_polygon = PackedVector2Array()
        for point in world_polygon:
            deck_polygon.append(to_screen(point))

        var shadow_polygon = PackedVector2Array()
        for vertex in deck_polygon:
            shadow_polygon.append(vertex + Vector2(2.0, 3.0))

        var kind = str(bridge.get("kind", "road"))
        var deck_color = Color("#979c97")
        if kind == "rail":
            deck_color = Color("#857c73")
        elif kind == "pedestrian":
            deck_color = Color("#b7b1a5")

        draw_colored_polygon(shadow_polygon, Color(0.30, 0.39, 0.42, 0.6))
        draw_colored_polygon(deck_polygon, deck_color)
        var edge = deck_polygon.duplicate()
        edge.append(deck_polygon[0])
        draw_polyline(edge, Color("#626a6b"), 1.1, true)

        var scale = get_overview_scale() if show_overview else METERS_TO_PIXELS * zoom_scale
        if scale >= 1.3:
            draw_line(deck_polygon[0], deck_polygon[1], Color("#cdcac0"), 1.0, true)
            draw_line(deck_polygon[2], deck_polygon[3], Color("#cdcac0"), 1.0, true)


# =========================================================================
# KEYBOARD INPUT AND BRIDGE MESSAGES
# =========================================================================
func _input(event: InputEvent) -> void:
    if not course_selected:
        return
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    var name = ""
    match event.keycode:
        KEY_SHIFT: name = "SHIFT"
        KEY_CTRL: name = "CTRL"
        KEY_ALT: name = "ALT"
        KEY_TAB: name = "TAB"
        KEY_B:
            show_collision_box = not show_collision_box
            queue_redraw()
            return
        KEY_M:
            show_overview = not show_overview
            queue_redraw()
            return
        KEY_QUOTELEFT: name = "BACKTICK"
        KEY_ENTER, KEY_KP_ENTER: name = "ENTER"
        KEY_SPACE: name = "SPACE"
        KEY_UP: name = "UP"
        KEY_DOWN: name = "DOWN"
        KEY_LEFT: name = "LEFT"
        KEY_RIGHT: name = "RIGHT"
        KEY_R:
            send_message({"type": "reset"})
            return
        KEY_EQUAL, KEY_KP_ADD:
            show_overview = false
            zoom_scale = min(zoom_scale * 1.2, 15.0)
            return
        KEY_MINUS, KEY_KP_SUBTRACT:
            show_overview = false
            zoom_scale = max(zoom_scale / 1.2, 0.5)
            return
        _:
            name = OS.get_keycode_string(event.keycode).to_upper()
    if name != "":
        send_message({"type": "key", "key": name})


func send_message(message: Dictionary) -> void:
    if socket.get_status() == StreamPeerTCP.STATUS_CONNECTED:
        socket.put_data((JSON.stringify(message) + "\n").to_utf8_buffer())


var zoom_scale := 1.0

# =========================================================================
# CAMERA AND COURSE GEOMETRY
# =========================================================================
func to_screen(point: Array) -> Vector2:
    if show_overview:
        var map_center = Vector2(float(point[0]), float(point[1])) - overview_center
        return get_viewport_rect().size * 0.5 + Vector2(map_center.x, -map_center.y) * get_overview_scale()
    var center = get_viewport_rect().size * 0.5
    var x = float(point[0]) - float(state.get("x", 0.0))
    var y = float(point[1]) - float(state.get("y", 0.0))
    var heading = float(state.get("heading", 0.0))
    var forward = x * cos(heading) + y * sin(heading)
    var sideways = -x * sin(heading) + y * cos(heading)
    # Match graphics.py: positive sideways is port and appears screen-left.
    return center + Vector2(-sideways, -forward) * METERS_TO_PIXELS * zoom_scale


# Fit the entire mapped shoreline into the window with space for the HUD.
func update_overview_bounds() -> void:
    if shoreline.is_empty():
        return
    var min_x = INF
    var max_x = -INF
    var min_y = INF
    var max_y = -INF
    for point in shoreline:
        var x = float(point[0])
        var y = float(point[1])
        min_x = min(min_x, x)
        max_x = max(max_x, x)
        min_y = min(min_y, y)
        max_y = max(max_y, y)
    overview_center = Vector2((min_x + max_x) * 0.5, (min_y + max_y) * 0.5)
    var map_width = max(1.0, max_x - min_x)
    var map_height = max(1.0, max_y - min_y)
    # Reserve some room at the right for the rowing HUD.
    overview_map_size = Vector2(map_width, map_height)


func get_overview_scale() -> float:
    var viewport = get_viewport_rect().size
    return min(max(1.0, viewport.x - 300.0) / overview_map_size.x, max(1.0, viewport.y - 100.0) / overview_map_size.y)


# Visual smoothing only. Keep original source geometry for dock clipping/collisions.
# A conservative Chaikin corner-cut preserves the recognizable lake outline.
func soften_shoreline(source: Array) -> Array:
    if source.size() < 4:
        return source.duplicate()
    var vertices: Array = []
    for point in source:
        vertices.append(Vector2(float(point[0]), float(point[1])))
    for iteration in range(2):
        var next_vertices: Array = []
        for i in range(vertices.size()):
            var a: Vector2 = vertices[i]
            var b: Vector2 = vertices[(i + 1) % vertices.size()]
            next_vertices.append(a.lerp(b, 0.16))
            next_vertices.append(a.lerp(b, 0.84))
        vertices = next_vertices
    var result: Array = []
    for vertex in vertices:
        result.append([vertex.x, vertex.y])
    return result


# =========================================================================
# MAP MATERIALS AND DOCK SURFACES
# =========================================================================
func build_gradient_colors(points: PackedVector2Array, top_color: Color, bottom_color: Color) -> PackedColorArray:
    var colors = PackedColorArray()
    if points.is_empty():
        return colors
    var min_y = INF
    var max_y = -INF
    for point in points:
        min_y = min(min_y, point.y)
        max_y = max(max_y, point.y)
    var span = max(1.0, max_y - min_y)
    for point in points:
        var t = clamp((point.y - min_y) / span, 0.0, 1.0)
        colors.append(top_color.lerp(bottom_color, t))
    return colors


func draw_land_texture(dimensions: Vector2) -> void:
    for offset in range(-int(dimensions.y), int(dimensions.x + dimensions.y), 88):
        draw_line(Vector2(offset, 0.0), Vector2(offset + dimensions.y, dimensions.y), Color(0.34, 0.43, 0.31, 0.10), 2.0, true)
    for offset in range(-int(dimensions.y), int(dimensions.x + dimensions.y), 128):
        draw_line(Vector2(offset, dimensions.y), Vector2(offset + dimensions.y, 0.0), Color(0.67, 0.74, 0.58, 0.05), 1.0, true)


func draw_water_surface(visual_outline: PackedVector2Array) -> void:
    if visual_outline.size() < 3:
        return
    draw_polygon(visual_outline, build_gradient_colors(visual_outline, Color("#6baec4"), Color("#3c7f97")))
    var closed_outline = visual_outline.duplicate()
    closed_outline.append(visual_outline[0])
    draw_polyline(closed_outline, Color("#9fd4dc"), 6.0, true)
    draw_polyline(closed_outline, Color("#e1ecd2"), 1.4, true)

    # Avoid sampling the full lake's screen-space bounding box every frame.
    # Soft surface shading and the narrow shoreline bands remain inexpensive.


func build_dock_polygon(dock: Array, half_width: float) -> PackedVector2Array:
    var screen_points: Array[Vector2] = []
    for point in dock:
        screen_points.append(to_screen(point))
    if screen_points.size() < 2:
        return PackedVector2Array()

    var left_side = PackedVector2Array()
    var right_side = PackedVector2Array()
    for index in range(screen_points.size()):
        var current: Vector2 = screen_points[index]
        var normal = Vector2.ZERO
        if index == 0:
            var first_direction = (screen_points[1] - current).normalized()
            normal = Vector2(-first_direction.y, first_direction.x)
        elif index == screen_points.size() - 1:
            var last_direction = (current - screen_points[index - 1]).normalized()
            normal = Vector2(-last_direction.y, last_direction.x)
        else:
            var previous_direction = (current - screen_points[index - 1]).normalized()
            var next_direction = (screen_points[index + 1] - current).normalized()
            var previous_normal = Vector2(-previous_direction.y, previous_direction.x)
            var next_normal = Vector2(-next_direction.y, next_direction.x)
            normal = previous_normal + next_normal
            if normal.length_squared() < 0.0001:
                normal = next_normal
            else:
                normal = normal.normalized()
                var scale = normal.dot(next_normal)
                if abs(scale) > 0.25:
                    normal /= scale
        left_side.append(current + normal * half_width)
        right_side.append(current - normal * half_width)

    var polygon = PackedVector2Array()
    for point in left_side:
        polygon.append(point)
    for reverse_index in range(right_side.size() - 1, -1, -1):
        polygon.append(right_side[reverse_index])
    return polygon


func draw_dock_planks(dock: Array, half_width: float) -> void:
    if dock.size() < 2:
        return
    var plank_spacing = max(10.0, half_width * 2.4)
    for segment_index in range(dock.size() - 1):
        var a = to_screen(dock[segment_index])
        var b = to_screen(dock[segment_index + 1])
        var difference = b - a
        var length = difference.length()
        if length < 0.001:
            continue
        var tangent = difference / length
        var normal = Vector2(-tangent.y, tangent.x)
        var distance_along = plank_spacing * 0.5
        while distance_along < length:
            var center = a + tangent * distance_along
            draw_line(center - normal * half_width * 0.8, center + normal * half_width * 0.8, Color("#9ea89f"), 1.0, true)
            distance_along += plank_spacing


func draw_shore_scrub(visual_outline: PackedVector2Array) -> void:
    if visual_outline.size() < 3:
        return
    var point_step = max(8, int(visual_outline.size() / 70))
    for index in range(0, visual_outline.size(), point_step):
        var point = visual_outline[index]
        draw_circle(point + Vector2(2.5, -1.5), 1.4, Color(0.78, 0.84, 0.63, 0.18))
        draw_circle(point + Vector2(-3.0, 1.0), 1.6, Color(0.35, 0.48, 0.29, 0.14))


func draw_stern_wake(stern_center: Vector2, px_per_meter: float, boat_speed: float) -> void:
    if boat_speed <= 0.35:
        return
    var wake_length = min(18.0, 4.0 + boat_speed * 2.2) * px_per_meter
    var wake_alpha = min(0.24, 0.08 + boat_speed * 0.04)
    for arc_index in range(1, 5):
        var radius = 2.0 + float(arc_index) * 2.6
        var arc_center = stern_center + Vector2(0.0, 4.0 + wake_length * float(arc_index) / 6.0)
        draw_arc(arc_center, radius, PI * 0.12, PI * 0.88, 18, Color(0.95, 0.99, 0.99, wake_alpha / float(arc_index)), 1.2, true)
    var foam_color = Color(0.92, 0.98, 0.99, wake_alpha * 0.8)
    var foam_left = stern_center + Vector2(-3.2, wake_length * 0.45)
    var foam_right = stern_center + Vector2(3.2, wake_length * 0.45)
    draw_line(stern_center + Vector2(-0.6, 1.0), foam_left, foam_color, 1.0, true)
    draw_line(stern_center + Vector2(0.6, 1.0), foam_right, foam_color, 1.0, true)


# =========================================================================
# MAIN OVERHEAD DRAW
# =========================================================================
func _draw() -> void:
    var dimensions = get_viewport_rect().size
    draw_rect(Rect2(Vector2.ZERO, dimensions), Color("#6b7774") if course_setting == "urban" else LAND)
    if course_setting == "urban":
        draw_urban_land(dimensions)
    else:
        draw_land_texture(dimensions)

    var shoreline_outline = PackedVector2Array()
    var visual_outline = PackedVector2Array()
    if shoreline.size() >= 3:
        for point in shoreline:
            shoreline_outline.append(to_screen(point))
        for point in smooth_shoreline:
            visual_outline.append(to_screen(point))
        draw_water_surface(visual_outline)
        draw_shore_scrub(visual_outline)

    if shoreline_outline.size() >= 3:
        var dock_half_width = max(2.0, DOCK_WIDTH_METERS * (get_overview_scale() if show_overview else METERS_TO_PIXELS * zoom_scale)) / 2.0
        for dock in docks:
            if dock.size() < 2:
                continue
            var dock_polygon = build_dock_polygon(dock, dock_half_width)
            for visible_piece in Geometry2D.intersect_polygons(dock_polygon, shoreline_outline):
                if visible_piece.size() >= 3:
                    draw_polygon(visible_piece, build_gradient_colors(visible_piece, Color("#847c70"), Color("#5f5a53")))
                    var edge = visible_piece.duplicate()
                    edge.append(visible_piece[0])
                    draw_polyline(edge, Color("#3d3a36"), 1.1, true)
            draw_dock_planks(dock, dock_half_width)

    draw_bridges()

    if state.has("trail"):
        var path = PackedVector2Array()
        for point in state["trail"]:
            path.append(to_screen(point))
        if path.size() >= 2:
            draw_polyline(path, TRAIL, 3.0, true)

    if show_collision_box and state.has("collision_box"):
        var collision_outline = PackedVector2Array()
        for point in state["collision_box"]:
            collision_outline.append(to_screen(point))
        if collision_outline.size() >= 3:
            collision_outline.append(collision_outline[0])
            draw_polyline(collision_outline, COLLISION_BOX, 2.0, true)

    var middle = dimensions * 0.5
    var px_per_meter = METERS_TO_PIXELS * zoom_scale
    if show_overview:
        var boat_center = to_screen([float(state.get("x", 0.0)), float(state.get("y", 0.0))])
        var heading = float(state.get("heading", 0.0))
        var ahead = Vector2(cos(heading), -sin(heading))
        var right = Vector2(-ahead.y, ahead.x)
        var boat_marker = PackedVector2Array([
            boat_center + ahead * 12.0,
            boat_center - ahead * 8.0 + right * 5.0,
            boat_center - ahead * 8.0 - right * 5.0
        ])
        draw_colored_polygon(boat_marker, Color("#f0f4f7"))
        var marker_border = boat_marker.duplicate()
        marker_border.append(boat_marker[0])
        draw_polyline(marker_border, Color("#173e76"), 2.0, true)
        return

    var hull_half_width = max(2.0, hull_width_m * px_per_meter * 0.5)
    var bow_y = middle.y - (geometric_center_m + hull_length_m * 0.5) * px_per_meter
    var stern_y = middle.y - (geometric_center_m - hull_length_m * 0.5) * px_per_meter
    var shell = PackedVector2Array([
        Vector2(middle.x, bow_y),
        Vector2(middle.x - hull_half_width * 0.78, bow_y + 1.3 * px_per_meter),
        Vector2(middle.x - hull_half_width, bow_y + 3.0 * px_per_meter),
        Vector2(middle.x - hull_half_width, stern_y - 1.9 * px_per_meter),
        Vector2(middle.x - hull_half_width * 0.45, stern_y - 0.4 * px_per_meter),
        Vector2(middle.x, stern_y),
        Vector2(middle.x + hull_half_width * 0.45, stern_y - 0.4 * px_per_meter),
        Vector2(middle.x + hull_half_width, stern_y - 1.9 * px_per_meter),
        Vector2(middle.x + hull_half_width, bow_y + 3.0 * px_per_meter),
        Vector2(middle.x + hull_half_width * 0.78, bow_y + 1.3 * px_per_meter),
    ])

    draw_stern_wake(Vector2(middle.x, stern_y), px_per_meter, float(state.get("speed", 0.0)))

    var hull_shadow = PackedVector2Array()
    for vertex in shell:
        hull_shadow.append(vertex + Vector2(2.0, 2.0))
    draw_colored_polygon(hull_shadow, HULL_SHADOW)
    draw_polygon(shell, build_gradient_colors(shell, Color("#fbfdfd"), Color("#d8e3e8")))
    var border = shell.duplicate()
    border.append(shell[0])
    draw_polyline(border, Color("#253944"), 1.5, true)
    var inner_width = max(1.0, hull_half_width * 0.52)
    draw_line(Vector2(middle.x, bow_y + 7.0 * px_per_meter), Vector2(middle.x, stern_y - 1.1 * px_per_meter), HULL_DECK, inner_width * 2.0)
    draw_line(Vector2(middle.x, bow_y + 5.0 * px_per_meter), Vector2(middle.x, stern_y - 1.1 * px_per_meter), Color("#9cb3bd"), 0.8)

    var rowers: Dictionary = state.get("rower_states", {})
    var positions: Dictionary = state.get("oar_positions", {})
    var phase = float(state.get("stroke_phase", 0.0))
    for seat_number in range(1, 9):
        var seat = str(seat_number)
        if not seat_positions.has(seat):
            continue
        var seat_offset = -seat_offset_m if seat_number % 2 == 0 else seat_offset_m
        var position_m = float(seat_positions[seat]) + seat_offset
        var seat_y = middle.y - position_m * px_per_meter
        var action = str(rowers.get(seat, "coast"))
        var side = -1.0 if seat_number % 2 == 0 else 1.0
        var group = "port" if seat_number % 2 == 0 else "starboard"
        var raised = str(positions.get(group, "down")) == "up"
        var sweep_degrees = oar_coast_sweep_deg
        if raised or action == "hold":
            sweep_degrees = 0.0
        elif action == "forward" or action == "backward":
            if phase < drive_fraction:
                sweep_degrees = oar_max_sweep_deg * (1.0 - 2.0 * phase / drive_fraction)
            else:
                sweep_degrees = oar_max_sweep_deg * (-1.0 + 2.0 * (phase - drive_fraction) / (1.0 - drive_fraction))
            if action == "backward":
                sweep_degrees = -sweep_degrees
        var sweep_angle = deg_to_rad(sweep_degrees)
        var reach = oar_raised_reach_m - oar_span_m if raised else oar_outboard_m
        var blade_length = min(oar_blade_length_m, reach)
        var pivot = Vector2(middle.x + side * oar_span_m * px_per_meter, seat_y)
        var shaft_length = reach - blade_length
        var shaft_offset = Vector2(side * shaft_length * cos(sweep_angle), -shaft_length * sin(sweep_angle))
        var shaft_end = pivot + shaft_offset * px_per_meter
        var end_point = pivot + Vector2(side * reach * cos(sweep_angle), -reach * sin(sweep_angle)) * px_per_meter
        var shaft_color = Color("#ffd700") if raised else Color("#2e333b")
        var blade_color = Color("#ffd700") if raised else Color("#702039")
        draw_line(pivot, shaft_end, shaft_color, max(1.0, 0.055 * px_per_meter))
        draw_line(shaft_end, end_point, blade_color, max(2.0, 0.15 * px_per_meter))
        draw_circle(pivot, max(1.5, 0.10 * px_per_meter), Color("#e6e8e4"))
        var seat_center = Vector2(middle.x + side * 0.16 * px_per_meter, seat_y)
        draw_circle(seat_center, max(2.0, px_per_meter * 0.16), Color("#24495b"))
        draw_circle(seat_center + Vector2(-0.5, -0.5), max(1.0, px_per_meter * 0.06), Color("#c9d6d7"))

    draw_circle(middle, 2.0, Color("#173e76"))
    var cox_y = middle.y - cox_position_m * px_per_meter
    draw_circle(Vector2(middle.x, cox_y), max(3.0, px_per_meter * 0.22), Color("#e15759"))
