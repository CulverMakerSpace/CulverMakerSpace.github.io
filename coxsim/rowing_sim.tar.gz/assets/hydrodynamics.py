import math

import settings


# =============================================================================
# REYNOLDS NUMBER
# =============================================================================
def calculate_reynolds_number(velocity):
    # Reynolds number sets the skin-friction regime for the shell.
    reynolds_number = (abs(velocity) * settings.SHELL_LENGTH / settings.WATER_KINEMATIC_VISCOSITY)

    return reynolds_number


# =============================================================================
# FRICTION COEFFICIENT
# =============================================================================
def calculate_friction_coefficient(reynolds_number):
    if reynolds_number <= 0.0:
        return 0.0


    # -------------------------------------------------------------------------
    # LOW REYNOLDS NUMBER
    # -------------------------------------------------------------------------
    # Use a laminar flat-plate relation while the shell is moving slowly.
    if reynolds_number < 500000.0:
        friction_coefficient = 1.328 / math.sqrt(reynolds_number)

        return friction_coefficient


    # -------------------------------------------------------------------------
    # NORMAL ROWING SPEEDS
    # -------------------------------------------------------------------------
    # Use the ITTC-1957 model-ship friction correlation line.
    logarithm_term = math.log10(reynolds_number) - 2.0
    friction_coefficient = 0.075 / logarithm_term**2

    return friction_coefficient


# =============================================================================
# LONGITUDINAL DRAG
# =============================================================================
def calculate_longitudinal_drag(boat):
    velocity_forward, velocity_sideways = boat.get_velocity_components()

    if velocity_forward == 0.0:
        return 0.0


    # -------------------------------------------------------------------------
    # REYNOLDS NUMBER AND FRICTION
    # -------------------------------------------------------------------------
    reynolds_number = calculate_reynolds_number(velocity_forward)
    friction_coefficient = calculate_friction_coefficient(reynolds_number)


    # -------------------------------------------------------------------------
    # FRICTIONAL RESISTANCE
    # -------------------------------------------------------------------------
    drag_magnitude = (0.5 * settings.WATER_DENSITY * friction_coefficient * settings.WETTED_SURFACE_AREA * velocity_forward**2)


    # -------------------------------------------------------------------------
    # DIRECTION
    # -------------------------------------------------------------------------
    # Longitudinal drag always opposes forward or reverse motion.
    if velocity_forward > 0.0:
        return -drag_magnitude

    else:
        return drag_magnitude


# =============================================================================
# LATERAL DRAG FORCE
# =============================================================================
def calculate_lateral_drag_force(velocity_sideways, area, drag_coefficient):
    # Calculate broadside drag for one lateral velocity component.
    drag_magnitude = (0.5 * settings.WATER_DENSITY * drag_coefficient * area * velocity_sideways**2)

    if velocity_sideways > 0.0:
        return -drag_magnitude

    elif velocity_sideways < 0.0:
        return drag_magnitude

    else:
        return 0.0


# =============================================================================
# HULL SIDESLIP FORCE
# =============================================================================
def calculate_hull_sideslip_force(velocity_forward, velocity_sideways, area):
    # Model side force caused by the shell moving through the water at an angle.
    water_speed = math.sqrt(velocity_forward**2 + velocity_sideways**2)

    if water_speed == 0.0:
        return 0.0


    # -------------------------------------------------------------------------
    # SIDESLIP ANGLE
    # -------------------------------------------------------------------------
    sideslip_angle = math.atan2(velocity_sideways, abs(velocity_forward))


    # -------------------------------------------------------------------------
    # SIDE FORCE COEFFICIENT
    # -------------------------------------------------------------------------
    side_force_coefficient = (settings.HULL_SIDESLIP_FORCE_SLOPE * sideslip_angle)

    side_force_coefficient = max(
        -settings.HULL_MAX_SIDESLIP_FORCE_COEFFICIENT,
        min(settings.HULL_MAX_SIDESLIP_FORCE_COEFFICIENT, side_force_coefficient))


    # -------------------------------------------------------------------------
    # SIDE FORCE
    # -------------------------------------------------------------------------
    sideslip_force = (-0.5 * settings.WATER_DENSITY * water_speed**2 * area * side_force_coefficient)

    return sideslip_force


# =============================================================================
# SECTION LATERAL FORCE
# =============================================================================
def calculate_section_lateral_force(boat, section):
    velocity_forward, velocity_sideways = boat.get_velocity_components()

    rotational_sideways_velocity = (boat.angular_velocity * section["position"])


    # -------------------------------------------------------------------------
    # SIDEWAYS TRANSLATION DRAG
    # -------------------------------------------------------------------------
    translational_drag = calculate_lateral_drag_force(velocity_sideways, section["lateral_area"], settings.LATERAL_DRAG_COEFFICIENT)


    # -------------------------------------------------------------------------
    # ROTATIONAL DRAG
    # -------------------------------------------------------------------------
    rotational_drag = calculate_lateral_drag_force(
        rotational_sideways_velocity,
        section["lateral_area"],
        settings.ROTATIONAL_LATERAL_DRAG_COEFFICIENT)


    # -------------------------------------------------------------------------
    # SIDESLIP FORCE
    # -------------------------------------------------------------------------
    sideslip_force = calculate_hull_sideslip_force(velocity_forward, velocity_sideways, section["lateral_area"])


    # -------------------------------------------------------------------------
    # TOTAL LATERAL FORCE
    # -------------------------------------------------------------------------
    lateral_force = translational_drag + rotational_drag + sideslip_force

    return lateral_force


# =============================================================================
# STEERING SURFACE LOCAL VELOCITY
# =============================================================================
def calculate_steering_surface_velocity(boat):
    # Find the local water velocity at the rudder/skeg position.
    velocity_forward, velocity_sideways = boat.get_velocity_components()

    rotational_sideways_velocity = (boat.angular_velocity * settings.STEERING_LEVER_ARM)

    steering_sideways_velocity = (velocity_sideways + rotational_sideways_velocity)

    return velocity_forward, steering_sideways_velocity


# =============================================================================
# STEERING SURFACE FORCE
# =============================================================================
def calculate_steering_surface_force(boat, surface_angle, surface_area, lift_slope, maximum_lift_coefficient):

    velocity_forward, velocity_sideways = calculate_steering_surface_velocity(boat)

    water_speed = math.sqrt(velocity_forward**2 + velocity_sideways**2)

    if water_speed == 0.0:
        return 0.0


    # -------------------------------------------------------------------------
    # SURFACE ANGLE
    # -------------------------------------------------------------------------
    surface_angle_radians = math.radians(surface_angle)

    if velocity_forward < 0.0:
        surface_angle_radians = -surface_angle_radians


    # -------------------------------------------------------------------------
    # LOCAL FLOW ANGLE
    # -------------------------------------------------------------------------
    flow_angle = math.atan2(velocity_sideways, abs(velocity_forward))

    angle_of_attack = surface_angle_radians + flow_angle


    # -------------------------------------------------------------------------
    # LIFT COEFFICIENT
    # -------------------------------------------------------------------------
    lift_coefficient = lift_slope * angle_of_attack

    lift_coefficient = max(-maximum_lift_coefficient, min(maximum_lift_coefficient, lift_coefficient))


    # -------------------------------------------------------------------------
    # SIDEWAYS FORCE
    # -------------------------------------------------------------------------
    force_sideways = (-0.5 * settings.WATER_DENSITY * water_speed**2 * surface_area * lift_coefficient)

    return force_sideways


# =============================================================================
# RUDDER FORCE
# =============================================================================
def calculate_rudder_force(boat, rudder_angle):
    # Apply the shared steering-surface model using rudder properties.
    rudder_force = calculate_steering_surface_force(
        boat,
        rudder_angle,
        settings.RUDDER_AREA,
        settings.RUDDER_LIFT_SLOPE,
        settings.RUDDER_MAX_LIFT_COEFFICIENT)

    return rudder_force


# =============================================================================
# SKEG FORCE
# =============================================================================
def calculate_skeg_force(boat):
    # The skeg uses the same force model but remains fixed at zero angle.
    skeg_force = calculate_steering_surface_force(
        boat,
        0.0,
        settings.SKEG_AREA,
        settings.SKEG_LIFT_SLOPE,
        settings.SKEG_MAX_LIFT_COEFFICIENT)

    return skeg_force
