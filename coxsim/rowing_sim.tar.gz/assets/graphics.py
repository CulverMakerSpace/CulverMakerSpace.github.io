import math

import pygame  # type: ignore[reportMissingImports]

import course
import settings


# =============================================================================
# CAMERA
# =============================================================================
class Camera:
    def __init__(self):
        # Start in follow mode using the normal world-to-screen scale.
        self.x = 0.0
        self.y = 0.0
        self.heading = 0.0
        self.zoom = settings.PIXELS_PER_METER
        self.show_overview = False


    # =========================================================================
    # FOLLOW BOAT
    # =========================================================================
    def follow(self, boat):
        # Keep the boat centered and store its heading so the follow view can rotate with it.
        self.x = boat.x
        self.y = boat.y
        self.heading = boat.heading


    # =========================================================================
    # CHANGE ZOOM
    # =========================================================================
    def change_zoom(self, multiplier):
        # Manual zoom always returns the camera to normal follow mode.
        self.show_overview = False
        self.zoom *= multiplier

        self.zoom = max(settings.CAMERA_MIN_ZOOM, min(settings.CAMERA_MAX_ZOOM, self.zoom))


    # =========================================================================
    # TOGGLE OVERVIEW
    # =========================================================================
    def toggle_overview(self):
        self.show_overview = not self.show_overview


    # =========================================================================
    # GET CURRENT VIEW
    # =========================================================================
    def get_view(self):
        # Normal mode uses the camera position and user-selected zoom.
        if not self.show_overview:
            return self.x, self.y, self.zoom


        # ---------------------------------------------------------------------
        # FULL-LAKE OVERVIEW
        # ---------------------------------------------------------------------
        map_width = course.MAX_X - course.MIN_X
        map_height = course.MAX_Y - course.MIN_Y

        horizontal_zoom = (settings.WINDOW_WIDTH - 140) / map_width
        vertical_zoom = (settings.WINDOW_HEIGHT - 100) / map_height
        overview_zoom = min(horizontal_zoom, vertical_zoom)

        center_x = (course.MIN_X + course.MAX_X) / 2
        center_y = (course.MIN_Y + course.MAX_Y) / 2

        return center_x, center_y, overview_zoom


# =============================================================================
# WORLD TO SCREEN
# =============================================================================
def world_to_screen(x, y, camera):
    # Convert world coordinates into either the rotating follow view or the fixed north-up overview.
    center_x, center_y, zoom = camera.get_view()

    if camera.show_overview:
        screen_x = (settings.WINDOW_WIDTH / 2) + ((x - center_x) * zoom)
        screen_y = (settings.WINDOW_HEIGHT / 2) - ((y - center_y) * zoom)

    else:
        relative_x = x - camera.x
        relative_y = y - camera.y

        heading_cosine = math.cos(camera.heading)
        heading_sine = math.sin(camera.heading)

        forward = (relative_x * heading_cosine) + (relative_y * heading_sine)
        sideways = (-relative_x * heading_sine) + (relative_y * heading_cosine)

        screen_x = (settings.WINDOW_WIDTH / 2) - (sideways * zoom)
        screen_y = (settings.WINDOW_HEIGHT / 2) - (forward * zoom)

    return int(round(screen_x)), int(round(screen_y))


# =============================================================================
# DRAW COURSE
# =============================================================================
def draw_course(screen, camera):
    # -------------------------------------------------------------------------
    # LAND AND WATER
    # -------------------------------------------------------------------------
    screen.fill(course.LAND_COLOR)

    # Draw every water polygon and cut any mapped interior land islands back out.
    water_polygons = getattr(course, "WATER_POLYGONS", [course.LAKE_SHORELINE])
    land_holes = getattr(course, "LAND_HOLES", [])

    for polygon in water_polygons:
        water_points = [world_to_screen(x, y, camera) for x, y in polygon]
        if len(water_points) >= 3:
            pygame.draw.polygon(screen, course.WATER_COLOR, water_points)
            pygame.draw.lines(screen, course.SHORE_COLOR, True, water_points, 2)

    for polygon in land_holes:
        land_points = [world_to_screen(x, y, camera) for x, y in polygon]
        if len(land_points) >= 3:
            pygame.draw.polygon(screen, course.LAND_COLOR, land_points)
            pygame.draw.lines(screen, course.SHORE_COLOR, True, land_points, 2)

    # -------------------------------------------------------------------------
    # DOCKS
    # -------------------------------------------------------------------------
    # Each mapped dock path is a centerline. Draw each segment as a rectangle
    # so the visible dock has a consistent width and square ends.
    dock_layer = pygame.Surface(screen.get_size(), pygame.SRCALPHA)

    _, _, zoom = camera.get_view()

    dock_width = max(2.0, settings.DOCK_DISPLAY_WIDTH * zoom)

    half_width = dock_width / 2.0

    for dock_path in course.DOCK_PATHS:
        screen_path = []

        for x, y in dock_path:
            screen_point = world_to_screen(x, y, camera)
            screen_path.append(screen_point)

        for index in range(len(screen_path) - 1):
            x1, y1 = screen_path[index]
            x2, y2 = screen_path[index + 1]

            dx = x2 - x1
            dy = y2 - y1
            segment_length = math.hypot(dx, dy)

            if segment_length < 0.001:
                continue

            normal_x = (-dy / segment_length) * half_width
            normal_y = (dx / segment_length) * half_width

            corners = [
                (x1 + normal_x, y1 + normal_y),
                (x2 + normal_x, y2 + normal_y),
                (x2 - normal_x, y2 - normal_y),
                (x1 - normal_x, y1 - normal_y)]

            pygame.draw.polygon(dock_layer, course.DOCK_COLOR, corners)


        # ---------------------------------------------------------------------
        # DOCK JOINS
        # ---------------------------------------------------------------------
        # Fill small gaps where two rectangular dock segments meet at a bend.
        join_size = max(2, round(dock_width))

        for x, y in screen_path[1:-1]:
            join_rect = pygame.Rect(0, 0, join_size, join_size)

            join_rect.center = (x, y)

            pygame.draw.rect(dock_layer, course.DOCK_COLOR, join_rect)


    # -------------------------------------------------------------------------
    # WATER MASK
    # -------------------------------------------------------------------------
    # Hide any dock width that extends beyond the mapped shoreline onto land.
    water_mask = pygame.Surface(screen.get_size(), pygame.SRCALPHA)

    for polygon in water_polygons:
        points = [world_to_screen(x, y, camera) for x, y in polygon]
        if len(points) >= 3:
            pygame.draw.polygon(water_mask, (255, 255, 255, 255), points)
    for polygon in land_holes:
        points = [world_to_screen(x, y, camera) for x, y in polygon]
        if len(points) >= 3:
            pygame.draw.polygon(water_mask, (0, 0, 0, 0), points)

    dock_layer.blit(water_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

    screen.blit(dock_layer, (0, 0))

    # -------------------------------------------------------------------------
    # VISUAL BRIDGE CENTERLINES (NOT COLLISION BARRIERS)
    # -------------------------------------------------------------------------
    for bridge in getattr(course, "BRIDGE_PATHS", []):
        path = [world_to_screen(x, y, camera) for x, y in bridge["points"]]
        if len(path) >= 2:
            pygame.draw.lines(screen, (220, 205, 172), False, path, max(2, round(1.5 * zoom)))

    for marker in getattr(course, "COURSE_MARKERS", []):
        if "point" not in marker:
            continue
        marker_screen = world_to_screen(*marker["point"], camera)
        pygame.draw.circle(screen, marker["color"], marker_screen, max(4, round(1.5 * zoom)))
        pygame.draw.circle(screen, "white", marker_screen, max(4, round(1.5 * zoom)), 1)

    # -------------------------------------------------------------------------
    # NON-COLLIDING COURSE LINE MARKERS
    # -------------------------------------------------------------------------
    # Some courses use point markers; others use lines across the water.
    # Point markers were already drawn above, so only draw line markers here.
    for marker in getattr(course, "COURSE_MARKERS", []):
        if "start" not in marker or "end" not in marker:
            continue

        start = world_to_screen(*marker["start"], camera)
        end = world_to_screen(*marker["end"], camera)
        if marker.get("style") == "checkered":
            # Alternating black/white bars across the river at the finish line.
            length = math.hypot(end[0] - start[0], end[1] - start[1])
            sections = max(2, round(length / 8))
            for section in range(sections):
                ratio_start = section / sections
                ratio_end = (section + 1) / sections
                point_a = (start[0] + (end[0] - start[0]) * ratio_start,
                           start[1] + (end[1] - start[1]) * ratio_start)
                point_b = (start[0] + (end[0] - start[0]) * ratio_end,
                           start[1] + (end[1] - start[1]) * ratio_end)
                color = (255, 255, 255) if section % 2 == 0 else (30, 30, 30)
                pygame.draw.line(screen, color, point_a, point_b, 5)
        else:
            pygame.draw.line(screen, marker["color"], start, end, 3)


# =============================================================================
# BOAT TO WORLD
# =============================================================================
def boat_to_world(boat, forward, sideways):
    # Rotate a boat-relative point into world coordinates.
    heading_cosine = math.cos(boat.heading)
    heading_sine = math.sin(boat.heading)

    world_x = (boat.x + (forward * heading_cosine) - (sideways * heading_sine))

    world_y = (boat.y + (forward * heading_sine) + (sideways * heading_cosine))

    return world_x, world_y


# =============================================================================
# BOAT DETAIL POINT
# =============================================================================
def boat_detail_point(boat, camera, forward, sideways):
    # Convert a boat-relative point directly into screen coordinates.
    world_x, world_y = boat_to_world(boat, forward, sideways)

    screen_point = world_to_screen(world_x, world_y, camera)

    return screen_point


# =============================================================================
# DRAW OAR
# =============================================================================
def draw_oar(screen, boat, camera, section, seat, rowing_state, oar_position, stroke_phase):

    # The oar animation is visual only and does not alter the rowing forces.
    port_side = seat in settings.PORT_SEATS

    if port_side:
        side = 1.0

    else:
        side = -1.0


    # -------------------------------------------------------------------------
    # SWEEP ANGLE
    # -------------------------------------------------------------------------
    # Raised oars are held straight out from the shell while clearing the dock.
    if oar_position == "up":
        sweep_angle = 0.0

    elif rowing_state == "hold":
        sweep_angle = 0.0

    elif rowing_state in ("forward", "backward"):
        if stroke_phase < settings.DRIVE_FRACTION:
            drive_progress = stroke_phase / settings.DRIVE_FRACTION

            sweep_degrees = (settings.OAR_DISPLAY_MAX_SWEEP_ANGLE - (2 * settings.OAR_DISPLAY_MAX_SWEEP_ANGLE * drive_progress))

        else:
            recovery_progress = ((stroke_phase - settings.DRIVE_FRACTION) / settings.RECOVERY_FRACTION)

            sweep_degrees = (-settings.OAR_DISPLAY_MAX_SWEEP_ANGLE + (2 * settings.OAR_DISPLAY_MAX_SWEEP_ANGLE * recovery_progress))

        if rowing_state == "backward":
            sweep_degrees = -sweep_degrees

        sweep_angle = math.radians(sweep_degrees)

    else:
        sweep_angle = math.radians(settings.OAR_COAST_SWEEP_ANGLE)


    # -------------------------------------------------------------------------
    # OAR POSITION
    # -------------------------------------------------------------------------
    # Offset paired seats slightly fore/aft so both oars remain visible.
    if seat % 2 == 0:
        seat_offset = -settings.ROWER_SEAT_FORWARD_OFFSET

    else:
        seat_offset = settings.ROWER_SEAT_FORWARD_OFFSET

    position = section["position"] + seat_offset
    pivot_side = side * settings.OAR_SPAN


    # -------------------------------------------------------------------------
    # OAR LENGTH
    # -------------------------------------------------------------------------
    # Raised oars use their full horizontal reach because they are out of the water.
    if oar_position == "up":
        blade_outer_distance = (settings.OAR_RAISED_REACH - settings.OAR_SPAN)

    else:
        blade_outer_distance = settings.OAR_OUTBOARD

    blade_graphics_length = min(settings.OAR_BLADE_GRAPHICS_LENGTH, blade_outer_distance)

    blade_inner_distance = (blade_outer_distance - blade_graphics_length)


    # -------------------------------------------------------------------------
    # OAR GEOMETRY
    # -------------------------------------------------------------------------
    shaft_end_forward = (position + (blade_inner_distance * math.sin(sweep_angle)))

    shaft_end_sideways = (pivot_side + (side * blade_inner_distance * math.cos(sweep_angle)))

    blade_inner_forward = shaft_end_forward
    blade_inner_sideways = shaft_end_sideways

    blade_outer_forward = (position + (blade_outer_distance * math.sin(sweep_angle)))

    blade_outer_sideways = (pivot_side + (side * blade_outer_distance * math.cos(sweep_angle)))


    # -------------------------------------------------------------------------
    # SCREEN POINTS
    # -------------------------------------------------------------------------
    pivot = boat_detail_point(boat, camera, position, pivot_side)

    shaft_end = boat_detail_point(boat, camera, shaft_end_forward, shaft_end_sideways)

    _, _, zoom = camera.get_view()

    if zoom < 1.0:
        return


    # -------------------------------------------------------------------------
    # OAR SHAFT
    # -------------------------------------------------------------------------
    oar_width = max(1, round(0.055 * zoom))

    if oar_position == "up":
        shaft_color = settings.OAR_RAISED_COLOR

    else:
        shaft_color = (46, 51, 59)

    pygame.draw.line(screen, shaft_color, pivot, shaft_end, oar_width)


    # -------------------------------------------------------------------------
    # OAR BLADE
    # -------------------------------------------------------------------------
    blade_start = boat_detail_point(boat, camera, blade_inner_forward, blade_inner_sideways)

    blade_end = boat_detail_point(boat, camera, blade_outer_forward, blade_outer_sideways)

    if oar_position == "up":
        blade_color = settings.OAR_RAISED_COLOR

    elif rowing_state == "coast":
        blade_color = (175, 196, 202)

    elif rowing_state == "hold":
        blade_color = (40, 62, 82)

    else:
        if port_side:
            blade_color = (226, 153, 55)

        else:
            blade_color = (235, 182, 80)

    blade_width = max(2, round(0.15 * zoom))

    pygame.draw.line(screen, blade_color, blade_start, blade_end, blade_width)


# =============================================================================
# DRAW BOAT COLLISION BOX
# =============================================================================
def draw_boat_collision_box(screen, boat, camera, control_state):
    # Draw the fixed local collision envelope in the boat's current position.
    collision_points = []

    for forward, sideways in control_state.boat_collision_local_points:
        screen_point = boat_detail_point(boat, camera, forward, sideways)

        collision_points.append(screen_point)

    pygame.draw.lines(screen, settings.BOAT_COLLISION_COLOR, True, collision_points, settings.BOAT_COLLISION_LINE_WIDTH)


# =============================================================================
# DRAW BOAT
# =============================================================================
def draw_boat(screen, boat, camera, control_state=None, simulation_time=0.0):
    _, _, zoom = camera.get_view()


    # -------------------------------------------------------------------------
    # DISPLAY DIMENSIONS
    # -------------------------------------------------------------------------
    # Slightly widen the drawn shell at low zoom so it remains visible. Physics
    # calculations still use the actual 0.53 m shell width from settings.py.
    minimum_visible_half_width = 2.8 / max(zoom, 0.01)

    visual_half_width = max(settings.SHELL_WIDTH / 2, minimum_visible_half_width)

    geometric_center = settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS
    bow = geometric_center + (settings.SHELL_LENGTH / 2)
    stern = geometric_center - (settings.SHELL_LENGTH / 2)


    # -------------------------------------------------------------------------
    # OARS - DRAWN BEHIND THE HULL
    # -------------------------------------------------------------------------
    if (control_state is not None and zoom >= 1.0 and not camera.show_overview):

        stroke_fraction = control_state.stroke_clock.phase

        for section in settings.ROWER_SECTIONS:
            for seat in section["rowers"]:
                rowing_state = control_state.rower_states[seat]

                if seat in settings.PORT_SEATS:
                    oar_position = control_state.oar_positions["port"]

                else:
                    oar_position = control_state.oar_positions["starboard"]

                draw_oar(screen, boat, camera, section, seat, rowing_state, oar_position, stroke_fraction)


    # -------------------------------------------------------------------------
    # RACING SHELL OUTLINE
    # -------------------------------------------------------------------------
    # Use a tapered polygon at both the bow and stern.
    local_points = [
        (bow, 0.0),
        (bow - 1.3, visual_half_width * 0.78),
        (bow - 3.0, visual_half_width),
        (stern + 1.9, visual_half_width),
        (stern + 0.4, visual_half_width * 0.45),
        (stern, 0.0),
        (stern + 0.4, -visual_half_width * 0.45),
        (stern + 1.9, -visual_half_width),
        (bow - 3.0, -visual_half_width),
        (bow - 1.3, -visual_half_width * 0.78)]

    hull_points = []

    for forward, sideways in local_points:
        screen_point = boat_detail_point(boat, camera, forward, sideways)

        hull_points.append(screen_point)

    pygame.draw.polygon(screen, (242, 246, 244), hull_points)

    pygame.draw.lines(screen, (53, 69, 80), True, hull_points, 1)


    # -------------------------------------------------------------------------
    # CENTERLINE AND CREW POSITIONS
    # -------------------------------------------------------------------------
    if zoom >= 2.0 and not camera.show_overview:
        centerline_start = boat_detail_point(boat, camera, stern + 0.9, 0)

        centerline_end = boat_detail_point(boat, camera, bow - 0.8, 0)

        pygame.draw.line(screen, (164, 180, 182), centerline_start, centerline_end, 1)

        for section in settings.ROWER_SECTIONS:
            for seat in section["rowers"]:
                if seat in settings.PORT_SEATS:
                    side = 1.0

                else:
                    side = -1.0

                if seat % 2 == 0:
                    seat_offset = -settings.ROWER_SEAT_FORWARD_OFFSET

                else:
                    seat_offset = settings.ROWER_SEAT_FORWARD_OFFSET

                position = section["position"] + seat_offset

                seat_center = boat_detail_point(boat, camera, position, side * 0.16)

                seat_radius = max(2, round(0.16 * zoom))

                pygame.draw.circle(screen, (33, 72, 100), seat_center, seat_radius)


        # ---------------------------------------------------------------------
        # COXSWAIN POSITION
        # ---------------------------------------------------------------------
        if settings.HAS_COXSWAIN:
            coxswain_center = boat_detail_point(boat, camera, settings.COXSWAIN_POSITION, 0)

            coxswain_radius = max(2, round(0.20 * zoom))

            pygame.draw.circle(screen, (180, 92, 58), coxswain_center, coxswain_radius)


    # -------------------------------------------------------------------------
    # RUDDER DIRECTION INDICATOR
    # -------------------------------------------------------------------------
    if (control_state is not None and zoom >= 3.0 and not camera.show_overview):

        rudder_angle = math.radians(control_state.rudder_angle)
        rudder_base = settings.STEERING_LEVER_ARM

        rudder_tip_forward = (rudder_base - (0.60 * math.cos(rudder_angle)))

        rudder_tip_sideways = 0.60 * math.sin(rudder_angle)

        rudder_start = boat_detail_point(boat, camera, rudder_base, 0)

        rudder_tip = boat_detail_point(boat, camera, rudder_tip_forward, rudder_tip_sideways)

        pygame.draw.line(screen, (228, 171, 52), rudder_start, rudder_tip, 2)


    # -------------------------------------------------------------------------
    # COLLISION BOX
    # -------------------------------------------------------------------------
    if control_state is not None:
        draw_boat_collision_box(screen, boat, camera, control_state)


    # -------------------------------------------------------------------------
    # OVERVIEW BOAT MARKER
    # -------------------------------------------------------------------------
    if camera.show_overview:
        marker = world_to_screen(boat.x, boat.y, camera)

        pygame.draw.circle(screen, "yellow", marker, 5)

        pygame.draw.circle(screen, "black", marker, 5, 1)


# =============================================================================
# CENTER-OF-MASS PATH
# =============================================================================
def draw_com_trail(screen, camera, trail):
    if trail is None:
        return

    points = [world_to_screen(x, y, camera) for x, y in trail.visible_points()]
    if len(points) >= 2:
        pygame.draw.lines(screen, (14, 48, 113), False, points, 3)


# =============================================================================
# DRAW DEBUG HUD
# =============================================================================
def draw_hud(screen, font, boat, trail=None):
    # Display the current boat state and recent average speed.
    speed = boat.get_speed()
    average_speed = boat.get_average_speed()
    heading_degrees = math.degrees(boat.heading)

    lines = [
        f"Position X: {boat.x:.2f} m",
        f"Position Y: {boat.y:.2f} m",
        f"Velocity X: {boat.velocity_x:.2f} m/s",
        f"Velocity Y: {boat.velocity_y:.2f} m/s",
        f"Speed: {speed:.2f} m/s",
        f"Average Speed (5s): {average_speed:.2f} m/s",
        f"COM Distance: {trail.distance_m:.1f} m" if trail is not None else "COM Distance: 0.0 m",
        f"Acceleration X: {boat.acceleration_x:.2f} m/s^2",
        f"Acceleration Y: {boat.acceleration_y:.2f} m/s^2",
        f"Force X: {boat.last_force_x:.2f} N",
        f"Force Y: {boat.last_force_y:.2f} N",
        f"Heading: {heading_degrees:.1f} degrees",
        f"Angular Velocity: {boat.angular_velocity:.3f} rad/s",
        f"Angular Acceleration: {boat.angular_acceleration:.3f} rad/s^2",
        f"Torque: {boat.last_torque:.2f} N*m"]

    x = 20
    y = 20
    line_spacing = 17

    for line in lines:
        text = font.render(line, True, "white")

        screen.blit(text, (x, y))
        y += line_spacing


# =============================================================================
# DRAW CONTROL HUD
# =============================================================================
def draw_control_hud(screen, font, control_state):
    x = settings.WINDOW_WIDTH - 250
    y = 20
    line_spacing = 27


    # -------------------------------------------------------------------------
    # TITLE
    # -------------------------------------------------------------------------
    title = font.render("ROWING STATUS", True, "white")

    screen.blit(title, (x, y))
    y += line_spacing + 5


    # -------------------------------------------------------------------------
    # ROWER STATES
    # -------------------------------------------------------------------------
    for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
        display_name = settings.ROWER_DISPLAY_NAMES[seat]
        rowing_state = control_state.rower_states[seat].title()

        line = f"{display_name}: {rowing_state}"
        instruction = control_state.command_manager.pending[seat]
        if instruction is not None:
            current_count = control_state.stroke_clock.completed_strokes
            if instruction.mode == "in":
                remaining = max(0, instruction.start_at - current_count)
            elif instruction.mode == "for":
                remaining = max(0, instruction.finish_at - max(current_count, instruction.start_at))
            else:
                remaining = 0
            if instruction.mode in ("in", "for"):
                line += f" ({instruction.mode.upper()} {remaining})"

        text = font.render(line, True, "white")

        screen.blit(text, (x, y))
        y += line_spacing


    # -------------------------------------------------------------------------
    # OAR POSITIONS
    # -------------------------------------------------------------------------
    y += 5
    count_text = font.render(f"Boat strokes: {control_state.stroke_clock.completed_strokes}", True, "white")
    screen.blit(count_text, (x, y))
    y += line_spacing + 3

    port_oar_position = control_state.oar_positions["port"].title()
    starboard_oar_position = (control_state.oar_positions["starboard"].title())

    port_text = font.render(f"Port Oars: {port_oar_position}", True, "white")

    screen.blit(port_text, (x, y))
    y += line_spacing

    starboard_text = font.render(f"Starboard Oars: {starboard_oar_position}", True, "white")

    screen.blit(starboard_text, (x, y))
    y += line_spacing


    # -------------------------------------------------------------------------
    # STROKE RATE
    # -------------------------------------------------------------------------
    y += 8

    stroke_rate_text = font.render(f"Stroke Rate: {control_state.stroke_rate} spm", True, "white")

    screen.blit(stroke_rate_text, (x, y))
    y += line_spacing


    # -------------------------------------------------------------------------
    # RUDDER
    # -------------------------------------------------------------------------
    rudder_angle = control_state.rudder_angle

    if rudder_angle > 0.0:
        rudder_text = (f"Rudder: {abs(rudder_angle):.0f} degrees Port")

    elif rudder_angle < 0.0:
        rudder_text = (f"Rudder: {abs(rudder_angle):.0f} degrees Starboard")

    else:
        rudder_text = "Rudder: 0 degrees"

    text = font.render(rudder_text, True, "white")

    screen.blit(text, (x, y))


    # -------------------------------------------------------------------------
    # PREP COMMAND
    # -------------------------------------------------------------------------
    prepared = control_state.get_prepared_text() if hasattr(control_state, "get_prepared_text") else ""
    if prepared:
        y += line_spacing + 8

        # Wrap the natural-language prepared instruction by words.
        words = prepared.split()
        lines = []
        current_line = "Prepared:"
        max_width = min(480, settings.WINDOW_WIDTH - 40)

        for word in words:
            candidate = current_line + " " + word
            if font.size(candidate)[0] > max_width and current_line != "Prepared:":
                lines.append(current_line)
                current_line = word
            else:
                current_line = candidate

        lines.append(current_line)
        for line in lines:
            prep_text = font.render(line, True, "white")
            screen.blit(prep_text, (settings.WINDOW_WIDTH - 20 - prep_text.get_width(), y))
            y += line_spacing


# =============================================================================
# DRAW CAMERA LABEL
# =============================================================================
def draw_camera_label(screen, font, camera):
    # Show either the overview instructions or the current follow-mode zoom.
    if camera.show_overview:
        label = "COURSE OVERVIEW   M: FOLLOW BOAT"

    else:
        label = (f"{getattr(course, 'COURSE_TITLE', 'LAKE MAXINKUCKEE')}   ZOOM: {camera.zoom:.2f} px/m   " "M: OVERVIEW   +/-: ZOOM")

    text = font.render(label, True, "white")

    screen.blit(text, (20, settings.WINDOW_HEIGHT - 30))

# =============================================================================
# RESET BUTTON
# =============================================================================
def get_reset_button_rect():
    return pygame.Rect(settings.WINDOW_WIDTH - 120, settings.WINDOW_HEIGHT - 55, 100, 35)


def draw_reset_button(screen, font):
    # Keep reset available during normal driving, warnings, and crash freezes.
    button_rect = get_reset_button_rect()

    pygame.draw.rect(screen, (45, 45, 45), button_rect)
    pygame.draw.rect(screen, "white", button_rect, 2)

    text = font.render("RESET", True, "white")
    text_rect = text.get_rect(center=button_rect.center)
    screen.blit(text, text_rect)


# =============================================================================
# COLLISION MESSAGES
# =============================================================================
def get_warning_close_button_rect():
    return pygame.Rect((settings.WINDOW_WIDTH // 2) + 185, 78, 28, 28)


def draw_collision_messages(screen, font, warning_message=None, crash_message=None, docked=False):
    # Persistent bump/crash notices sit above the simulation without hiding the boat.
    if docked and crash_message is None:
        docked_text = font.render("DOCKED", True, "white")
        docked_rect = docked_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 35))
        background = docked_rect.inflate(24, 14)

        pygame.draw.rect(screen, (35, 110, 55), background)
        pygame.draw.rect(screen, "white", background, 2)
        screen.blit(docked_text, docked_rect)

    if crash_message is not None:
        message_rect = pygame.Rect((settings.WINDOW_WIDTH // 2) - 260, 70, 520, 110)

        pygame.draw.rect(screen, (120, 25, 25), message_rect)
        pygame.draw.rect(screen, "white", message_rect, 3)

        title = font.render("CRASH - SIMULATION FROZEN", True, "white")
        detail = font.render(crash_message, True, "white")
        reset_text = font.render("Use RESET or press R to restart.", True, "white")

        screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 96)))
        screen.blit(detail, detail.get_rect(center=(settings.WINDOW_WIDTH // 2, 128)))
        screen.blit(reset_text, reset_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 156)))

    elif warning_message is not None:
        message_rect = pygame.Rect((settings.WINDOW_WIDTH // 2) - 235, 70, 470, 82)
        close_rect = get_warning_close_button_rect()

        pygame.draw.rect(screen, (145, 100, 20), message_rect)
        pygame.draw.rect(screen, "white", message_rect, 2)
        pygame.draw.rect(screen, (70, 55, 25), close_rect)
        pygame.draw.rect(screen, "white", close_rect, 1)

        title = font.render("COLLISION WARNING", True, "white")
        detail = font.render(warning_message, True, "white")
        close_text = font.render("X", True, "white")

        screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 93)))
        screen.blit(detail, detail.get_rect(center=(settings.WINDOW_WIDTH // 2, 124)))
        screen.blit(close_text, close_text.get_rect(center=close_rect.center))