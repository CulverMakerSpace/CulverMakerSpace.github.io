import math


# =============================================================================
# BOAT CONFIGURATION
# =============================================================================
# Change BOAT_TYPE to select a different crew layout in the future.
BOAT_TYPE = "8+"

BOAT_CONFIGS = {
    "8+": {
        "rowers": 8,
        "has_coxswain": True},
    "4+": {
        "rowers": 4,
        "has_coxswain": True},
    "4-": {
        "rowers": 4,
        "has_coxswain": False},
    "2-": {
        "rowers": 2,
        "has_coxswain": False}}

NUMBER_OF_ROWERS = BOAT_CONFIGS[BOAT_TYPE]["rowers"]
HAS_COXSWAIN = BOAT_CONFIGS[BOAT_TYPE]["has_coxswain"]
NUMBER_OF_ROWER_SECTIONS = NUMBER_OF_ROWERS // 2


# =============================================================================
# SHELL MEASUREMENTS
# =============================================================================
EXAMPLE_SHELL_MASS = 90.0      # kg
EXAMPLE_SHELL_LENGTH = 17.7    # m
SHELL_WIDTH = 0.53             # m
SHELL_HEIGHT = 0.35            # m
SHELL_DRAFT = 0.15             # m


# =============================================================================
# SHELL SECTION MEASUREMENTS
# =============================================================================
BOW_SECTION_LENGTH = 3.2       # m
ROWER_SECTION_LENGTH = 2.7     # m
STERN_SECTION_LENGTH = 3.7     # m


# =============================================================================
# CALCULATED SHELL DIMENSIONS
# =============================================================================
# Build the full shell length from the measured bow, rower, and stern sections.
SHELL_LENGTH = BOW_SECTION_LENGTH + (NUMBER_OF_ROWER_SECTIONS * ROWER_SECTION_LENGTH) + STERN_SECTION_LENGTH
SHELL_MASS = EXAMPLE_SHELL_MASS * (SHELL_LENGTH / EXAMPLE_SHELL_LENGTH)
SHELL_HEIGHT_ABOVE_WATER = SHELL_HEIGHT - SHELL_DRAFT


# =============================================================================
# STEERING SURFACES
# =============================================================================
SKEG_AREA = 0.020              # m^2
RUDDER_AREA = 0.004            # m^2
STERN_TO_STEERING = 2.1        # m
MAX_RUDDER_ANGLE = 30.0        # degrees


# -----------------------------------------------------------------------------
# RUDDER
# -----------------------------------------------------------------------------
RUDDER_LIFT_SLOPE = 1.2 * math.pi
RUDDER_MAX_LIFT_COEFFICIENT = 1.20


# -----------------------------------------------------------------------------
# SKEG
# -----------------------------------------------------------------------------
SKEG_LIFT_SLOPE = 1.00
SKEG_MAX_LIFT_COEFFICIENT = 0.50


# =============================================================================
# OARS
# =============================================================================
OAR_BLADE_AREA = 0.104         # m^2
OAR_SPAN = 0.85                # m, shell centerline to oarlock/pin
OAR_INBOARD = 0.86             # m, oarlock/pin to handle end
OAR_OUTBOARD = 2.69            # m, effective outboard length used by the model
OAR_STROKE_ANGLE = 90.0        # degrees

OAR_BLADE_DRAG_COEFFICIENT = 1.17


# -----------------------------------------------------------------------------
# OAR DISPLAY AND DOCKING POSITION
# -----------------------------------------------------------------------------
# These values affect only the visual oar position and collision envelope.
OAR_DISPLAY_MAX_SWEEP_ANGLE = 32.0      # degrees from perpendicular
OAR_COAST_SWEEP_ANGLE = 18.0            # degrees from perpendicular
OAR_BLADE_GRAPHICS_LENGTH = 0.46        # m
OAR_RAISED_REACH = 3.77                 # m, centerline to raised blade tip
OAR_RAISED_COLLISION_CLEARANCE = 0.50   # m, collision boundary outside hull when oars are raised
OAR_RAISED_COLOR = (255, 215, 0)        # yellow

# Useful oar dimensions calculated from the measured geometry.
OAR_BLADE_CENTER_FROM_CENTERLINE = OAR_SPAN + OAR_OUTBOARD
OAR_HANDLE_FROM_CENTERLINE_AT_90 = OAR_SPAN - OAR_INBOARD
OAR_HANDLE_TO_BLADE_CENTER = OAR_INBOARD + OAR_OUTBOARD


# =============================================================================
# CREW
# =============================================================================
ROWER_MASS = 80.0              # kg per rower
ROWER_POWER = 450.0            # W per rower at REFERENCE_STROKE_RATE
COXSWAIN_MASS = 70.0           # kg when present

# Rower power is calibrated to produce approximately 5 m/s at 33 spm with the
# current drive fraction, oar model, and water/air resistance calculations.
REFERENCE_STROKE_RATE = 33.0   # strokes per minute
DEFAULT_STROKE_RATE = 25       # strokes per minute
MIN_STROKE_RATE = 10           # strokes per minute
MAX_STROKE_RATE = 50           # strokes per minute

if HAS_COXSWAIN:
    ACTIVE_COXSWAIN_MASS = COXSWAIN_MASS

else:
    ACTIVE_COXSWAIN_MASS = 0.0


# =============================================================================
# ROWING MODEL ASSUMPTIONS
# =============================================================================
# Fraction of a rower's mechanical power that becomes useful propulsion.
FORWARD_EFFICIENCY = 0.65
REVERSE_EFFICIENCY = 0.40

# Maximum holding-water force is capped at this fraction of the maximum
# forward rowing force that one rower can produce at the reference stroke rate.
HOLD_FORCE_FRACTION = 0.25

# Rowing force is applied only during the drive portion of each stroke.
DRIVE_FRACTION = 0.33
RECOVERY_FRACTION = 1.0 - DRIVE_FRACTION


# =============================================================================
# WATER PROPERTIES
# =============================================================================
# Approximate freshwater properties.
WATER_DENSITY = 1000.0                 # kg/m^3
WATER_KINEMATIC_VISCOSITY = 1.004e-6   # m^2/s


# =============================================================================
# AIR AND WIND
# =============================================================================
# Wind direction uses the meteorological convention: the direction the wind
# comes FROM. 0 = north, 90 = east, 180 = south, 270 = west.
AIR_DENSITY = 1.225                    # kg/m^3, standard sea-level air
WIND_SPEED = 0.0                       # m/s
WIND_DIRECTION = 0.0                   # degrees, wind FROM this direction


# -----------------------------------------------------------------------------
# SHELL AERODYNAMICS
# -----------------------------------------------------------------------------
SHELL_FORWARD_AIR_DRAG_COEFFICIENT = 0.50
SHELL_SIDE_AIR_DRAG_COEFFICIENT = 0.80

# Approximate the exposed front of the tapered shell as a triangle.
SHELL_FORWARD_PROJECTED_AREA = (0.5 * SHELL_WIDTH * SHELL_HEIGHT_ABOVE_WATER)

# Reduce exposed side area for the tapered bow and stern.
BOW_SIDE_AIR_AREA_FACTOR = 0.50
STERN_SIDE_AIR_AREA_FACTOR = 0.50
ROWER_SECTION_SIDE_AIR_AREA_FACTOR = 1.00


# -----------------------------------------------------------------------------
# ROWER AERODYNAMICS
# -----------------------------------------------------------------------------
# Effective seated dimensions averaged over the stroke cycle.
ROWER_EFFECTIVE_EXPOSED_HEIGHT = 0.65   # m
ROWER_EFFECTIVE_BODY_WIDTH = 0.45       # m, front/back view
ROWER_EFFECTIVE_BODY_DEPTH = 0.25       # m, side view

ROWER_FORWARD_PROJECTED_AREA = (ROWER_EFFECTIVE_EXPOSED_HEIGHT * ROWER_EFFECTIVE_BODY_WIDTH)

ROWER_SIDE_PROJECTED_AREA = (ROWER_EFFECTIVE_EXPOSED_HEIGHT * ROWER_EFFECTIVE_BODY_DEPTH)

# Rowers shield one another when viewed from directly ahead or astern.
ROWER_FORWARD_SHIELDING_FACTOR = 0.35
ROWER_AIR_DRAG_COEFFICIENT = 1.00


# -----------------------------------------------------------------------------
# COXSWAIN AERODYNAMICS
# -----------------------------------------------------------------------------
# The coxswain sits lower than the rowers, so use a smaller silhouette.
COXSWAIN_EFFECTIVE_EXPOSED_HEIGHT = 0.45    # m
COXSWAIN_EFFECTIVE_BODY_WIDTH = 0.40        # m
COXSWAIN_EFFECTIVE_BODY_DEPTH = 0.25        # m

COXSWAIN_FORWARD_PROJECTED_AREA = (COXSWAIN_EFFECTIVE_EXPOSED_HEIGHT * COXSWAIN_EFFECTIVE_BODY_WIDTH)

COXSWAIN_SIDE_PROJECTED_AREA = (COXSWAIN_EFFECTIVE_EXPOSED_HEIGHT * COXSWAIN_EFFECTIVE_BODY_DEPTH)

COXSWAIN_AIR_DRAG_COEFFICIENT = 1.00


# =============================================================================
# LATERAL HYDRODYNAMICS
# =============================================================================
# Translation and rotation use separate drag coefficients so the shell strongly
# resists sideways drift without unrealistically resisting yaw.
LATERAL_DRAG_COEFFICIENT = 0.60
ROTATIONAL_LATERAL_DRAG_COEFFICIENT = 0.42

HULL_SIDESLIP_FORCE_SLOPE = 0.06
HULL_MAX_SIDESLIP_FORCE_COEFFICIENT = 1.00


# =============================================================================
# CALCULATED MASSES
# =============================================================================
CREW_MASS = NUMBER_OF_ROWERS * ROWER_MASS
TOTAL_MASS = SHELL_MASS + CREW_MASS + ACTIVE_COXSWAIN_MASS
ROWER_PAIR_MASS = 2 * ROWER_MASS
ROWERS_PER_SIDE = NUMBER_OF_ROWERS // 2


# =============================================================================
# ROWER POSITIONS
# =============================================================================
# Even-numbered seats are port and odd-numbered seats are starboard.
ROWER_SEAT_FORWARD_OFFSET = 0.46        # m, visual fore/aft separation

PORT_SEATS = [2, 4, 6, 8]
STARBOARD_SEATS = [1, 3, 5, 7]

ROWER_DISPLAY_NAMES = {
    1: "Bow",
    2: "2 Seat",
    3: "3 Seat",
    4: "4 Seat",
    5: "5 Seat",
    6: "6 Seat",
    7: "7 Seat",
    8: "Stroke"}


# =============================================================================
# SECTION GEOMETRY - RELATIVE TO SHELL GEOMETRIC CENTER
# =============================================================================
# Build the stern, rower sections, and bow from the measured section lengths.
HULL_SECTION_GEOMETRY = []

STERN_START = -SHELL_LENGTH / 2
STERN_CENTER = STERN_START + (STERN_SECTION_LENGTH / 2)

HULL_SECTION_GEOMETRY.append({ "name": "stern", "length": STERN_SECTION_LENGTH, "center_geometric": STERN_CENTER, "rowers": []})

for SECTION_INDEX in range(NUMBER_OF_ROWER_SECTIONS):
    SECTION_START = (STERN_START + STERN_SECTION_LENGTH + (SECTION_INDEX * ROWER_SECTION_LENGTH))

    SECTION_CENTER = SECTION_START + (ROWER_SECTION_LENGTH / 2)

    HIGH_SEAT = NUMBER_OF_ROWERS - (2 * SECTION_INDEX)
    LOW_SEAT = HIGH_SEAT - 1

    HULL_SECTION_GEOMETRY.append({
        "name": f"rowers_{LOW_SEAT}_{HIGH_SEAT}",
        "length": ROWER_SECTION_LENGTH,
        "center_geometric": SECTION_CENTER,
        "rowers": [LOW_SEAT, HIGH_SEAT]})

BOW_START = (STERN_START + STERN_SECTION_LENGTH + (NUMBER_OF_ROWER_SECTIONS * ROWER_SECTION_LENGTH))

BOW_CENTER = BOW_START + (BOW_SECTION_LENGTH / 2)

HULL_SECTION_GEOMETRY.append({ "name": "bow", "length": BOW_SECTION_LENGTH, "center_geometric": BOW_CENTER, "rowers": []})

# Approximate the seated coxswain location inside the stern section.
COXSWAIN_POSITION_GEOMETRIC = (STERN_START + (0.875 * STERN_SECTION_LENGTH))


# =============================================================================
# CENTER OF MASS
# =============================================================================
# Treat the shell as centered at x = 0 and each rower pair as a point mass at
# the center of its section.
ROWER_MASS_MOMENT = 0.0

for SECTION in HULL_SECTION_GEOMETRY:
    if SECTION["rowers"]:
        ROWER_MASS_MOMENT += (ROWER_PAIR_MASS * SECTION["center_geometric"])

COXSWAIN_MASS_MOMENT = (ACTIVE_COXSWAIN_MASS * COXSWAIN_POSITION_GEOMETRIC)

CENTER_OF_MASS_FROM_GEOMETRIC_CENTER = ((ROWER_MASS_MOMENT + COXSWAIN_MASS_MOMENT) / TOTAL_MASS)

GEOMETRIC_CENTER_FROM_CENTER_OF_MASS = (-CENTER_OF_MASS_FROM_GEOMETRIC_CENTER)


# =============================================================================
# HULL SECTION DATA - RELATIVE TO CENTER OF MASS
# =============================================================================
# Convert each section position from the shell's geometric center to the loaded
# center of mass and calculate its underwater side area.
HULL_SECTIONS = []

for SECTION in HULL_SECTION_GEOMETRY:
    SECTION_POSITION = (SECTION["center_geometric"] - CENTER_OF_MASS_FROM_GEOMETRIC_CENTER)

    LATERAL_AREA = SECTION["length"] * SHELL_DRAFT

    HULL_SECTIONS.append({
        "name": SECTION["name"],
        "length": SECTION["length"],
        "center_geometric": SECTION["center_geometric"],
        "position": SECTION_POSITION,
        "lateral_area": LATERAL_AREA,
        "rowers": SECTION["rowers"]})

# Keep a separate list containing only the sections occupied by rowers.
ROWER_SECTIONS = []

for SECTION in HULL_SECTIONS:
    if SECTION["rowers"]:
        ROWER_SECTIONS.append(SECTION)

COXSWAIN_POSITION = (COXSWAIN_POSITION_GEOMETRIC - CENTER_OF_MASS_FROM_GEOMETRIC_CENTER)


# =============================================================================
# WETTED SURFACE AREA
# =============================================================================
# Approximate the underwater cross-section as the lower half of an ellipse.
WIDTH = SHELL_WIDTH / 2
DEPTH = SHELL_DRAFT

UNDERWATER_ELLIPSE_PERIMETER = math.pi * ((3 * (WIDTH + DEPTH)) - math.sqrt(((3 * WIDTH) + DEPTH) * (WIDTH + (3 * DEPTH))))

WETTED_PERIMETER = UNDERWATER_ELLIPSE_PERIMETER / 2
WETTED_SURFACE_AREA = WETTED_PERIMETER * SHELL_LENGTH


# =============================================================================
# MOMENT OF INERTIA
# =============================================================================
# Treat the shell as a uniform rectangle and the crew as point masses along it.
SHELL_MOMENT_OF_INERTIA_AT_GEOMETRIC_CENTER = ((1 / 12) * SHELL_MASS * (SHELL_LENGTH**2 + SHELL_WIDTH**2))

SHELL_PARALLEL_AXIS_TERM = (SHELL_MASS * CENTER_OF_MASS_FROM_GEOMETRIC_CENTER**2)

SHELL_MOMENT_OF_INERTIA = (SHELL_MOMENT_OF_INERTIA_AT_GEOMETRIC_CENTER + SHELL_PARALLEL_AXIS_TERM)

ROWER_MOMENT_OF_INERTIA = 0.0

for SECTION in ROWER_SECTIONS:
    ROWER_MOMENT_OF_INERTIA += (ROWER_PAIR_MASS * SECTION["position"]**2)

COXSWAIN_MOMENT_OF_INERTIA = (ACTIVE_COXSWAIN_MASS * COXSWAIN_POSITION**2)

MOMENT_OF_INERTIA = (SHELL_MOMENT_OF_INERTIA + ROWER_MOMENT_OF_INERTIA + COXSWAIN_MOMENT_OF_INERTIA)


# =============================================================================
# STEERING CALCULATIONS
# =============================================================================
# Measure the rudder/skeg location from the loaded center of mass.
STEERING_POSITION_GEOMETRIC = ((-SHELL_LENGTH / 2) + STERN_TO_STEERING)

STEERING_LEVER_ARM = (STEERING_POSITION_GEOMETRIC - CENTER_OF_MASS_FROM_GEOMETRIC_CENTER)


# =============================================================================
# DISPLAY
# =============================================================================
WINDOW_WIDTH = 1200            # pixels
WINDOW_HEIGHT = 800            # pixels
FPS = 60                       # frames per second
PIXELS_PER_METER = 5.0         # pixels per meter

DEBUG_HUD_FONT_SIZE = 15       # pixels
CONTROL_HUD_FONT_SIZE = 24     # pixels
SPEED_HISTORY_WINDOW = 5.0     # seconds
RUDDER_STEP = 10.0             # degrees per key press
DOCK_DISPLAY_WIDTH = 3.0       # m, visual width of mapped dock centerlines

# Collision shape is drawn around the shell and the current oar position.
BOAT_COLLISION_PADDING = 0.15       # m
BOAT_COLLISION_LINE_WIDTH = 2       # pixels
BOAT_COLLISION_COLOR = (255, 0, 0)  # red

# Collision severity uses ONLY inward speed at the actual contact point.
COLLISION_CONTACT_MAX_SPEED = 0.50      # m/s, inbound contact-point speed
COLLISION_BUMP_MAX_SPEED = 1.50         # m/s, inbound contact-point speed

# Successful docking uses ONLY the boat's 5-second rolling average speed.
COLLISION_DOCKED_MAX_SPEED = 0.10       # m/s, 5-second rolling average

# Coefficient of restitution controls the normal bounce at the contact point.
# 0.0 = no bounce; 1.0 = perfectly elastic bounce.
COLLISION_CONTACT_RESTITUTION = 0.0
COLLISION_BUMP_RESTITUTION = 0.15

# Small numerical tolerances used by the course collision calculations.
COLLISION_GEOMETRY_EPSILON = 1e-7
COLLISION_NORMAL_TEST_DISTANCE = 0.25   # m
COLLISION_SEARCH_ITERATIONS = 10


# =============================================================================
# TESTING
# =============================================================================
TEST_FORWARD_FORCE = 800.0     # N


# =============================================================================
# LAKE CAMERA
# =============================================================================
# World geometry remains in meters regardless of the current camera scale.
CAMERA_MIN_ZOOM = 0.20         # pixels per meter
CAMERA_MAX_ZOOM = 12.0         # pixels per meter
CAMERA_ZOOM_FACTOR = 1.25      # zoom multiplier per key press
