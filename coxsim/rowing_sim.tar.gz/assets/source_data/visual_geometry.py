"""Visual-only course geometry shared by the Pygame and Godot renderers.

Do not use these smoothed banks or merged bridges for collision detection.
The course modules retain the original mapped coordinates for physics.
"""

import math


# =============================================================================
# SHORELINE DETAIL - PRECOMPUTED ONCE PER COURSE
# =============================================================================
SHORELINE_SMOOTHING_PASSES = 3
SHORELINE_CORNER_FRACTION = 0.16
SHORELINE_MAX_EDGE_METERS = 12.0
SHORELINE_MAX_VERTICES = 1850


def smooth_visual_shoreline(points):
    """Round sharp corners and add bounded intermediate shoreline vertices.

    Three conservative corner-cutting passes keep the smoothed outline close
    to the surveyed polygon; added points never alter navigable boundaries.
    """
    vertices = [(float(x), float(y)) for x, y in points]
    if len(vertices) < 4:
        return vertices

    for _ in range(SHORELINE_SMOOTHING_PASSES):
        if len(vertices) * 2 > SHORELINE_MAX_VERTICES:
            break
        next_vertices = []
        for index, point in enumerate(vertices):
            following = vertices[(index + 1) % len(vertices)]
            fraction = SHORELINE_CORNER_FRACTION
            next_vertices.append((point[0] * (1 - fraction) + following[0] * fraction,
                                  point[1] * (1 - fraction) + following[1] * fraction))
            next_vertices.append((point[0] * fraction + following[0] * (1 - fraction),
                                  point[1] * fraction + following[1] * (1 - fraction)))
        vertices = next_vertices

    segment_lengths = [math.dist(point, vertices[(index + 1) % len(vertices)])
                       for index, point in enumerate(vertices)]
    remaining_slots = SHORELINE_MAX_VERTICES - len(vertices)
    target_edge = SHORELINE_MAX_EDGE_METERS
    while sum(max(0, math.ceil(length / target_edge) - 1) for length in segment_lengths) > remaining_slots:
        target_edge *= 1.1
    result = []

    for index, point in enumerate(vertices):
        following = vertices[(index + 1) % len(vertices)]
        result.append(point)
        extra = min(max(0, math.ceil(math.dist(point, following) / target_edge) - 1), remaining_slots)
        remaining_slots -= extra
        for subdivision in range(1, extra + 1):
            fraction = subdivision / (extra + 1)
            result.append((point[0] + (following[0] - point[0]) * fraction,
                           point[1] + (following[1] - point[1]) * fraction))
    return [(round(x, 2), round(y, 2)) for x, y in result]


# =============================================================================
# BRIDGE CONSOLIDATION - RENDERING GEOMETRY ONLY
# =============================================================================
BRIDGE_MARGIN_METERS = 1.5
BRIDGE_MIN_WIDTH_METERS = 5.0
BRIDGE_BANK_OVERLAP_METERS = 5.0
BRIDGE_MAX_BANK_EXTENSION_METERS = 140.0


def _path_direction(points):
    start = points[0]
    end = points[-1]
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    distance = math.hypot(dx, dy)
    return (dx / distance, dy / distance) if distance > 0.001 else (1.0, 0.0)


def _path_bounds(points, axis):
    normal = (-axis[1], axis[0])
    along = [x * axis[0] + y * axis[1] for x, y in points]
    across = [x * normal[0] + y * normal[1] for x, y in points]
    return min(along), max(along), min(across), max(across)


def _overlap(a_min, a_max, b_min, b_max):
    return min(a_max, b_max) - max(a_min, b_min)


def _are_parallel_overlapping(first, second):
    axis_a = _path_direction(first["points"])
    axis_b = _path_direction(second["points"])
    dot = abs(axis_a[0] * axis_b[0] + axis_a[1] * axis_b[1])
    if dot < math.cos(math.radians(18.0)):
        return False

    a_min, a_max, a_side_min, a_side_max = _path_bounds(first["points"], axis_a)
    b_min, b_max, b_side_min, b_side_max = _path_bounds(second["points"], axis_a)
    aligned = first["name"] == second["name"] and first["name"] != ""
    side_gap = max(0.0, a_side_min - b_side_max, b_side_min - a_side_max)
    along_overlap = _overlap(a_min, a_max, b_min, b_max)
    if aligned:
        return side_gap <= 28.0 and along_overlap >= -12.0

    # Different labels can describe different mapped edges of one roadway
    # (e.g. Anderson Memorial Bridge and the JFK Street centerline).
    almost_identical_heading = dot >= math.cos(math.radians(8.0))
    same_deck = almost_identical_heading and side_gap <= 16.0 and along_overlap >= 20.0
    close_duplicate = side_gap <= 7.0 and along_overlap >= -2.0
    return same_deck or close_duplicate


def _bridge_kind(name):
    lower = name.lower()
    if any(word in lower for word in ("rail", "subdivision", "muskego")):
        return "rail"
    if any(word in lower for word in ("footbridge", "pedestrian")):
        return "pedestrian"
    return "road"


def _is_decorative_path(name):
    """Exclude riverside paths that are not bridge structures."""
    lower = name.lower()
    return any(word in lower for word in ("riverwalk", "running track", "dudley white path"))



def _water_intervals_on_line(origin, direction, shoreline):
    """Return stretches of a bridge centerline that lie inside the water polygon."""
    intersections = []
    for index, start in enumerate(shoreline):
        end = shoreline[(index + 1) % len(shoreline)]
        edge_x = end[0] - start[0]
        edge_y = end[1] - start[1]
        denominator = direction[0] * edge_y - direction[1] * edge_x
        if abs(denominator) < 1e-9:
            continue

        offset_x = start[0] - origin[0]
        offset_y = start[1] - origin[1]
        distance = (offset_x * edge_y - offset_y * edge_x) / denominator
        edge_fraction = (offset_x * direction[1] - offset_y * direction[0]) / denominator
        if -1e-8 <= edge_fraction <= 1.0 + 1e-8:
            intersections.append(distance)

    intersections.sort()
    unique = []
    for distance in intersections:
        if not unique or distance - unique[-1] > 0.001:
            unique.append(distance)

    # The midpoint test works regardless of the polygon winding direction.
    intervals = []
    for left, right in zip(unique[::2], unique[1::2]):
        if right - left > 0.01:
            intervals.append((left, right))
    return intervals


def _extend_bridge_to_banks(start, end, center_side, half_width, axis, shoreline):
    """Cover the full water crossing, including the outer edges of a bridge deck."""
    if not shoreline or len(shoreline) < 3:
        return start, end

    normal = (-axis[1], axis[0])
    candidates = []
    for side in (center_side - half_width, center_side, center_side + half_width):
        origin = (normal[0] * side, normal[1] * side)
        intervals = _water_intervals_on_line(origin, axis, shoreline)
        overlapping = [(left, right) for left, right in intervals
                       if min(right, end) - max(left, start) > 0.0]
        if not overlapping:
            continue
        # If a line crosses multiple separate water areas, keep the crossing
        # that actually overlaps the mapped bridge.
        left, right = max(overlapping, key=lambda pair: min(pair[1], end) - max(pair[0], start))
        candidates.append((left, right))

    if not candidates:
        return start, end

    target_start = min(left for left, _ in candidates) - BRIDGE_BANK_OVERLAP_METERS
    target_end = max(right for _, right in candidates) + BRIDGE_BANK_OVERLAP_METERS
    new_start = max(start - BRIDGE_MAX_BANK_EXTENSION_METERS, min(start, target_start))
    new_end = min(end + BRIDGE_MAX_BANK_EXTENSION_METERS, max(end, target_end))
    return new_start, new_end

def consolidate_visual_bridges(bridge_paths, shoreline=None):
    """Merge near-parallel mapped bridge edges into a single deck per span.

    Returns simple four-corner polygons, not unions of collision objects. A
    source path may represent one deck edge, the center, or duplicate OSM ways.
    Grouping uses direction, lateral spacing and longitudinal overlap.
    """
    items = []
    for bridge in bridge_paths:
        name = str(bridge.get("name", "")).strip()
        points = [tuple(point) for point in bridge.get("points", [])]
        if len(points) < 2 or _is_decorative_path(name):
            continue
        if math.dist(points[0], points[-1]) < 4.0:
            continue
        items.append({"name": name, "points": points})

    parent = list(range(len(items)))

    def find(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    for first in range(len(items)):
        for second in range(first + 1, len(items)):
            if _are_parallel_overlapping(items[first], items[second]):
                parent[find(second)] = find(first)

    groups = {}
    for index in range(len(items)):
        groups.setdefault(find(index), []).append(items[index])

    bridges = []
    for group in groups.values():
        # Unnamed, isolated OSM ways should not become mysterious roadways.
        named = [piece for piece in group if piece["name"]]
        if not named:
            continue
        main = max(group, key=lambda piece: math.dist(piece["points"][0], piece["points"][-1]))
        axis = _path_direction(main["points"])
        points = [point for piece in group for point in piece["points"]]
        min_along, max_along, min_side, max_side = _path_bounds(points, axis)
        center_side = (min_side + max_side) * 0.5
        half_width = max(BRIDGE_MIN_WIDTH_METERS * 0.5,
                         (max_side - min_side) * 0.5 + BRIDGE_MARGIN_METERS)
        left_side = center_side + half_width
        right_side = center_side - half_width
        start = min_along - BRIDGE_MARGIN_METERS
        end = max_along + BRIDGE_MARGIN_METERS
        start, end = _extend_bridge_to_banks(start, end, center_side, half_width, axis, shoreline)
        normal = (-axis[1], axis[0])
        polygon = []
        for along, across in ((start, left_side), (end, left_side),
                              (end, right_side), (start, right_side)):
            polygon.append([round(along * axis[0] + across * normal[0], 3),
                            round(along * axis[1] + across * normal[1], 3)])

        name = max(named, key=lambda piece: len(piece["name"]))["name"]
        bridges.append({"name": name,
                        "kind": _bridge_kind(name),
                        "polygon": polygon,
                        "source_segments": len(group)})

    bridges.sort(key=lambda bridge: (bridge["name"], bridge["polygon"][0]))
    return bridges
