"""Shared active course interface; import-safe for the collision module."""
from importlib import import_module

COURSES = {
    "max": "source_data.courses.course_maxinkuckee",
    "charles": "source_data.courses.course_charles",
    "nathan": "source_data.courses.course_nathan",
    "milwaukee": "source_data.courses.course_milwaukee",
}

_active = None
active_course_name = None


def activate_course(name):
    global _active, active_course_name
    if name not in COURSES:
        raise ValueError(f"Unknown course: {name}")
    _active = import_module(COURSES[name])
    active_course_name = name


def __getattr__(name):
    if _active is None:
        raise RuntimeError("Select a course before accessing its geometry")
    return getattr(_active, name)


# Collision geometry is initialized for this course at import time.
# Simulation.load_course() rebuilds that geometry for each selected course.
activate_course("charles")
