"""Course definitions, selection registry, and mapped navigation geometry."""
