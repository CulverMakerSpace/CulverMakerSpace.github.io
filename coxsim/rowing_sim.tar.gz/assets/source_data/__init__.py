"""Course data and visual-only geographical geometry helpers."""
