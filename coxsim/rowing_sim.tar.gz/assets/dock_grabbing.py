"""Per-seat dock grabbing, independent of the collision safety envelope.

The dock centerlines describe physical platforms with a fixed width. Raised
blades reach over these platforms; each rower can grab independently.
"""
import math

import course
import settings
from collisions import get_rower_forward_position
from rowing import calculate_max_hold_force_per_rower


def dock_segments():
    """Extract the currently selected course's dock centerline segments."""
    for path in course.DOCK_PATHS:
        for start, end in zip(path, path[1:]):
            dx = end[0] - start[0]
            dy = end[1] - start[1]
            length = math.hypot(dx, dy)
            if length > 1e-8:
                yield start, (dx / length, dy / length), length


def nearest_dock_for_seat(boat, forward_position, side, segments):
    """Find a dock in reach on the side of this raised oar."""
    cosine = math.cos(boat.heading)
    sine = math.sin(boat.heading)
    seat_x = boat.x + forward_position * cosine
    seat_y = boat.y + forward_position * sine
    outward_x = -sine * side
    outward_y = cosine * side
    best = None

    for origin, tangent, length in segments:
        offset_x = seat_x - origin[0]
        offset_y = seat_y - origin[1]
        along = offset_x * tangent[0] + offset_y * tangent[1]
        along = max(0.0, min(length, along))
        closest_x = origin[0] + tangent[0] * along
        closest_y = origin[1] + tangent[1] * along
        toward_x = closest_x - seat_x
        toward_y = closest_y - seat_y
        distance = math.hypot(toward_x, toward_y)
        if distance < 1e-6:
            continue
        normal_x = toward_x / distance
        normal_y = toward_y / distance
        # Reject dock geometry across the hull or near the longitudinal ends.
        alignment = normal_x * outward_x + normal_y * outward_y
        if alignment < settings.DOCK_GRAB_MIN_SIDE_ALIGNMENT:
            continue
        edge_distance = distance - settings.DOCK_DISPLAY_WIDTH / 2.0
        if edge_distance > settings.OAR_RAISED_REACH:
            continue
        if best is None or edge_distance < best[0]:
            best = (edge_distance, tangent, (normal_x, normal_y), (seat_x, seat_y), alignment)
    return best


def apply_dock_grab_forces(boat, controls, dt):
    """Apply bounded braking and pulling at every engaged raised-oar seat."""
    if dt <= 0.0:
        return 0
    segments = list(dock_segments())
    if not segments:
        return 0

    max_force = calculate_max_hold_force_per_rower() * settings.DOCK_GRAB_FORCE_MULTIPLIER
    cosine = math.cos(boat.heading)
    sine = math.sin(boat.heading)
    engaged_count = 0

    for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
        side = 1.0 if seat in settings.PORT_SEATS else -1.0
        group = "port" if side > 0.0 else "starboard"
        if controls.oar_positions[group] != "up":
            continue
        forward_position = get_rower_forward_position(seat)
        nearby = nearest_dock_for_seat(boat, forward_position, side, segments)
        if nearby is None:
            continue

        edge_distance, tangent, normal, _, alignment = nearby
        engaged_count += 1
        # Velocity at the actual seat includes yaw-induced translation.
        seat_vx = boat.velocity_x - boat.angular_velocity * forward_position * sine
        seat_vy = boat.velocity_y + boat.angular_velocity * forward_position * cosine
        tangential_speed = seat_vx * tangent[0] + seat_vy * tangent[1]
        inward_speed = seat_vx * normal[0] + seat_vy * normal[1]

        # Keep a 1 m clearance from the edge of the dock. A velocity damper
        # prevents the pull from accelerating the hull into the platform.
        clearance_error = max(0.0, edge_distance - settings.DOCK_GRAB_TARGET_CLEARANCE)
        pulling_force = max(0.0, settings.DOCK_GRAB_PULL_STIFFNESS * clearance_error
                            - settings.DOCK_GRAB_PULL_DAMPING * inward_speed)
        braking_force = -settings.DOCK_GRAB_BRAKE_DAMPING * tangential_speed

        # Each rower has one combined force limit, not a full limit per axis.
        pulling_force = min(max_force, pulling_force)
        braking_force = max(-max_force, min(max_force, braking_force))
        magnitude = math.hypot(pulling_force, braking_force)
        if magnitude > max_force:
            scale = max_force / magnitude
            pulling_force *= scale
            braking_force *= scale

        force_x = pulling_force * normal[0] + braking_force * tangent[0]
        force_y = pulling_force * normal[1] + braking_force * tangent[1]
        forward_force = force_x * cosine + force_y * sine
        sideways_force = -force_x * sine + force_y * cosine
        boat.apply_force(forward_force, sideways_force, forward_position, 0.0)
    return engaged_count


def aligned_dock_sections(boat, controls):
    """Return the sections whose raised dock-side oars have reached the dock.

    Every section must contact the same side of the boat. The dock edge is
    compared with the raised-oar collision boundary (1 m from centerline),
    rather than waiting for the physical hull to touch a dock.
    """
    segments = list(dock_segments())
    aligned_by_side = {"port": set(), "starboard": set()}
    if not segments:
        return aligned_by_side

    for section_index, section in enumerate(settings.ROWER_SECTIONS):
        for seat in section["rowers"]:
            side = 1.0 if seat in settings.PORT_SEATS else -1.0
            group = "port" if side > 0.0 else "starboard"
            if controls.oar_positions[group] != "up":
                continue

            forward_position = get_rower_forward_position(seat)
            nearby = nearest_dock_for_seat(boat, forward_position, side, segments)
            if nearby is None:
                continue

            edge_distance = nearby[0]
            if edge_distance <= settings.DOCK_GRAB_TARGET_CLEARANCE + settings.DOCK_GRAB_ALIGNMENT_TOLERANCE:
                aligned_by_side[group].add(section_index)

    return aligned_by_side


def is_fully_alongside_dock(boat, controls):
    """All four sections must be at dock clearance on one raised-oar side."""
    aligned = aligned_dock_sections(boat, controls)
    section_count = len(settings.ROWER_SECTIONS)
    return any(len(sections) == section_count for sections in aligned.values())
