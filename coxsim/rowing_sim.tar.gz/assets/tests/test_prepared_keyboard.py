"""Keyboard staging tests without requiring a graphical Pygame installation."""
import sys
import types
import unittest
from unittest.mock import patch

KEY_NAMES = ("LSHIFT RSHIFT q p LCTRL RCTRL LALT RALT TAB w s SPACE RETURN "
             "KP_ENTER u j UP DOWN LEFT RIGHT c g BACKQUOTE 0 1 2 3 4 5 6 7 8 9").split()
pygame_stub = types.SimpleNamespace(KEYDOWN=2)
for index, name in enumerate(KEY_NAMES, start=100):
    setattr(pygame_stub, "K_" + name, index)

with patch.dict(sys.modules, {"pygame": pygame_stub}):
    import controls


class TestPreparedKeyboard(unittest.TestCase):
    def setUp(self):
        self.state = controls.ControlState()

    def press(self, *keys):
        for key in keys:
            controls.handle_keyboard_event(self.state, types.SimpleNamespace(type=pygame_stub.KEYDOWN,
                                                                             key=getattr(pygame_stub, "K_" + key)))

    def test_staged_until_go(self):
        self.press("LSHIFT", "w")
        self.assertEqual(self.state.get_prepared_text(), "All forward")
        self.assertTrue(all(v == "coast" for v in self.state.rower_states.values()))
        self.press("g")
        self.assertEqual(self.state.get_prepared_text(), "")
        self.assertTrue(all(v == "forward" for v in self.state.rower_states.values()))

    def test_clear_discard_and_replace(self):
        self.press("q", "LCTRL", "3", "w")
        self.assertEqual(self.state.get_prepared_text(), "Port for 3 forward")
        self.press("c", "LSHIFT", "RETURN", "g")
        self.assertTrue(all(v == "hold" for v in self.state.rower_states.values()))

    def test_in_count_go(self):
        self.press("LSHIFT", "w", "g")
        self.press("q", "LALT", "7", "s")
        self.assertEqual(self.state.get_prepared_text(), "Port in 7 reverse")
        self.press("g")
        for seat in controls.settings.PORT_SEATS:
            self.assertEqual(self.state.command_manager.pending[seat].count, 7)

    def test_follow_up_with_hold(self):
        self.press("LSHIFT", "LCTRL", "9", "w", "TAB", "p", "RETURN")
        self.assertEqual(self.state.get_prepared_text(), "All for 9 forward then Starboard hold")
        self.press("g")
        self.assertEqual(len(self.state.command_manager.follow_ups), 1)
        follow = self.state.command_manager.follow_ups[0]
        self.assertEqual(set(follow.seats), set(controls.settings.STARBOARD_SEATS))
        self.assertEqual(follow.action, "hold")

    def test_action_and_group_replacements(self):
        self.press("q", "p", "LCTRL", "3", "9", "s", "w")
        self.assertEqual(self.state.get_prepared_text(), "Starboard for 9 forward")

    def test_incomplete_followup_cannot_execute(self):
        self.press("LSHIFT", "LCTRL", "3", "s", "TAB", "g")
        self.assertNotEqual(self.state.get_prepared_text(), "")
        self.assertTrue(all(v == "coast" for v in self.state.rower_states.values()))

    def test_two_digit_input_and_replacement(self):
        examples = [
            (("5",), 5),
            (("1", "BACKQUOTE", "4"), 14),
            (("1", "BACKQUOTE", "0"), 10),
            (("2", "BACKQUOTE", "0"), 20),
            (("3", "2", "BACKQUOTE", "0"), 20),
            (("1", "BACKQUOTE", "4", "8"), 8),
            (("1", "BACKQUOTE", "1", "1", "BACKQUOTE", "3"), 13),
        ]
        for keys, expected in examples:
            with self.subTest(keys=keys):
                self.press("c", "q", "LCTRL", *keys)
                self.assertEqual(self.state.command_count, expected)
                self.press("w", "g")
                self.assertEqual(self.state.command_manager.last_instruction.count, expected)

    def test_in_twenty_and_invalid_above_twenty(self):
        self.press("q", "LALT", "2", "BACKQUOTE", "0", "s")
        self.assertEqual(self.state.get_prepared_text(), "Port in 20 reverse")
        self.assertTrue(controls.execute_prepared_command(self.state))
        self.press("q", "LCTRL", "3", "BACKQUOTE", "0", "w")
        self.assertFalse(controls.execute_prepared_command(self.state))
        self.assertEqual(self.state.get_prepared_text(), "Port for 30 forward")


if __name__ == "__main__":
    unittest.main()

class TestCrossGroupFollowUp(unittest.TestCase):
    def setUp(self):
        self.state = controls.ControlState()

    def press(self, *keys):
        for key in keys:
            controls.handle_keyboard_event(self.state, types.SimpleNamespace(type=pygame_stub.KEYDOWN,
                                                                             key=getattr(pygame_stub, "K_" + key)))

    def complete_strokes(self, count):
        for _ in range(count):
            clock = self.state.stroke_clock
            clock.update(clock.stroke_period, self.state.command_manager.any_rowing())
            self.state.command_manager.update()

    def test_port_for_four_then_starboard_reverse(self):
        self.press("q", "LCTRL", "4", "w", "TAB", "p", "s")
        self.assertEqual(self.state.get_prepared_text(), "Port for 4 forward then Starboard reverse")
        self.press("g")
        self.assertEqual(self.state.get_prepared_text(), "")
        self.complete_strokes(3)
        self.assertTrue(all(self.state.rower_states[seat] == "forward" for seat in controls.settings.PORT_SEATS))
        self.complete_strokes(1)
        self.assertTrue(all(self.state.rower_states[seat] == "coast" for seat in controls.settings.PORT_SEATS))
        self.assertTrue(all(self.state.rower_states[seat] == "backward" for seat in controls.settings.STARBOARD_SEATS))

    def test_unrelated_followup_replaced_by_newer_command(self):
        self.press("q", "LCTRL", "4", "w", "TAB", "p", "s", "g")
        self.press("p", "RETURN", "g")
        self.complete_strokes(4)
        self.assertTrue(all(self.state.rower_states[seat] == "hold" for seat in controls.settings.STARBOARD_SEATS))
