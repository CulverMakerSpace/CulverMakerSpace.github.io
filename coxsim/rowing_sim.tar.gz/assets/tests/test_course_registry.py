"""Course-module and menu ID regression tests."""
import importlib
import unittest

import course


class TestCourseRegistry(unittest.TestCase):
    def test_expected_course_ids_and_modules(self):
        expected = {
            "max": "courses.course_maxinkuckee",
            "charles": "courses.course_charles",
            "nathan": "courses.course_nathan",
            "milwaukee": "courses.course_milwaukee",
        }
        self.assertEqual(course.COURSES, expected)
        for course_id, module_name in expected.items():
            with self.subTest(course=course_id):
                module = importlib.import_module(module_name)
                course.activate_course(course_id)
                self.assertEqual(course.active_course_name, course_id)
                self.assertEqual(course.START_X, module.START_X)
                self.assertEqual(course.START_Y, module.START_Y)
                self.assertTrue(len(course.LAKE_SHORELINE) > 2)

    def test_unknown_id_rejected(self):
        with self.assertRaises(ValueError):
            course.activate_course("lake")
