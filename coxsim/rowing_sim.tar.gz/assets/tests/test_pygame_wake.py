"""Pygame wake should follow historical water coordinates, not current heading."""
import math
import unittest

from pygame_wake import WakeTrail
import settings


class FakeBoat:
    def __init__(self):
        self.x = 0.0
        self.y = 0.0
        self.heading = 0.0
        self.velocity_x = 5.0
        self.velocity_y = 0.0

    def get_speed(self):
        return math.hypot(self.velocity_x, self.velocity_y)

    def get_velocity_components(self):
        cosine = math.cos(self.heading)
        sine = math.sin(self.heading)
        return (self.velocity_x * cosine + self.velocity_y * sine,
                -self.velocity_x * sine + self.velocity_y * cosine)


class WakeTrailTests(unittest.TestCase):
    def test_forward_samples_start_at_world_stern(self):
        boat = FakeBoat()
        wake = WakeTrail()
        wake.record(boat, 0.0)
        expected_stern = settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS - settings.SHELL_LENGTH / 2
        self.assertAlmostEqual(wake.points[0][0], expected_stern)
        self.assertAlmostEqual(wake.points[0][1], 0.0)

    def test_path_keeps_old_stern_positions_through_turn(self):
        boat = FakeBoat()
        wake = WakeTrail()
        for index in range(12):
            boat.x = index
            wake.record(boat, index / 5.0)
        earlier = wake.visible_points(3.0)
        self.assertGreater(len(earlier), 4)

        # Turn 90 degrees then travel north; the old eastbound wake must stay put.
        boat.heading = math.pi / 2
        boat.velocity_x = 0.0
        boat.velocity_y = 5.0
        for index in range(1, 7):
            boat.y = index
            wake.record(boat, 3.0 + index / 5.0)
        points = wake.visible_points(4.5)
        self.assertAlmostEqual(points[0][1], 0.0)
        self.assertTrue(any(abs(p[1]) > 0.5 for p in points))
        self.assertTrue(any(p[0] < 0 for p in points))

    def test_reverse_uses_bow_and_starts_separate_wake(self):
        boat = FakeBoat()
        wake = WakeTrail()
        wake.record(boat, 0.0)
        boat.velocity_x = -5.0
        boat.x = -1.0
        wake.record(boat, 0.2)
        expected_bow = boat.x + settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS + settings.SHELL_LENGTH / 2
        self.assertEqual(wake.direction, -1)
        self.assertEqual(len(wake.points), 1)
        self.assertAlmostEqual(wake.points[0][0], expected_bow)

    def test_stopping_fades_existing_wake(self):
        boat = FakeBoat()
        wake = WakeTrail()
        for index in range(8):
            boat.x = index
            wake.record(boat, index / 5.0)
        self.assertGreater(len(wake.visible_points(2.0)), 2)
        boat.velocity_x = 0.0
        boat.x = 7.0
        wake.record(boat, 12.0)
        self.assertEqual(wake.visible_points(12.0), [])

    def test_lateral_drift_keeps_last_stern_or_bow(self):
        boat = FakeBoat()
        wake = WakeTrail()
        wake.record(boat, 0.0)
        boat.velocity_x = 0.0
        boat.velocity_y = 2.0
        boat.y = 1.0
        wake.record(boat, 0.5)
        self.assertEqual(wake.direction, 1)
        self.assertEqual(len(wake.points), 2)


if __name__ == "__main__":
    unittest.main()
