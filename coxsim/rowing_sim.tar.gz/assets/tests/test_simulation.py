"""Deterministic, headless regression tests. Run: python -m unittest discover -s tests -v"""
import math
import unittest

import settings
from boat import Boat
from rowing import get_stroke_period, is_drive_phase
from trajectory import CenterOfMassTrail


class TestTrail(unittest.TestCase):
    def test_length_follows_path_not_displacement(self):
        trail = CenterOfMassTrail(0, 0)
        for x, y in [(3, 0), (3, 4), (0, 4), (0, 0)]:
            trail.record(x, y)
        self.assertAlmostEqual(trail.distance_m, 14)
        self.assertEqual(trail.last_position, (0, 0))

    def test_short_movement_appears_at_current_com(self):
        trail = CenterOfMassTrail(1, 2, minimum_point_spacing=1)
        trail.record(1.1, 2.0)
        self.assertEqual(len(trail.points), 1)
        self.assertEqual(trail.visible_points()[-1], (1.1, 2.0))

    def test_reset_starts_new_track(self):
        trail = CenterOfMassTrail(0, 0)
        trail.record(10, 0)
        trail = CenterOfMassTrail(5, 5)
        self.assertEqual(trail.distance_m, 0)
        self.assertEqual(trail.visible_points(), [(5, 5)])


class TestBoatPhysics(unittest.TestCase):
    def test_force_acceleration_and_translation(self):
        boat = Boat()
        boat.apply_force(boat.mass, 0)
        boat.update(0.1)
        self.assertAlmostEqual(boat.acceleration_x, 1)
        self.assertAlmostEqual(boat.velocity_x, 0.1)
        self.assertAlmostEqual(boat.x, 0.01)
        self.assertAlmostEqual(boat.net_force_x, 0)

    def test_side_force_creates_torque(self):
        boat = Boat()
        boat.apply_force(0, 100, application_forward=2)
        self.assertAlmostEqual(boat.net_torque, 200)
        boat.update(0.1)
        self.assertGreater(boat.angular_velocity, 0)

    def test_zero_force_at_rest_is_stable(self):
        boat = Boat()
        for _ in range(120):
            boat.update(1/120)
        self.assertAlmostEqual(boat.x, 0)
        self.assertAlmostEqual(boat.y, 0)
        self.assertAlmostEqual(boat.get_speed(), 0)

    def test_rolling_average_speed(self):
        boat = Boat()
        for _ in range(100):
            boat.record_speed_history(0.1, 0.5)
        self.assertAlmostEqual(boat.get_average_speed(), 5)
        self.assertLessEqual(boat.speed_history_time, settings.SPEED_HISTORY_WINDOW + 1e-8)


class TestMovementScenarios(unittest.TestCase):
    @staticmethod
    def run_rowing_scenario(port_state, starboard_state, duration_s=12, rate=25):
        from hydrodynamics import calculate_longitudinal_drag
        from rowing import calculate_forward_force, calculate_reverse_force

        boat = Boat()
        dt = 1 / 120
        steps = int(duration_s / dt)
        port_count = len(settings.PORT_SEATS)
        starboard_count = len(settings.STARBOARD_SEATS)

        for step in range(steps):
            elapsed = step * dt
            if is_drive_phase(elapsed, rate):
                for state, count, side in [(port_state, port_count, 1), (starboard_state, starboard_count, -1)]:
                    if state == "forward":
                        force = calculate_forward_force(boat, count, rate)
                    elif state == "backward":
                        force = calculate_reverse_force(boat, count, rate)
                    else:
                        force = 0.0
                    boat.apply_force(force, 0, 0, side * settings.OAR_BLADE_CENTER_FROM_CENTERLINE)

            boat.apply_force(calculate_longitudinal_drag(boat), 0)
            boat.update(dt)

        return boat

    def test_all_forward_moves_ahead(self):
        boat = self.run_rowing_scenario("forward", "forward")
        self.assertGreater(boat.x, 0)
        self.assertGreater(boat.get_speed(), 0)

    def test_all_reverse_moves_astern(self):
        boat = self.run_rowing_scenario("backward", "backward")
        self.assertLess(boat.x, 0)

    def test_opposite_sides_generate_yaw(self):
        boat = self.run_rowing_scenario("forward", "backward")
        self.assertGreater(abs(boat.angular_velocity), 0.001)

    def test_only_one_side_creates_turning_torque(self):
        boat = self.run_rowing_scenario("forward", "coast")
        self.assertGreater(abs(boat.angular_velocity), 0.001)


class TestExistingStrokeModel(unittest.TestCase):
    def test_rate_period(self):
        self.assertAlmostEqual(get_stroke_period(25), 2.4)
        self.assertAlmostEqual(get_stroke_period(33), 60 / 33)

    def test_drive_and_recovery(self):
        self.assertTrue(is_drive_phase(0.1, 25))
        self.assertFalse(is_drive_phase(1.0, 25))

    def test_new_clock_maintains_phase_on_rate_request(self):
        from command_engine import StrokeClock
        clock = StrokeClock(25)
        clock.update(1.0, True)
        phase_before = clock.phase
        clock.request_rate(33)
        self.assertAlmostEqual(clock.phase, phase_before)
        self.assertEqual(clock.stroke_rate, 25)


class TestCourseGeometry(unittest.TestCase):
    def test_all_courses_have_valid_starts_and_water(self):
        import course
        for name in course.COURSES:
            with self.subTest(course=name):
                course.activate_course(name)
                self.assertTrue(math.isfinite(course.START_X))
                self.assertTrue(math.isfinite(course.START_Y))
                self.assertLess(course.MIN_X, course.MAX_X)
                self.assertLess(course.MIN_Y, course.MAX_Y)


if __name__ == "__main__":
    unittest.main()
