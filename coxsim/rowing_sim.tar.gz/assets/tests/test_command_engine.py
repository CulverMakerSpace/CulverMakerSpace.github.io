"""Deterministic tests for the renderer-independent command engine."""
import unittest

from command_engine import CommandManager, StrokeClock


class TestStrokeClock(unittest.TestCase):
    def test_completed_cycles_and_rate_change_at_boundary(self):
        clock = StrokeClock(25)
        clock.update(1.0, True)
        original_phase = clock.phase
        clock.request_rate(33)
        self.assertAlmostEqual(clock.phase, original_phase)
        self.assertEqual(clock.stroke_rate, 25)
        clock.update(1.4, True)
        self.assertEqual(clock.completed_strokes, 1)
        self.assertEqual(clock.stroke_rate, 33)
        self.assertAlmostEqual(clock.phase, 0)

    def test_requested_rate_updates_without_changing_active_stroke(self):
        from pathlib import Path

        clock = StrokeClock(25)
        clock.update(0.6, True)
        original_phase = clock.phase
        requested_rate = 27
        clock.request_rate(requested_rate)

        self.assertEqual(clock.pending_rate, requested_rate)
        self.assertEqual(clock.stroke_rate, 25)
        self.assertAlmostEqual(clock.phase, original_phase)
        clock.update(1.8, True)
        self.assertEqual(clock.stroke_rate, requested_rate)

        graphics_source = (Path(__file__).resolve().parents[1] / "graphics.py").read_text()
        self.assertIn('Stroke Rate: {control_state.stroke_rate} spm', graphics_source)

    def test_idle_does_not_count(self):
        clock = StrokeClock(25)
        clock.update(24, False)
        self.assertEqual(clock.completed_strokes, 0)
        self.assertEqual(clock.phase, 0)

    def test_large_dt_does_not_skip_strokes(self):
        clock = StrokeClock(25)
        self.assertEqual(clock.update(7.2, True), 3)
        self.assertEqual(clock.completed_strokes, 3)


class TestCommands(unittest.TestCase):
    def setUp(self):
        self.states = {1: "coast", 2: "coast", 3: "coast"}
        self.clock = StrokeClock(25)
        self.commands = CommandManager(self.states, self.clock)

    def tick(self, count=1):
        for _ in range(count):
            self.clock.update(60 / self.clock.stroke_rate, self.commands.any_rowing())
            self.commands.update()

    def test_for_three_from_idle_then_coast(self):
        self.commands.send([1, 2, 3], "backward", "for", 3)
        self.assertEqual(self.states[1], "backward")
        self.tick(2)
        self.assertEqual(self.states[1], "backward")
        self.tick()
        self.assertEqual(self.states[1], "coast")

    def test_follow_up_applies_only_selected_seats(self):
        self.commands.send([1, 2, 3], "backward", "for", 3)
        self.assertTrue(self.commands.set_follow_up([2], "forward"))
        self.tick(3)
        self.assertEqual(self.states, {1: "coast", 2: "forward", 3: "coast"})

    def test_in_waits_when_rowing(self):
        self.commands.send([1], "forward")
        self.commands.send([1], "coast", "in", 3)
        self.tick(2)
        self.assertEqual(self.states[1], "forward")
        self.tick()
        self.assertEqual(self.states[1], "coast")

    def test_in_is_immediate_if_all_coast(self):
        self.commands.send([1], "forward", "in", 8)
        self.assertEqual(self.states[1], "forward")

    def test_hold_interrupts_and_cancels(self):
        self.commands.send([1], "forward", "for", 3)
        self.commands.send([1], "hold")
        self.assertEqual(self.states[1], "hold")
        self.assertIsNone(self.commands.pending[1])

    def test_new_instruction_replaces_existing_count(self):
        self.commands.send([1], "forward", "for", 5)
        self.tick()
        self.commands.send([1], "backward", "for", 2)
        self.tick()
        self.assertEqual(self.states[1], "backward")
        self.tick(2)
        self.assertEqual(self.states[1], "coast")


if __name__ == "__main__":
    unittest.main()
