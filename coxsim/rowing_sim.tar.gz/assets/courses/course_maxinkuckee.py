"""Lake Maxinkuckee course geometry in local meter-based coordinates.

The shoreline and piers come from the supplied OpenStreetMap GeoJSON export.
The stored geometry is self-contained, so the simulator does not need the
GeoJSON file, internet access, pyproj, or shapely at runtime.
"""

import math

import settings


# =============================================================================
# COURSE METADATA AND COLORS
# =============================================================================
COURSE_NAME = "Lake Maxinkuckee"
COORDINATE_SYSTEM = "meters, x=east and y=north (local UTM 16N)"
SOURCE_CREDIT = "OpenStreetMap contributors (ODbL)"

LAND_COLOR = (86, 118, 87)
WATER_COLOR = (78, 161, 214)
SHORE_COLOR = (216, 228, 204)
DOCK_COLOR = (64, 65, 67)


# =============================================================================
# SHORELINE POLYGON
# =============================================================================
# Closed lake boundary in meters. pygame closes the polygon automatically.
LAKE_SHORELINE = [(-803.48, -103.37),
 (-900.48, -268.21),
 (-902.78, -510.62),
 (-813.56, -940.08),
 (-579.63, -1290.39),
 (-95.65, -1470.88),
 (58.79, -1669.24),
 (401.95, -1913.22),
 (653.53, -1966.23),
 (929.18, -1935.01),
 (990.0, -1800.0),
 (991.14, -1408.65),
 (931.26, -1264.4),
 (1306.22, 0.0),
 (1328.6, 282.65),
 (1171.79, 820.99),
 (907.61, 1006.77),
 (841.22, 1092.13),
 (780.68, 1205.23),
 (796.76, 1286.74),
 (786.71, 1360.01),
 (786.48, 1412.45),
 (769.29, 1530.47),
 (764.58, 1621.43),
 (710.59, 1693.3),
 (674.77, 1767.31),
 (675.95, 1820.44),
 (670.62, 1880.65),
 (685.01, 1983.35),
 (622.33, 2077.12),
 (538.76, 2117.66),
 (472.39, 2142.75),
 (296.58, 2184.26),
 (252.78, 2182.26),
 (208.64, 2166.7),
 (176.14, 2129.19),
 (160.32, 2080.34),
 (128.23, 2044.09),
 (57.92, 1999.54),
 (20.94, 1932.75),
 (-63.79, 1881.31),
 (-81.71, 1865.19),
 (-93.3, 1846.26),
 (-109.53, 1836.55),
 (-137.0, 1850.08),
 (-154.82, 1848.96),
 (-268.95, 1865.68),
 (-396.92, 1844.8),
 (-463.58, 1820.82),
 (-519.08, 1779.9),
 (-678.33, 1789.48),
 (-735.56, 1779.5),
 (-824.36, 1748.01),
 (-886.35, 1718.14),
 (-996.36, 1644.44),
 (-1085.73, 1609.66),
 (-1153.72, 1569.97),
 (-1198.86, 1533.79),
 (-1290.25, 1409.73),
 (-1329.15, 1299.65),
 (-1276.57, 1162.71),
 (-1284.22, 1092.13),
 (-1293.81, 898.94),
 (-1233.6, 843.65),
 (-1184.88, 597.71),
 (-1096.97, 359.85),
 (-1057.21, 281.94),
 (-990.1, 223.75),
 (-742.95, 233.23),
 (-668.11, 190.73),
 (-679.33, 108.56),
 (-730.04, 0.0)]


# =============================================================================
# DOCK GEOMETRY
# =============================================================================
# All 29 mapped pier features are stored as centerline paths in meters.
DOCK_PATHS = [
    [
        (370.77, 2187.44),
        (331.73, 2085.28),
        (320.77, 2056.62),
        (309.86, 2028.09),
    ],
    [
        (282.92, 2037.85),
        (309.86, 2028.09),
        (344.31, 2015.61),
    ],
    [
        (295.85, 2066.26),
        (320.77, 2056.62),
        (340.57, 2049.57),
    ],
    [
        (306.15, 2095.53),
        (331.73, 2085.28),
        (358.33, 2075.41),
    ],
    [
        (-402.57, 1857.66),
        (-393.94, 1816.83),
    ],
    [
        (-317.05, 1870.82),
        (-307.31, 1800.58),
    ],
    [
        (675.99, 1845.38),
        (635.91, 1843.09),
        (632.81, 1842.92),
        (615.30, 1841.92),
        (590.26, 1840.49),
    ],
    [
        (651.94, 2037.32),
        (629.34, 2017.21),
    ],
    [
        (637.27, 2054.77),
        (615.01, 2033.17),
    ],
    [
        (156.24, 1942.80),
        (137.39, 1980.09),
        (104.78, 2044.62),
    ],
    [
        (675.90, 1999.65),
        (616.64, 1952.51),
        (612.02, 1958.65),
    ],
    [
        (-393.94, 1816.83),
        (-374.72, 1821.61),
    ],
    [
        (-393.94, 1816.83),
        (-429.85, 1808.19),
    ],
    [
        (-1229.74, 1497.20),
        (-1220.09, 1489.81),
        (-1212.45, 1484.11),
        (-1190.65, 1467.82),
        (-1187.97, 1471.40),
    ],
    [
        (-1212.45, 1484.11),
        (-1208.46, 1489.02),
    ],
    [
        (-1220.09, 1489.81),
        (-1216.24, 1495.14),
    ],
    [
        (-1212.96, 1517.56),
        (-1203.57, 1508.94),
        (-1197.06, 1502.96),
        (-1191.06, 1497.45),
        (-1186.79, 1493.52),
        (-1185.46, 1492.30),
        (-1179.39, 1486.74),
        (-1171.93, 1494.71),
        (-1166.57, 1490.46),
    ],
    [
        (-1179.39, 1486.74),
        (-1182.66, 1483.37),
    ],
    [
        (-1203.57, 1508.94),
        (-1199.14, 1514.01),
    ],
    [
        (-1203.57, 1508.94),
        (-1205.88, 1506.04),
    ],
    [
        (-1185.46, 1492.30),
        (-1180.81, 1497.27),
    ],
    [
        (-1186.79, 1493.52),
        (-1190.14, 1489.81),
    ],
    [
        (-1191.06, 1497.45),
        (-1194.00, 1493.54),
    ],
    [
        (-1197.06, 1502.96),
        (-1192.59, 1507.97),
    ],
    [
        (-740.36, 1777.85),
        (-730.13, 1744.22),
    ],
    [
        (121.15, 1972.28),
        (137.39, 1980.09),
        (151.70, 1986.98),
    ],
    [
        (615.30, 1841.92),
        (613.47, 1869.35),
        (634.24, 1870.48),
        (635.91, 1843.09),
    ],
    [
        (627.40, 1818.43),
        (634.92, 1818.97),
        (634.11, 1828.14),
        (632.81, 1842.92),
    ],
    [
        (626.51, 1827.55),
        (634.11, 1828.14),
    ],
]


# =============================================================================
# INITIAL BOAT POSITION - BETWEEN EASTERN DOCKS 3 AND 4
# =============================================================================
# Dock 3 and dock 4 are the adjacent short southwest-pointing academy piers.
# The boat starts alongside dock 3 with 4 m between the visible dock edge and
# the hull edge, and its bow points parallel to the dock toward the lake.
START_DOCK_3 = DOCK_PATHS[7]
START_DOCK_4 = DOCK_PATHS[8]

START_HULL_CLEARANCE = 4.0                     # m, hull edge to dock edge
START_SHELL_HALF_WIDTH = settings.SHELL_WIDTH / 2
START_DOCK_HALF_WIDTH = settings.DOCK_DISPLAY_WIDTH / 2


# -----------------------------------------------------------------------------
# DOCK 3 DIRECTION
# -----------------------------------------------------------------------------
DOCK_3_SHORE = START_DOCK_3[0]
DOCK_3_TIP = START_DOCK_3[-1]

DOCK_DIRECTION_X = DOCK_3_TIP[0] - DOCK_3_SHORE[0]
DOCK_DIRECTION_Y = DOCK_3_TIP[1] - DOCK_3_SHORE[1]
DOCK_LENGTH = math.hypot(DOCK_DIRECTION_X, DOCK_DIRECTION_Y)

DOCK_UNIT_X = DOCK_DIRECTION_X / DOCK_LENGTH
DOCK_UNIT_Y = DOCK_DIRECTION_Y / DOCK_LENGTH


# -----------------------------------------------------------------------------
# SIDE OF DOCK 3 FACING DOCK 4
# -----------------------------------------------------------------------------
# Start with one perpendicular direction, then flip it if it points away from
# dock 4. This places the shell in the gap between the two docks.
SIDE_UNIT_X = -DOCK_UNIT_Y
SIDE_UNIT_Y = DOCK_UNIT_X

VECTOR_TO_DOCK_4_X = START_DOCK_4[0][0] - DOCK_3_SHORE[0]
VECTOR_TO_DOCK_4_Y = START_DOCK_4[0][1] - DOCK_3_SHORE[1]

DOT_PRODUCT_TO_DOCK_4 = ((SIDE_UNIT_X * VECTOR_TO_DOCK_4_X) + (SIDE_UNIT_Y * VECTOR_TO_DOCK_4_Y))

if DOT_PRODUCT_TO_DOCK_4 < 0.0:
    SIDE_UNIT_X = -SIDE_UNIT_X
    SIDE_UNIT_Y = -SIDE_UNIT_Y


# -----------------------------------------------------------------------------
# STARTING CENTER POSITION
# -----------------------------------------------------------------------------
DOCK_3_MID_X = (DOCK_3_SHORE[0] + DOCK_3_TIP[0]) / 2.0
DOCK_3_MID_Y = (DOCK_3_SHORE[1] + DOCK_3_TIP[1]) / 2.0

CENTERLINE_CLEARANCE = (START_HULL_CLEARANCE + START_SHELL_HALF_WIDTH + START_DOCK_HALF_WIDTH)

START_X = DOCK_3_MID_X + (SIDE_UNIT_X * CENTERLINE_CLEARANCE)
START_Y = DOCK_3_MID_Y + (SIDE_UNIT_Y * CENTERLINE_CLEARANCE)

START_HEADING_DEGREES = (math.degrees(math.atan2(DOCK_UNIT_Y, DOCK_UNIT_X)) % 360.0)


# =============================================================================
# DOCK CENTERLINE SEGMENTS
# =============================================================================
# Flatten each path into individual line segments for course collision checks.
DOCK_SEGMENTS = []

for DOCK_PATH in DOCK_PATHS:
    for SEGMENT_INDEX in range(len(DOCK_PATH) - 1):
        SEGMENT_START = DOCK_PATH[SEGMENT_INDEX]
        SEGMENT_END = DOCK_PATH[SEGMENT_INDEX + 1]

        if SEGMENT_START != SEGMENT_END:
            DOCK_SEGMENTS.append((SEGMENT_START, SEGMENT_END))


# =============================================================================
# COURSE BOUNDS
# =============================================================================
# Bounds are used by the full-lake camera view.
MIN_X = min(point[0] for point in LAKE_SHORELINE)
MAX_X = max(point[0] for point in LAKE_SHORELINE)
MIN_Y = min(point[1] for point in LAKE_SHORELINE)
MAX_Y = max(point[1] for point in LAKE_SHORELINE)


# =============================================================================
# POINT-IN-WATER TEST
# =============================================================================
def is_in_water(x, y):
    # Ray-casting test: each shoreline crossing toggles inside/outside status.
    inside = False
    previous_x, previous_y = LAKE_SHORELINE[-1]

    for current_x, current_y in LAKE_SHORELINE:
        crosses_y = (current_y > y) != (previous_y > y)

        if crosses_y:
            y_fraction = (y - previous_y) / (current_y - previous_y)
            x_change = current_x - previous_x
            crossing_x = previous_x + (y_fraction * x_change)

            if x < crossing_x:
                inside = not inside

        previous_x = current_x
        previous_y = current_y

    return inside
