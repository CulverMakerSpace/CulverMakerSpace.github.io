COURSE_TITLE = "RIVER TEST COURSE"

# =============================================================================
# TEST RIVER COURSE
# =============================================================================
# World coordinates use meters.
# +x points east/right and +y points north/up.
#
# The course is a T-intersection:
#   - Approach straight: 200 m long and 45 m wide.
#   - Cross river: 100 m wide and perpendicular to the approach.
#   - The approach ends at the south bank of the cross river.
#
# The east/right inside corner is at (22.5, 200.0).


# =============================================================================
# COURSE DIMENSIONS
# =============================================================================
APPROACH_LENGTH = 200.0
APPROACH_WIDTH = 45.0
CROSS_RIVER_WIDTH = 100.0

# Give the cross river plenty of room in both directions for turn testing.
CROSS_RIVER_WEST_EXTENT = 250.0
CROSS_RIVER_EAST_EXTENT = 250.0

APPROACH_HALF_WIDTH = APPROACH_WIDTH / 2.0


# =============================================================================
# KEY COURSE LOCATIONS
# =============================================================================
APPROACH_SOUTH_Y = 0.0
INTERSECTION_Y = APPROACH_LENGTH
CROSS_RIVER_NORTH_Y = INTERSECTION_Y + CROSS_RIVER_WIDTH

WEST_INSIDE_CORNER = (-APPROACH_HALF_WIDTH, INTERSECTION_Y)
EAST_INSIDE_CORNER = (APPROACH_HALF_WIDTH, INTERSECTION_Y)


# =============================================================================
# WATER BOUNDARY
# =============================================================================
# Keep the existing LAKE_SHORELINE name so the current graphics and collision
# systems can use this river course without any collision-code changes.
LAKE_SHORELINE = [
    (-CROSS_RIVER_WEST_EXTENT, INTERSECTION_Y),
    (-APPROACH_HALF_WIDTH, INTERSECTION_Y),
    (-APPROACH_HALF_WIDTH, APPROACH_SOUTH_Y),
    (APPROACH_HALF_WIDTH, APPROACH_SOUTH_Y),
    (APPROACH_HALF_WIDTH, INTERSECTION_Y),
    (CROSS_RIVER_EAST_EXTENT, INTERSECTION_Y),
    (CROSS_RIVER_EAST_EXTENT, CROSS_RIVER_NORTH_Y),
    (-CROSS_RIVER_WEST_EXTENT, CROSS_RIVER_NORTH_Y)]


# =============================================================================
# TEST MARKERS
# =============================================================================
# The first marker is 28 m before the east/right inside corner while approaching
# the intersection. The second is 48 m east of that same inside corner.
APPROACH_MARKER_DISTANCE = 28.0
EXIT_MARKER_DISTANCE = 48.0

APPROACH_MARKER_Y = INTERSECTION_Y - APPROACH_MARKER_DISTANCE
EXIT_MARKER_X = EAST_INSIDE_CORNER[0] + EXIT_MARKER_DISTANCE

COURSE_MARKERS = [
    {
        "name": "28 m approach marker",
        "start": (-APPROACH_HALF_WIDTH, APPROACH_MARKER_Y),
        "end": (APPROACH_HALF_WIDTH, APPROACH_MARKER_Y),
        "color": (70, 220, 110)},
    {
        "name": "48 m exit marker",
        "start": (EXIT_MARKER_X, INTERSECTION_Y),
        "end": (EXIT_MARKER_X, CROSS_RIVER_NORTH_Y),
        "color": (235, 80, 70)}]


# =============================================================================
# DOCKS
# =============================================================================
# This test course intentionally has no docks. Keeping the list available lets
# the existing graphics and collision systems continue to work unchanged.
DOCK_PATHS = []


# =============================================================================
# START POSITION
# =============================================================================
# Start on the centerline, 20 m north of the southern end, facing north toward
# the T-intersection. Heading uses the simulator convention: 0 degrees = east,
# 90 degrees = north.
START_X = 0.0
START_Y = 20.0
START_HEADING_DEGREES = 90.0


# =============================================================================
# MAP BOUNDS
# =============================================================================
MIN_X = -CROSS_RIVER_WEST_EXTENT
MAX_X = CROSS_RIVER_EAST_EXTENT
MIN_Y = APPROACH_SOUTH_Y
MAX_Y = CROSS_RIVER_NORTH_Y


# =============================================================================
# DISPLAY COLORS
# =============================================================================
LAND_COLOR = (92, 120, 78)
WATER_COLOR = (62, 126, 168)
SHORE_COLOR = (214, 221, 205)
DOCK_COLOR = (145, 116, 82)


# =============================================================================
# WATER TEST
# =============================================================================
def is_in_water(x, y):
    # Approach straight, including the shared intersection boundary.
    in_approach = (
        -APPROACH_HALF_WIDTH <= x <= APPROACH_HALF_WIDTH
        and APPROACH_SOUTH_Y <= y <= INTERSECTION_Y)

    # Perpendicular cross river.
    in_cross_river = (
        -CROSS_RIVER_WEST_EXTENT <= x <= CROSS_RIVER_EAST_EXTENT
        and INTERSECTION_Y <= y <= CROSS_RIVER_NORTH_Y)

    return in_approach or in_cross_river
