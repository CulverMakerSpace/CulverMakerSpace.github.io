"""Rowing course geometry modules."""
