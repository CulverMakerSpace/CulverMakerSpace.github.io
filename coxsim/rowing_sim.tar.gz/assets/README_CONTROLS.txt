COXSWAIN SIMULATOR - PERSISTENT KEYBOARD CONTROLS

Prep commands
-------------
Shift = all rowers
Q     = port / left-side rowers
P     = starboard / right-side rowers

Execution commands
------------------
W       = row forward
S       = row backward
Enter   = way enough / coast
Space   = hold water
I       = lift oars
O       = lower oars

Commands are persistent and require a prep command followed by an execution
command. Examples:

Shift, W       = all rowers forward
Shift, Enter   = all rowers coast
Q, Enter      = port side coast
P, Space       = starboard side hold water
Q, W, P, S     = port forward, then starboard backward
Shift, I       = lift all oars
Q, I           = lift port oars
P, O           = lower starboard oars

Stroke rate
-----------
Up Arrow       = increase 1 stroke/min
Down Arrow     = decrease 1 stroke/min

Default = 25 strokes/min
Minimum = 10 strokes/min
Maximum = 50 strokes/min

Rudder
------
Left Arrow     = 10 degrees toward port
Right Arrow    = 10 degrees toward starboard

Rudder position persists and is limited to +/- 30 degrees.

HUD
---
Left HUD: physics/debug information at approximately half the previous size.
Right HUD: individual seat states, stroke rate, rudder position, and any
currently waiting prep command.

Seat-side model
---------------
The current code assumes:
Port:      2, 4, 6, Stroke (8)
Starboard: Bow (1), 3, 5, 7

If the physical shell is rigged the opposite way, swap PORT_SEATS and
STARBOARD_SEATS in settings.py.

LAKE MAXINKUCKEE - STAGE 1
-------------------------
Course is a Pygame-drawn approximation based on the supplied illustration.
The image is NOT used at runtime or distributed in this project.

The polygon shoreline is stored in course.py in meters. It is simplified
with high detail in the northern 25%, medium in the next 25%, and low in
the southern 50%. The only docks drawn are the two academy-shore groups.

Camera controls:
  M = toggle full-lake overview / follow-boat view
  + = zoom in
  - = zoom out

Physics and wind remain unchanged. The approximate shoreline is not a survey
map. Shoreline and dock collision detection are now enabled.

Run: python main.py   (requires pygame)


GEOGRAPHIC COURSE - OPENSTREETMAP DATA
-------------------------------------
The Lake Maxinkuckee shoreline and all 29 mapped piers are
extracted from OpenStreetMap GeoJSON and stored as independent meter-based
polygons/line segments in course.py. The source export is included in
source_data/export.geojson for reference, but not needed to run the game.
OpenStreetMap contributors: https://www.openstreetmap.org/copyright
License: Open Database License (ODbL). Respect attribution and applicable
share-alike obligations if distributing the derived geographic data.

Northern 25%: high detail (~3 m tolerance); next 25%: medium (~11 m);
southern 50%: low detail (~32 m).

Shoreline and dock collision detection are enabled.

ALL MAPPED PIERS
----------------
All 29 mapped OSM pier features from export.geojson are now included in
DOCK_PATHS (each pier as an ordered centerline) and DOCK_SEGMENTS.
The northern academy docks are no longer the only docks on the map.

DOCK 3 START LOCATION
---------------------
On launch, the shell starts between the adjacent northeast-shore docks
numbered 3 and 4 when counting physical docks northwestward from the
southeasternmost eastern dock complex. The shell is parallel to dock 3, bow
pointing southwest, with 4.0 m clearance between its side and dock 3's
centerline (the modeled docks currently have no physical width).
The start position is calculated in course.py from the pier geometry.
The starting position is used by the active collision system.

MAP DISPLAY
-----------
All mapped piers remain in course.py. The renderer clips dock pixels to
the lake water polygon, so their inland sections are hidden visually.
This is a drawing-only change; collision geometry is unchanged.


GRAPHICS UPDATE
---------------
Racing shell now has tapered ends, seats, oars (animated visually), a cox
marker and a rudder indicator. These visuals do not alter boat physics.
All 29 OSM piers are drawn as constant-width rectangular segments with
flat ends, with land overlap hidden by the existing water mask.


OAR ANIMATION
-------------
Forward rowing: during the power/drive phase the blade sweeps toward
the stern; during recovery it moves toward the bow. Backward rowing
reverses these directions. The visual cycle follows the same 33% drive
and 67% recovery timing used by the physics model.


SPEED MODEL AND HUD
-------------------
The debug HUD displays instantaneous speed and the moving distance/time
average over the most recent 5 seconds (or time elapsed since start).

Each rower's reference power is 450 W at 33 spm. With a fixed oar sweep
distance, characteristic blade velocity rises with rate; hydrodynamic
resistance scales approximately as velocity squared, leading to a modelled
rower power increase proportional to stroke rate cubed. Rowing thrust is
still determined by the power/velocity and blade-work force limits, with
actual boat speed determined by the existing drag and mass physics.

This is a simplified rate-vs-effort assumption, not a physiological model:
very high stroke rates imply unsustainably high power over long periods.
No velocity is set or multiplied directly to meet a target speed.

Calibration note: 450 W per rower at 33 spm is a model assumption,
not a validated sustained high-school crew power measurement.
The cubic rate-power relationship can become unrealistic at high rates.
Testing used all eight rowers forward on still water, without collisions.


OAR HEIGHT AND COLLISION ENVELOPE
---------------------------------
Oar height is tracked independently for port and starboard. Oars begin down.
Lifting or lowering a side immediately changes those rowers to coast, so that
side waits for a new rowing command before creating force again. Raised oars
are drawn yellow and straight out from the shell with a 3.77 m horizontal reach
from the boat centerline.

The red outline around the boat is the current boat collision envelope. It is a
fixed tapered six-point shape around the hull and oar sweep area. It does NOT
move with every stroke. The local shape is rebuilt only when port or starboard
oars change between raised and lowered. Raised oars use the same reduced
collision footprint that the earlier blades-in command used. Shoreline and dock
collision detection use this current envelope.

RESET
-----
R or click RESET = Restart the simulation from the initial dock position

COLLISION LEVELS
----------------
Collision severity uses the boat's moving average speed over the most recent
5 seconds, or the time elapsed since the simulation was reset.

Contact: average speed less than 0.50 m/s
- All rowers immediately change to coast.
- Prevents penetration and allows the shell to slide along the obstacle.
- Applies braking equivalent to all rowers holding water while contact continues.
- Dock contact displays DOCKED once average speed is below 0.10 m/s.

Bump: average speed from 0.50 m/s up to, but not including, 1.50 m/s
- Rebounds from the obstacle.
- One-third of total translational and rotational kinetic energy is dissipated.
- All rowers immediately change to coast.
- Rudder returns to midship.
- Collision warning remains until its X is clicked or the simulation is reset.

Crash: average speed of 1.50 m/s or greater
- Boat is returned to the last safe position.
- Simulation time, boat motion, and rowing physics freeze immediately.
- Crash message remains until RESET is clicked or R is pressed.
