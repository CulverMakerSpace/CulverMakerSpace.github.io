"""Shared active course. Import-safe for the collision module."""
from importlib import import_module

COURSES = {"lake": "course_lake", "river": "course_charles"}
_active = None
active_course_name = None

def activate_course(name):
    global _active, active_course_name
    if name not in COURSES:
        raise ValueError(f"Unknown course: {name}")
    _active = import_module(COURSES[name])
    active_course_name = name

def __getattr__(name):
    if _active is None:
        raise RuntimeError("Select a course before accessing its geometry")
    return getattr(_active, name)

# controls.py imports collisions.py before the menu is opened. This temporary
# geometry prevents import errors, and selecting a course reloads collisions.
activate_course("river")
