import asyncio
import math
import importlib
import os

import pygame  # type: ignore[reportMissingImports]

import course
import settings

from simulation import Simulation
from boat import Boat
from trajectory import CenterOfMassTrail
from controls import ControlState, coast_all_rowers, handle_keyboard_event, oars_are_down
from environment import calculate_coxswain_side_air_force, calculate_forward_air_force, calculate_section_side_air_force
from graphics import (
    Camera,
    draw_boat,
    draw_camera_label,
    draw_collision_messages,
    draw_control_hud,
    draw_course,
    draw_com_trail,
    draw_hud,
    draw_reset_button,
    get_reset_button_rect,
    get_warning_close_button_rect)
from hydrodynamics import calculate_longitudinal_drag, calculate_rudder_force, calculate_section_lateral_force, calculate_skeg_force
from rowing import calculate_forward_force, calculate_hold_water_force, calculate_reverse_force


# =============================================================================
# COURSE SELECTION MENU
# =============================================================================
def menu_buttons():
    center = settings.WINDOW_WIDTH // 2
    course_names = list(course.COURSES)
    return {name: pygame.Rect(center - 230, 258 + index * 82, 460, 64)
            for index, name in enumerate(course_names)}


def draw_course_menu():
    screen.fill((24, 39, 51))
    font = pygame.font.Font(None, 54)
    small_font = pygame.font.Font(None, 27)
    title = font.render("SELECT A COURSE", True, "white")
    screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 165)))

    labels = {"max": "LAKE MAXINKUCKEE", "charles": "HEAD OF THE CHARLES",
              "nathan": "NATHAN BENDERSON PARK", "milwaukee": "MILWAUKEE RIVER"}

    for name, rectangle in menu_buttons().items():
        pygame.draw.rect(screen, (49, 109, 138), rectangle, border_radius=9)
        pygame.draw.rect(screen, (204, 220, 226), rectangle, 2, border_radius=9)
        label = small_font.render(labels[name], True, "white")
        screen.blit(label, label.get_rect(center=rectangle.center))

    help_text = small_font.render("Select a course to continue. ESC: menu. R: reset.", True, (200, 212, 222))
    screen.blit(help_text, help_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 660)))


def launch_course(course_name):
    global boat, control_state, camera, simulation_time
    global warning_message, crash_message, dock_contact, docked, simulation_crashed
    global current_course, resolve_course_collisions, com_trail

    global simulation
    simulation = Simulation(course_name)
    boat, control_state, camera = simulation.boat, simulation.controls, Camera()
    camera.follow(boat)
    com_trail = simulation.com_trail
    simulation_time = 0.0
    warning_message = None
    crash_message = None
    dock_contact = False
    docked = False
    simulation_crashed = False
    current_course = course_name


# =============================================================================
# BLADE SIDE POSITION
# =============================================================================

def get_blade_sideways(seat):
    # Positive sideways is port; negative sideways is starboard.
    if seat in settings.PORT_SEATS:
        return settings.OAR_BLADE_CENTER_FROM_CENTERLINE

    return -settings.OAR_BLADE_CENTER_FROM_CENTERLINE


# =============================================================================
# RESET SIMULATION
# =============================================================================

def reset_simulation():
    # Recreate every changing simulation object so reset matches a fresh launch.
    simulation.reset()
    new_boat = simulation.boat
    new_control_state = simulation.controls
    new_camera = Camera()

    new_boat.x = course.START_X
    new_boat.y = course.START_Y
    new_boat.heading = math.radians(course.START_HEADING_DEGREES)

    new_camera.follow(new_boat)

    return new_boat, new_control_state, new_camera


# =============================================================================
# SETUP
# =============================================================================

pygame.init()
pygame.display.set_caption("Coxswain Simulator")

screen = pygame.display.set_mode((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))
clock = pygame.time.Clock()

debug_font = pygame.font.Font(None, settings.DEBUG_HUD_FONT_SIZE)
control_font = pygame.font.Font(None, settings.CONTROL_HUD_FONT_SIZE)

boat = None
control_state = None
camera = None
current_course = None
resolve_course_collisions = None

simulation_time = 0.0
com_trail = None
simulation = None

warning_message = None
crash_message = None

dock_contact = False
docked = False
simulation_crashed = False


# =============================================================================
# MAIN LOOP
# =============================================================================

async def main():
    global boat, control_state, camera, current_course, simulation_time
    global warning_message, crash_message, dock_contact, docked, simulation_crashed, com_trail

    running = True

    while running:
        # -------------------------------------------------------------------------
        # TIME
        # -------------------------------------------------------------------------
        dt = clock.tick(settings.FPS) / 1000.0



        # -------------------------------------------------------------------------
        # EVENTS
        # -------------------------------------------------------------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif current_course is None:
                requested = None
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    requested = next((name for name, button in menu_buttons().items() if button.collidepoint(event.pos)), None)
                elif event.type == pygame.KEYDOWN:
                    keys = {pygame.K_1: "max", pygame.K_2: "charles",
                            pygame.K_3: "nathan", pygame.K_4: "milwaukee"}
                    requested = keys.get(event.key)

                if requested is not None:
                    launch_course(requested)

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                current_course = None

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33).collidepoint(event.pos):
                    current_course = None
                    continue
                if get_reset_button_rect().collidepoint(event.pos):
                    boat, control_state, camera = reset_simulation()
                    com_trail = simulation.com_trail

                    simulation_time = 0.0

                    warning_message = None
                    crash_message = None

                    dock_contact = False
                    docked = False
                    simulation_crashed = False

                elif warning_message is not None and get_warning_close_button_rect().collidepoint(event.pos):
                    warning_message = None

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    boat, control_state, camera = reset_simulation()
                    com_trail = simulation.com_trail

                    simulation_time = 0.0

                    warning_message = None
                    crash_message = None

                    dock_contact = False
                    docked = False
                    simulation_crashed = False

                elif event.key == pygame.K_m:
                    camera.toggle_overview()

                elif event.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                    camera.change_zoom(settings.CAMERA_ZOOM_FACTOR)

                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    camera.change_zoom(1.0 / settings.CAMERA_ZOOM_FACTOR)

                elif not simulation_crashed:
                    handle_keyboard_event(control_state, event)


        if current_course is None:
            draw_course_menu()
            pygame.display.flip()
            await asyncio.sleep(0)
            continue

        # =========================================================================
        # PHYSICS
        # =========================================================================

        simulation.step(dt)
        boat = simulation.boat
        control_state = simulation.controls
        com_trail = simulation.com_trail
        warning_message = simulation.warning_message
        crash_message = simulation.crash_message
        dock_contact = simulation.dock_contact
        docked = simulation.docked
        simulation_crashed = simulation.simulation_crashed
        simulation_time = simulation.simulation_time
        camera.follow(boat)


        # =========================================================================
        # DRAW FRAME
        # =========================================================================

        draw_course(screen, camera)
        draw_com_trail(screen, camera, com_trail)
        draw_boat(screen, boat, camera, control_state, simulation_time)

        draw_hud(screen, debug_font, boat, com_trail)
        draw_control_hud(screen, control_font, control_state, boat, com_trail)
        draw_camera_label(screen, debug_font, camera)

        draw_collision_messages(screen, control_font, warning_message, crash_message, docked)
        draw_reset_button(screen, control_font)

        menu_rect = pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33)
        pygame.draw.rect(screen, (45, 45, 45), menu_rect)
        pygame.draw.rect(screen, "white", menu_rect, 2)
        menu_text = control_font.render("COURSES", True, "white")
        screen.blit(menu_text, menu_text.get_rect(center=menu_rect.center))

        pygame.display.flip()


        # Yield every frame to the browser event loop (required by Pygbag).
        await asyncio.sleep(0)

    # =========================================================================
    # SHUTDOWN
    # =========================================================================
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())