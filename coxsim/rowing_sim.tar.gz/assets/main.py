import asyncio
import math
import importlib
import os

import pygame  # type: ignore[reportMissingImports]

import course
import settings

from boat import Boat
from controls import ControlState, coast_all_rowers, handle_keyboard_event, oars_are_down
from environment import calculate_coxswain_side_air_force, calculate_forward_air_force, calculate_section_side_air_force
from graphics import (
    Camera,
    draw_boat,
    draw_camera_label,
    draw_collision_messages,
    draw_control_hud,
    draw_course,
    draw_hud,
    draw_reset_button,
    get_reset_button_rect,
    get_warning_close_button_rect)
from hydrodynamics import calculate_longitudinal_drag, calculate_rudder_force, calculate_section_lateral_force, calculate_skeg_force
from rowing import calculate_forward_force, calculate_hold_water_force, calculate_reverse_force, is_drive_phase


# =============================================================================
# COURSE SELECTION MENU
# =============================================================================
def menu_buttons():
    center = settings.WINDOW_WIDTH // 2
    return {
        "lake": pygame.Rect(center - 230, 300, 460, 68),
        "river": pygame.Rect(center - 230, 392, 460, 68)}


def draw_course_menu():
    screen.fill((24, 39, 51))
    font = pygame.font.Font(None, 54)
    small_font = pygame.font.Font(None, 27)
    title = font.render("SELECT A COURSE", True, "white")
    screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 205)))

    lake_exists = os.path.exists(os.path.join(os.path.dirname(__file__), "course_lake.py"))
    for name, rectangle in menu_buttons().items():
        enabled = (name == "river" or lake_exists)
        color = (49, 109, 138) if enabled else (82, 82, 82)
        pygame.draw.rect(screen, color, rectangle, border_radius=9)
        pygame.draw.rect(screen, (204, 220, 226), rectangle, 2, border_radius=9)
        label = "LAKE MAXINKUCKEE" if name == "lake" else "HEAD OF THE CHARLES"
        text = small_font.render(label, True, "white")
        screen.blit(text, text.get_rect(center=rectangle.center))

    if not lake_exists:
        note = small_font.render("To enable the lake, save your original lake course.py as course_lake.py", True, (245, 190, 125))
        screen.blit(note, note.get_rect(center=(settings.WINDOW_WIDTH // 2, 505)))

    help_text = small_font.render("Click a course or press 1 / 2. Press ESC while driving to return here.", True, (200, 212, 222))
    screen.blit(help_text, help_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 558)))


def launch_course(course_name):
    global boat, control_state, camera, simulation_time
    global warning_message, crash_message, dock_contact, docked, simulation_crashed
    global current_course, resolve_course_collisions

    course.activate_course(course_name)
    import collisions
    # Reload shoreline and dock collision geometry after every course change.
    importlib.reload(collisions)
    resolve_course_collisions = collisions.resolve_course_collisions
    boat, control_state, camera = reset_simulation()
    simulation_time = 0.0
    warning_message = None
    crash_message = None
    dock_contact = False
    docked = False
    simulation_crashed = False
    current_course = course_name


# =============================================================================
# BLADE SIDE POSITION
# =============================================================================

def get_blade_sideways(seat):
    # Positive sideways is port; negative sideways is starboard.
    if seat in settings.PORT_SEATS:
        return settings.OAR_BLADE_CENTER_FROM_CENTERLINE

    return -settings.OAR_BLADE_CENTER_FROM_CENTERLINE


# =============================================================================
# RESET SIMULATION
# =============================================================================

def reset_simulation():
    # Recreate every changing simulation object so reset matches a fresh launch.
    new_boat = Boat()
    new_control_state = ControlState()
    new_camera = Camera()

    new_boat.x = course.START_X
    new_boat.y = course.START_Y
    new_boat.heading = math.radians(course.START_HEADING_DEGREES)

    new_camera.follow(new_boat)

    return new_boat, new_control_state, new_camera


# =============================================================================
# SETUP
# =============================================================================

pygame.init()
pygame.display.set_caption("Coxswain Simulator")

screen = pygame.display.set_mode((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))
clock = pygame.time.Clock()

debug_font = pygame.font.Font(None, settings.DEBUG_HUD_FONT_SIZE)
control_font = pygame.font.Font(None, settings.CONTROL_HUD_FONT_SIZE)

boat = None
control_state = None
camera = None
current_course = None
resolve_course_collisions = None

simulation_time = 0.0

warning_message = None
crash_message = None

dock_contact = False
docked = False
simulation_crashed = False


# =============================================================================
# MAIN LOOP
# =============================================================================

async def main():
    global boat, control_state, camera, current_course, simulation_time
    global warning_message, crash_message, dock_contact, docked, simulation_crashed

    running = True

    while running:
        # -------------------------------------------------------------------------
        # TIME
        # -------------------------------------------------------------------------
        dt = clock.tick(settings.FPS) / 1000.0

        if current_course is not None and not simulation_crashed:
            simulation_time += dt


        # -------------------------------------------------------------------------
        # EVENTS
        # -------------------------------------------------------------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif current_course is None:
                requested = None
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    requested = next((name for name, button in menu_buttons().items() if button.collidepoint(event.pos)), None)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_1:
                        requested = "lake"
                    elif event.key == pygame.K_2:
                        requested = "river"

                if requested is not None:
                    if requested == "river" or os.path.exists(os.path.join(os.path.dirname(__file__), "course_lake.py")):
                        launch_course(requested)

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                current_course = None

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33).collidepoint(event.pos):
                    current_course = None
                    continue
                if get_reset_button_rect().collidepoint(event.pos):
                    boat, control_state, camera = reset_simulation()

                    simulation_time = 0.0

                    warning_message = None
                    crash_message = None

                    dock_contact = False
                    docked = False
                    simulation_crashed = False

                elif warning_message is not None and get_warning_close_button_rect().collidepoint(event.pos):
                    warning_message = None

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    boat, control_state, camera = reset_simulation()

                    simulation_time = 0.0

                    warning_message = None
                    crash_message = None

                    dock_contact = False
                    docked = False
                    simulation_crashed = False

                elif event.key == pygame.K_m:
                    camera.toggle_overview()

                elif event.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
                    camera.change_zoom(settings.CAMERA_ZOOM_FACTOR)

                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    camera.change_zoom(1.0 / settings.CAMERA_ZOOM_FACTOR)

                elif not simulation_crashed:
                    handle_keyboard_event(control_state, event)


        if current_course is None:
            draw_course_menu()
            pygame.display.flip()
            await asyncio.sleep(0)
            continue

        # =========================================================================
        # PHYSICS
        # =========================================================================

        if not simulation_crashed:
            # ---------------------------------------------------------------------
            # ROWING FORCE - DRIVE PHASE ONLY
            # ---------------------------------------------------------------------
            if is_drive_phase(simulation_time, control_state.stroke_rate):
                for section in settings.ROWER_SECTIONS:
                    for seat in section["rowers"]:
                        if not oars_are_down(control_state, seat):
                            continue

                        rowing_state = control_state.rower_states[seat]
                        blade_sideways = get_blade_sideways(seat)

                        if rowing_state == "forward":
                            rowing_force = calculate_forward_force(boat, 1, control_state.stroke_rate)
                            boat.apply_force(rowing_force, 0.0, section["position"], blade_sideways)

                        elif rowing_state == "backward":
                            rowing_force = calculate_reverse_force(boat, 1, control_state.stroke_rate)
                            boat.apply_force(rowing_force, 0.0, section["position"], blade_sideways)


            # ---------------------------------------------------------------------
            # HOLD WATER
            # ---------------------------------------------------------------------
            for section in settings.ROWER_SECTIONS:
                for seat in section["rowers"]:
                    rowing_state = control_state.rower_states[seat]

                    if rowing_state == "hold" and oars_are_down(control_state, seat):
                        blade_sideways = get_blade_sideways(seat)
                        hold_force = calculate_hold_water_force(boat, blade_sideways)

                        boat.apply_force(hold_force, 0.0, section["position"], blade_sideways)


            # ---------------------------------------------------------------------
            # HYDRODYNAMICS - LONGITUDINAL DRAG
            # ---------------------------------------------------------------------
            longitudinal_drag = calculate_longitudinal_drag(boat)
            boat.apply_force(longitudinal_drag, 0.0)


            # ---------------------------------------------------------------------
            # HYDRODYNAMICS - HULL LATERAL FORCES
            # ---------------------------------------------------------------------
            for section in settings.HULL_SECTIONS:
                lateral_force = calculate_section_lateral_force(boat, section)
                boat.apply_force(0.0, lateral_force, section["position"], 0.0)


            # ---------------------------------------------------------------------
            # RUDDER
            # ---------------------------------------------------------------------
            rudder_force = calculate_rudder_force(boat, control_state.rudder_angle)
            boat.apply_force(0.0, rudder_force, settings.STEERING_LEVER_ARM, 0.0)


            # ---------------------------------------------------------------------
            # SKEG
            # ---------------------------------------------------------------------
            skeg_force = calculate_skeg_force(boat)
            boat.apply_force(0.0, skeg_force, settings.STEERING_LEVER_ARM, 0.0)


            # ---------------------------------------------------------------------
            # AERODYNAMICS - FORWARD
            # ---------------------------------------------------------------------
            forward_air_force = calculate_forward_air_force(boat)
            boat.apply_force(forward_air_force, 0.0, 0.0, 0.0)


            # ---------------------------------------------------------------------
            # AERODYNAMICS - HULL SECTIONS SIDEWAYS
            # ---------------------------------------------------------------------
            for section in settings.HULL_SECTIONS:
                side_air_force = calculate_section_side_air_force(boat, section)
                boat.apply_force(0.0, side_air_force, section["position"], 0.0)


            # ---------------------------------------------------------------------
            # AERODYNAMICS - COXSWAIN SIDEWAYS
            # ---------------------------------------------------------------------
            coxswain_side_air_force = calculate_coxswain_side_air_force(boat)
            boat.apply_force(0.0, coxswain_side_air_force, settings.COXSWAIN_POSITION, 0.0)


            # ---------------------------------------------------------------------
            # UPDATE BOAT STATE
            # ---------------------------------------------------------------------
            previous_x = boat.x
            previous_y = boat.y
            previous_pose = (boat.x, boat.y, boat.heading)

            boat.update(dt)


            # ---------------------------------------------------------------------
            # COURSE COLLISIONS
            # ---------------------------------------------------------------------
            collision_result = resolve_course_collisions(boat, control_state.boat_collision_local_points, previous_pose, dt)


            # ---------------------------------------------------------------------
            # SPEED HISTORY
            # ---------------------------------------------------------------------
            # Record the resolved movement for the 5-second rolling average.
            # This average is used only to decide when a gentle dock contact has
            # settled enough to count as DOCKED.
            distance_travelled = math.hypot(boat.x - previous_x, boat.y - previous_y)

            boat.record_speed_history(dt, distance_travelled)

            average_speed = boat.get_average_speed()


            # ---------------------------------------------------------------------
            # COLLISION BEHAVIOR
            # ---------------------------------------------------------------------
            if collision_result is not None:
                collision_level = collision_result["level"]
                collision_type = collision_result["type"]
                inbound_speed = collision_result["impact_speed"]

                # Collision severity is classified in collisions.py using the
                # inward speed of the actual contact point.
                if collision_level == "contact":
                    coast_all_rowers(control_state)

                    if collision_type == "dock":
                        dock_contact = True

                elif collision_level == "bump":
                    dock_contact = False

                    coast_all_rowers(control_state)
                    control_state.rudder_angle = 0.0

                    if collision_type == "dock":
                        warning_message = f"WARNING: Dock collision at {inbound_speed:.2f} m/s"

                    else:
                        warning_message = f"WARNING: Shore collision at {inbound_speed:.2f} m/s"

                elif collision_level == "crash":
                    dock_contact = False

                    if collision_type == "dock":
                        crash_message = f"CRASH: Dock collision at {inbound_speed:.2f} m/s"

                    else:
                        crash_message = f"CRASH: Shore collision at {inbound_speed:.2f} m/s"

                    simulation_crashed = True


            # ---------------------------------------------------------------------
            # SUCCESSFUL DOCKING
            # ---------------------------------------------------------------------
            # A gentle dock contact begins when inbound contact-point speed is below
            # the contact threshold. Once in that contact state, wait for the
            # 5-second rolling average speed to fall below the docking threshold.
            if dock_contact and average_speed < settings.COLLISION_DOCKED_MAX_SPEED:
                docked = True


            # ---------------------------------------------------------------------
            # CAMERA
            # ---------------------------------------------------------------------
            camera.follow(boat)


        # =========================================================================
        # DRAW FRAME
        # =========================================================================

        draw_course(screen, camera)
        draw_boat(screen, boat, camera, control_state, simulation_time)

        draw_hud(screen, debug_font, boat)
        draw_control_hud(screen, control_font, control_state)
        draw_camera_label(screen, debug_font, camera)

        draw_collision_messages(screen, control_font, warning_message, crash_message, docked)
        draw_reset_button(screen, control_font)

        menu_rect = pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33)
        pygame.draw.rect(screen, (45, 45, 45), menu_rect)
        pygame.draw.rect(screen, "white", menu_rect, 2)
        menu_text = control_font.render("COURSES", True, "white")
        screen.blit(menu_text, menu_text.get_rect(center=menu_rect.center))

        pygame.display.flip()


        # Yield every frame to the browser event loop (required by Pygbag).
        await asyncio.sleep(0)

    # =========================================================================
    # SHUTDOWN
    # =========================================================================
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())