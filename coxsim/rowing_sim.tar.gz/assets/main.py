"""Launch the desktop/Pygbag Coxswain Simulator.

Physics is owned by physics_engine.simulation.Simulation. This module only handles
Pygame input, the course menu, frame timing, and calls to the renderer.
"""

import asyncio

import pygame

import settings
from physics_engine.controls import handle_keyboard_event
from physics_engine.simulation import Simulation
from pygame_graphics.boat import draw_boat, draw_foamy_wake, draw_heading_guide
from pygame_graphics.camera import Camera, draw_bridge_overpasses, draw_course
from pygame_graphics.hud import (
    draw_camera_label,
    draw_collision_messages,
    draw_com_trail,
    draw_control_hud,
    draw_hud,
    draw_reset_button,
    get_reset_button_rect,
    get_warning_close_button_rect,
)
from pygame_graphics.menu import draw_course_menu, menu_buttons
from pygame_graphics.trails import WakeTrail
from pygame_graphics.timing import BoatPose, FrameClock, interpolate_pose


# =============================================================================
# PYGAME APPLICATION
# =============================================================================
class SimulatorApp:
    """Keep UI state separate from the renderer-independent simulation."""

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Coxswain Simulator")

        self.screen = pygame.display.set_mode((settings.WINDOW_WIDTH, settings.WINDOW_HEIGHT))
        self.clock = pygame.time.Clock()
        self.debug_font = pygame.font.Font(None, settings.DEBUG_HUD_FONT_SIZE)
        self.control_font = pygame.font.Font(None, settings.CONTROL_HUD_FONT_SIZE)

        self.simulation = None
        self.camera = None
        self.wake_trail = None
        self.dismissed_warning = None
        self.frame_clock = FrameClock()
        self.previous_pose = None
        self.current_pose = None
        self.show_performance = False
        self.performance_label = None
        self.performance_elapsed = 0.0
        self.performance_frames = 0
        self.render_time_ms = 0.0
        self.physics_steps = 0

    # -------------------------------------------------------------------------
    # START, RESET AND CHANGE COURSE
    # -------------------------------------------------------------------------
    def select_course(self, course_id):
        self.simulation = Simulation(course_id)
        self.camera = Camera()
        self.camera.follow(self.simulation.boat)
        self.wake_trail = WakeTrail()
        self.dismissed_warning = None
        self.frame_clock.reset()
        self.current_pose = BoatPose.capture(self.simulation.boat)
        self.previous_pose = self.current_pose

    def reset(self):
        self.simulation.reset()
        self.camera = Camera()
        self.camera.follow(self.simulation.boat)
        self.wake_trail = WakeTrail()
        self.dismissed_warning = None
        self.frame_clock.reset()
        self.current_pose = BoatPose.capture(self.simulation.boat)
        self.previous_pose = self.current_pose

    # -------------------------------------------------------------------------
    # KEYBOARD AND MOUSE EVENTS
    # -------------------------------------------------------------------------
    def handle_menu_event(self, event):
        requested_course = None

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            requested_course = next(
                (course_id for course_id, button in menu_buttons().items() if button.collidepoint(event.pos)),
                None,
            )
        elif event.type == pygame.KEYDOWN:
            course_keys = {pygame.K_1: "max", pygame.K_2: "charles",
                           pygame.K_3: "nathan", pygame.K_4: "milwaukee"}
            requested_course = course_keys.get(event.key)

        if requested_course is not None:
            self.select_course(requested_course)

    def handle_simulation_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            self.simulation = None
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            course_button = pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33)
            if course_button.collidepoint(event.pos):
                self.simulation = None
            elif get_reset_button_rect().collidepoint(event.pos):
                self.reset()
            elif self.simulation.warning_message is not None and get_warning_close_button_rect().collidepoint(event.pos):
                self.dismissed_warning = self.simulation.warning_message
            return

        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_r:
            self.reset()
        elif event.key == pygame.K_F3:
            self.show_performance = not self.show_performance
        elif event.key == pygame.K_m:
            self.camera.toggle_overview()
        elif event.key == pygame.K_b:
            self.camera.show_collision_box = not self.camera.show_collision_box
        elif event.key in (pygame.K_EQUALS, pygame.K_PLUS, pygame.K_KP_PLUS):
            self.camera.change_zoom(settings.CAMERA_ZOOM_FACTOR)
        elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.camera.change_zoom(1.0 / settings.CAMERA_ZOOM_FACTOR)
        elif not self.simulation.simulation_crashed:
            handle_keyboard_event(self.simulation.controls, event)

    # -------------------------------------------------------------------------
    # FRAME UPDATE AND RENDERING
    # -------------------------------------------------------------------------
    def draw_simulation(self, boat_pose):
        simulation = self.simulation
        boat = simulation.boat
        controls = simulation.controls
        trail = simulation.com_trail
        time = simulation.simulation_time

        draw_course(self.screen, self.camera)
        draw_com_trail(self.screen, self.camera, trail)
        draw_foamy_wake(self.screen, self.camera, self.wake_trail, time)
        draw_heading_guide(self.screen, boat_pose, self.camera)
        draw_boat(self.screen, boat_pose, self.camera, controls, time)
        draw_bridge_overpasses(self.screen, self.camera)

        draw_hud(self.screen, self.debug_font, boat, trail)
        draw_control_hud(self.screen, self.control_font, controls, boat, trail)
        draw_camera_label(self.screen, self.debug_font, self.camera)

        current_warning = simulation.warning_message
        if current_warning == self.dismissed_warning:
            current_warning = None
        draw_collision_messages(self.screen, self.control_font, current_warning,
                                simulation.crash_message, simulation.docked)
        draw_reset_button(self.screen, self.control_font)

        course_button = pygame.Rect(14, settings.WINDOW_HEIGHT - 76, 120, 33)
        pygame.draw.rect(self.screen, (45, 45, 45), course_button)
        pygame.draw.rect(self.screen, "white", course_button, 2)
        text = self.control_font.render("COURSES", True, "white")
        self.screen.blit(text, text.get_rect(center=course_button.center))

    # -------------------------------------------------------------------------
    # PHYSICS AND DISPLAY CLOCKS
    # -------------------------------------------------------------------------
    def advance_physics(self, dt):
        self.previous_pose = self.current_pose
        self.simulation.step(dt)
        self.current_pose = BoatPose.capture(self.simulation.boat)
        self.wake_trail.record(self.simulation.boat, self.simulation.simulation_time)

    def update_performance_counter(self, elapsed, rendering_ms, physics_steps):
        self.performance_elapsed += elapsed
        self.performance_frames += 1
        self.render_time_ms = rendering_ms
        self.physics_steps = physics_steps

        if self.performance_elapsed >= 0.5:
            fps = self.performance_frames / self.performance_elapsed
            label_text = f"FPS: {fps:.0f}   Draw: {rendering_ms:.1f} ms   Physics steps: {physics_steps}"
            font = self.debug_font
            self.performance_label = font.render(label_text, True, (241, 247, 240))
            self.performance_elapsed = 0.0
            self.performance_frames = 0

    async def run(self):
        running = True

        while running:
            elapsed = self.clock.tick(settings.FPS) / 1000.0

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif self.simulation is None:
                    self.handle_menu_event(event)
                else:
                    self.handle_simulation_event(event)

            if not running:
                break

            if self.simulation is None:
                # Time spent on the menu never accumulates as physics debt.
                self.frame_clock.reset()
                draw_course_menu(self.screen)
            else:
                fraction, physics_steps = self.frame_clock.advance(elapsed, self.advance_physics)
                if self.simulation.simulation_crashed:
                    boat_pose = self.current_pose
                else:
                    boat_pose = interpolate_pose(self.previous_pose, self.current_pose, fraction)

                self.camera.follow(boat_pose)
                drawing_start = pygame.time.get_ticks()
                self.draw_simulation(boat_pose)
                render_time_ms = float(pygame.time.get_ticks() - drawing_start)
                self.update_performance_counter(elapsed, render_time_ms, physics_steps)

                if self.show_performance and self.performance_label is not None:
                    label = self.performance_label
                    position = (self.screen.get_width() // 2 - label.get_width() // 2, 8)
                    pygame.draw.rect(self.screen, (29, 51, 61), label.get_rect(topleft=position).inflate(12, 8),
                                     border_radius=4)
                    self.screen.blit(label, position)

            pygame.display.flip()
            # Pygbag requires yielding to the browser event loop each frame.
            await asyncio.sleep(0)

        pygame.quit()


# =============================================================================
# ENTRY POINT
# =============================================================================
async def main():
    application = SimulatorApp()
    await application.run()


if __name__ == "__main__":
    asyncio.run(main())
