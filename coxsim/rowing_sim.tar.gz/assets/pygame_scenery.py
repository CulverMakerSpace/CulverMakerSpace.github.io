"""Pygame-only scenery for the overhead Coxswain Simulator.

Purely visual: uses the same course geometry as the physics engine but never
mutates it. Generated graphics are reused instead of recomputed every frame.
Compatible with desktop Pygame and Pygbag (no external assets or libraries).
"""

import math
import random

import pygame

import course
import settings


# =============================================================================
# COLORS AND DRAWING CONSTANTS
# =============================================================================
WATER_BASE = (55, 125, 160)
LAND_BASE = (87, 114, 81)
CITY_GROUND = (111, 119, 115)
SHORE_LIGHT = (178, 215, 202)
SHORE_SAND = (181, 187, 148)
DOCK_TOP = (119, 106, 91)
DOCK_SHADOW = (53, 64, 67)


# =============================================================================
# LIGHTWEIGHT GEOMETRY
# =============================================================================
def soften_polygon(vertices):
    """A visual-only, two-pass shoreline smoothing (physics stays untouched)."""
    points = list(vertices)
    if len(points) < 4:
        return points
    for _ in range(2):
        softened = []
        for index, start in enumerate(points):
            end = points[(index + 1) % len(points)]
            softened.append((0.84 * start[0] + 0.16 * end[0], 0.84 * start[1] + 0.16 * end[1]))
            softened.append((0.16 * start[0] + 0.84 * end[0], 0.16 * start[1] + 0.84 * end[1]))
        points = softened
    return points


def polygon_from_centerline(path, half_width):
    """Create a continuous dock polygon with mitered corners, not rectangles."""
    if len(path) < 2:
        return []
    left = []
    right = []
    for index, point in enumerate(path):
        if index == 0:
            direction = (path[1][0] - point[0], path[1][1] - point[1])
            length = math.hypot(*direction)
            if length < 0.0001:
                continue
            normal = (-direction[1] / length, direction[0] / length)
            scale = half_width
        elif index == len(path) - 1:
            direction = (point[0] - path[index - 1][0], point[1] - path[index - 1][1])
            length = math.hypot(*direction)
            if length < 0.0001:
                continue
            normal = (-direction[1] / length, direction[0] / length)
            scale = half_width
        else:
            prev = (point[0] - path[index - 1][0], point[1] - path[index - 1][1])
            following = (path[index + 1][0] - point[0], path[index + 1][1] - point[1])
            first_length = max(0.0001, math.hypot(*prev))
            second_length = max(0.0001, math.hypot(*following))
            prev_normal = (-prev[1] / first_length, prev[0] / first_length)
            next_normal = (-following[1] / second_length, following[0] / second_length)
            combined = (prev_normal[0] + next_normal[0], prev_normal[1] + next_normal[1])
            combined_length = math.hypot(*combined)
            if combined_length < 0.0001:
                normal = next_normal
                scale = half_width
            else:
                normal = (combined[0] / combined_length, combined[1] / combined_length)
                projection = abs(normal[0] * next_normal[0] + normal[1] * next_normal[1])
                scale = min(half_width * 2.0, half_width / max(0.45, projection))
        left.append((point[0] + normal[0] * scale, point[1] + normal[1] * scale))
        right.append((point[0] - normal[0] * scale, point[1] - normal[1] * scale))
    return left + list(reversed(right))


def point_in_polygon(x, y, vertices):
    inside = False
    prev_x, prev_y = vertices[-1]
    for curr_x, curr_y in vertices:
        if ((curr_y > y) != (prev_y > y)) and x < curr_x + (y - curr_y) * (prev_x - curr_x) / (prev_y - curr_y):
            inside = not inside
        prev_x, prev_y = curr_x, curr_y
    return inside


def is_water(x, y, polygons, holes):
    return any(point_in_polygon(x, y, polygon) for polygon in polygons) and not any(
        point_in_polygon(x, y, hole) for hole in holes)


def on_screen(center, screen_size, margin=160):
    return -margin <= center[0] <= screen_size[0] + margin and -margin <= center[1] <= screen_size[1] + margin


# =============================================================================
# PROCEDURAL TILES (GENERATED ONCE, NO IMAGE FILES)
# =============================================================================
def make_texture_tiles():
    rng = random.Random(1944)
    size = 256
    water = pygame.Surface((size, size), pygame.SRCALPHA)
    land = pygame.Surface((size, size), pygame.SRCALPHA)
    city = pygame.Surface((size, size), pygame.SRCALPHA)

    # Broad, very faint patches break up the flat water fill without
    # conspicuous cartoon waves. All marks are created once at startup.
    for _ in range(24):
        x = rng.randrange(size)
        y = rng.randrange(size)
        radius = rng.randrange(12, 45)
        color = (132, 206, 221, rng.randrange(7, 16)) if rng.randrange(2) else (11, 57, 87, rng.randrange(7, 16))
        pygame.draw.ellipse(water, color, (x - radius, y - radius // 3, radius * 2, radius // 2))

    # Fine, translucent ripples with irregular length and brightness.
    for _ in range(145):
        x = rng.randrange(size)
        y = rng.randrange(size)
        width = rng.randrange(5, 31)
        pygame.draw.line(water, (220, 242, 242, rng.randrange(11, 33)), (x, y), (min(size - 1, x + width), y), 1)
    for _ in range(130):
        x = rng.randrange(size)
        y = rng.randrange(size)
        pygame.draw.circle(water, (11, 61, 87, rng.randrange(8, 24)), (x, y), rng.choice((1, 2)))

    # Grass/mottled soil. Small marks read as foliage from normal zoom.
    for _ in range(850):
        x = rng.randrange(size)
        y = rng.randrange(size)
        color = (174, 194, 131, rng.randrange(9, 40)) if rng.randrange(3) else (31, 67, 43, rng.randrange(10, 43))
        pygame.draw.circle(land, color, (x, y), rng.choice((1, 1, 2, 3)))

    # Concrete/city grid mottling, deliberately subdued.
    for _ in range(1000):
        x = rng.randrange(size)
        y = rng.randrange(size)
        color = (230, 226, 206, rng.randrange(5, 23)) if rng.randrange(2) else (35, 50, 57, rng.randrange(5, 24))
        pygame.draw.rect(city, color, (x, y, rng.randrange(1, 4), rng.randrange(1, 4)))
    return water, land, city


def tile_texture(screen, tile, offset=(0, 0)):
    size = tile.get_width()
    shift_x = int(offset[0]) % size
    shift_y = int(offset[1]) % size
    for y in range(shift_y - size, screen.get_height(), size):
        for x in range(shift_x - size, screen.get_width(), size):
            screen.blit(tile, (x, y))


# =============================================================================
# COURSE-SPECIFIC DECORATIONS
# =============================================================================
class PygameScenery:
    def __init__(self):
        self.course_id = None
        self.tiles = None
        self.water_polygons = []
        self.land_holes = []
        self.smoothed_water = []
        self.smoothed_holes = []
        self.dock_polygons = []
        self.buildings = []
        self.trees = []
        self.roads = []
        self.urban = False
        self.frame_water = None
        self.frame_mask = None
        self.frame_docks = None
        self.frame_size = None

    def prepare(self):
        course_id = course.active_course_name
        if self.course_id == course_id:
            return
        self.course_id = course_id
        self.urban = course_id in ("charles", "milwaukee")
        self.water_polygons = list(getattr(course, "WATER_POLYGONS", [course.LAKE_SHORELINE]))
        self.land_holes = list(getattr(course, "LAND_HOLES", []))
        self.smoothed_water = [soften_polygon(p) for p in self.water_polygons]
        self.smoothed_holes = [soften_polygon(p) for p in self.land_holes]
        self.dock_polygons = [polygon_from_centerline(path, settings.DOCK_DISPLAY_WIDTH / 2.0)
                              for path in course.DOCK_PATHS]
        self.buildings = []
        self.trees = []
        self.roads = []
        rng = random.Random(2100 + sum(ord(ch) for ch in course_id))

        # Roads/buildings/foliage are decorative and generated on the LAND side
        # of a real shoreline. They are not mapped structures/collision objects.
        for shoreline in self.water_polygons:
            for index, a in enumerate(shoreline):
                b = shoreline[(index + 1) % len(shoreline)]
                dx = b[0] - a[0]
                dy = b[1] - a[1]
                length = math.hypot(dx, dy)
                if length < 5.0:
                    continue
                tangent = (dx / length, dy / length)
                normal = (-tangent[1], tangent[0])
                midpoint = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
                if is_water(midpoint[0] + normal[0] * 12, midpoint[1] + normal[1] * 12,
                            self.water_polygons, self.land_holes):
                    normal = (-normal[0], -normal[1])

                if self.urban:
                    road_a = (a[0] + normal[0] * 16, a[1] + normal[1] * 16)
                    road_b = (b[0] + normal[0] * 16, b[1] + normal[1] * 16)
                    self.roads.append((road_a, road_b))

                spacing = 36.0 if self.urban else 58.0
                for sample in range(max(1, math.ceil(length / spacing))):
                    ratio = (sample + 0.5) / max(1, math.ceil(length / spacing))
                    shore_x = a[0] + dx * ratio
                    shore_y = a[1] + dy * ratio
                    distance = rng.uniform(27, 64) if self.urban else rng.uniform(13, 55)
                    center = (shore_x + normal[0] * distance, shore_y + normal[1] * distance)
                    if is_water(*center, self.water_polygons, self.land_holes):
                        continue
                    if self.urban:
                        if rng.random() < 0.11:
                            continue
                        width = rng.uniform(10, 25)
                        depth = rng.uniform(12, 29)
                        corners = []
                        for along, across in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                            corners.append((center[0] + tangent[0] * width * along / 2 + normal[0] * depth * across / 2,
                                            center[1] + tangent[1] * width * along / 2 + normal[1] * depth * across / 2))
                        tone = rng.randrange(4)
                        self.buildings.append((center, corners, tone))
                    else:
                        self.trees.append((center, rng.uniform(3, 7), rng.randrange(3)))
                        if rng.random() < 0.6:
                            second_center = (center[0] + rng.uniform(-8, 8), center[1] + rng.uniform(-8, 8))
                            if not is_water(*second_center, self.water_polygons, self.land_holes):
                                self.trees.append((second_center, rng.uniform(2, 6), rng.randrange(3)))

    def ensure_buffers(self, size):
        if self.tiles is None:
            self.tiles = make_texture_tiles()
        if self.frame_size != size:
            self.frame_size = size
            self.frame_water = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_mask = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_docks = pygame.Surface(size, pygame.SRCALPHA)

    def draw_ground(self, screen, camera, convert):
        self.prepare()
        self.ensure_buffers(screen.get_size())
        water_texture, land_texture, city_texture = self.tiles
        ground = CITY_GROUND if self.urban else LAND_BASE
        screen.fill(ground)
        offset = (-camera.x * 0.75, camera.y * 0.75)
        tile_texture(screen, city_texture if self.urban else land_texture, offset)

        if self.urban:
            for a, b in self.roads:
                start = convert(*a, camera)
                end = convert(*b, camera)
                if not on_screen(start, screen.get_size(), 300) and not on_screen(end, screen.get_size(), 300):
                    continue
                pygame.draw.line(screen, (83, 90, 93), start, end, max(3, int(8 * camera.get_view()[2])))
                pygame.draw.line(screen, (138, 140, 134), start, end, max(1, int(camera.get_view()[2])))
            for center, corners, tone in self.buildings:
                screen_center = convert(*center, camera)
                if not on_screen(screen_center, screen.get_size()):
                    continue
                poly = [convert(*corner, camera) for corner in corners]
                shadow = [(x + 3, y + 4) for x, y in poly]
                pygame.draw.polygon(screen, (67, 75, 76), shadow)
                roof_colors = [(170, 176, 168), (153, 159, 157), (185, 169, 149), (133, 147, 152)]
                pygame.draw.polygon(screen, roof_colors[tone], poly)
                pygame.draw.lines(screen, (89, 101, 103), True, poly, 1)
                if camera.get_view()[2] >= 2.0:
                    pygame.draw.circle(screen, (110, 118, 117), screen_center, max(1, int(1.2 * camera.get_view()[2])))
        else:
            for center, radius_m, shade in self.trees:
                screen_center = convert(*center, camera)
                if not on_screen(screen_center, screen.get_size(), 40):
                    continue
                radius = max(1, int(radius_m * camera.get_view()[2]))
                if radius > 70:
                    continue
                pygame.draw.circle(screen, (49, 79, 53), (screen_center[0] + 2, screen_center[1] + 2), radius)
                pygame.draw.circle(screen, [(78, 114, 63), (92, 123, 69), (65, 102, 59)][shade], screen_center, radius)
                if radius >= 5:
                    pygame.draw.circle(screen, (115, 147, 87), (screen_center[0] - 1, screen_center[1] - 2), max(1, radius // 3))

    def draw_water(self, screen, camera, convert):
        self.frame_water.fill((0, 0, 0, 0))
        self.frame_mask.fill((0, 0, 0, 0))
        self.frame_docks.fill((0, 0, 0, 0))
        water_points = []
        for polygon in self.smoothed_water:
            points = [convert(x, y, camera) for x, y in polygon]
            water_points.append(points)
            if len(points) >= 3:
                pygame.draw.polygon(self.frame_water, (*WATER_BASE, 255), points)
                pygame.draw.polygon(self.frame_mask, (255, 255, 255, 255), points)
        hole_points = []
        for polygon in self.smoothed_holes:
            points = [convert(x, y, camera) for x, y in polygon]
            hole_points.append(points)
            if len(points) >= 3:
                pygame.draw.polygon(self.frame_water, (0, 0, 0, 0), points)
                pygame.draw.polygon(self.frame_mask, (0, 0, 0, 0), points)

        # Texture lies under a precomputed shoreline mask. This is one inexpensive
        # blend pass, not thousands of polygon intersection tests each frame.
        water_texture = self.tiles[0]
        offset = (camera.x * 0.55, -camera.y * 0.55)
        tile_texture(self.frame_water, water_texture, offset)
        self.frame_water.blit(self.frame_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        screen.blit(self.frame_water, (0, 0))

        for points in water_points:
            if len(points) >= 3:
                pygame.draw.lines(screen, (76, 154, 166), True, points, 5)
                pygame.draw.lines(screen, SHORE_LIGHT, True, points, 2)
        for points in hole_points:
            if len(points) >= 3:
                pygame.draw.polygon(screen, CITY_GROUND if self.urban else LAND_BASE, points)
                pygame.draw.lines(screen, SHORE_SAND, True, points, 2)

    def draw_docks(self, screen, camera, convert):
        _, _, zoom = camera.get_view()
        if not self.dock_polygons:
            return
        for polygon in self.dock_polygons:
            if len(polygon) < 3:
                continue
            screen_points = [convert(x, y, camera) for x, y in polygon]
            pygame.draw.polygon(self.frame_docks, (*DOCK_TOP, 255), screen_points)

        # All dock shapes are filled before any plank detailing: no outlines
        # between overlapping segments of the same pier or a T-join.
        if zoom > 1.5:
            for path in course.DOCK_PATHS:
                for a, b in zip(path, path[1:]):
                    begin = convert(*a, camera)
                    end = convert(*b, camera)
                    dx = end[0] - begin[0]
                    dy = end[1] - begin[1]
                    length = math.hypot(dx, dy)
                    if length < 8:
                        continue
                    ux = dx / length
                    uy = dy / length
                    nx = -uy
                    ny = ux
                    spacing = max(10.0, 0.85 * zoom)
                    for index in range(1, min(90, int(length / spacing))):
                        amount = index * spacing
                        x = begin[0] + ux * amount
                        y = begin[1] + uy * amount
                        half_width = settings.DOCK_DISPLAY_WIDTH * zoom * 0.36
                        pygame.draw.line(self.frame_docks, (158, 146, 130, 135),
                                         (x - nx * half_width, y - ny * half_width),
                                         (x + nx * half_width, y + ny * half_width), 1)

        self.frame_docks.blit(self.frame_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
        screen.blit(self.frame_docks, (0, 0))

    def draw_bridges(self, screen, camera, convert):
        _, _, zoom = camera.get_view()
        for bridge in getattr(course, "BRIDGE_PATHS", []):
            path = bridge.get("points", [])
            if len(path) < 2:
                continue
            name = bridge.get("name", "").lower()
            pedestrian = "foot" in name or "path" in name or "walk" in name
            rail = "rail" in name or "subdivision" in name or "junction" in name or "yard" in name
            bridge_width = 3.8 if pedestrian else (5.0 if rail else 8.0)
            thick = max(3, round(bridge_width * zoom))
            points = [convert(x, y, camera) for x, y in path]
            if not any(on_screen(p, screen.get_size(), 300) for p in points):
                continue
            # Broad understructure, roadway, contrasting railings, lane details.
            offset_points = [(x + 3, y + 3) for x, y in points]
            pygame.draw.lines(screen, (34, 57, 67), False, offset_points, thick + 5)
            pygame.draw.lines(screen, (77, 83, 84), False, points, thick + 4)
            deck_color = (180, 171, 153) if pedestrian else ((123, 111, 99) if rail else (143, 148, 143))
            pygame.draw.lines(screen, deck_color, False, points, thick)
            if zoom >= 1.3:
                for a, b in zip(points, points[1:]):
                    dx = b[0] - a[0]
                    dy = b[1] - a[1]
                    length = math.hypot(dx, dy)
                    if length < 1.0:
                        continue
                    normal = (-dy / length, dx / length)
                    for side in (-1.0, 1.0):
                        shift = side * thick / 2.0
                        start = (a[0] + shift * normal[0], a[1] + shift * normal[1])
                        end = (b[0] + shift * normal[0], b[1] + shift * normal[1])
                        pygame.draw.line(screen, (215, 211, 196), start, end, max(1, round(0.32 * zoom)))
                    if not pedestrian:
                        pygame.draw.line(screen, (219, 213, 183) if not rail else (77, 73, 69), a, b, 1)


SCENERY = PygameScenery()
