COXSWAIN SIMULATOR - PERSISTENT KEYBOARD CONTROLS

Prep commands
-------------
Shift = all rowers
Q     = port / left-side rowers
P     = starboard / right-side rowers


Execution commands
------------------
W       = row forward
S       = row backward
Space   = coast
Enter   = hold water
I       = lift oars
O       = lower oars

Commands are persistent and require a prep command followed by an execution
command. Examples:

Shift, W       = all rowers forward
Shift, Enter   = all rowers coast
Q, Enter      = port side coast
P, Space       = starboard side hold water
Q, W, P, S     = port forward, then starboard backward
Shift, I       = lift all oars
Q, I           = lift port oars
P, O           = lower starboard oars


Stroke rate
-----------
Up Arrow       = increase 1 stroke/min
Down Arrow     = decrease 1 stroke/min

Default = 25 strokes/min
Minimum = 10 strokes/min
Maximum = 50 strokes/min


Rudder
------
Left Arrow     = 10 degrees toward port
Right Arrow    = 10 degrees toward starboard

Rudder position persists and is limited to +/- 30 degrees.


Camera controls
---------------
  M = toggle full-lake overview / follow-boat view
  + = zoom in
  - = zoom out