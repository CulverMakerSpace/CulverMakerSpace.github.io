COXSWAIN SIMULATOR - PERSISTENT KEYBOARD CONTROLS

Prep commands
-------------
Shift = all rowers
Q     = port / left-side rowers
P     = starboard / right-side rowers


Execution commands
------------------
W       = row forward
S       = row backward
Space   = coast
Enter   = hold water
I       = lift oars
O       = lower oars

Commands are persistent and require a prep command followed by an execution
command. Examples:

Shift, W       = all rowers forward
Shift, Enter   = all rowers coast
Q, Enter      = port side coast
P, Space       = starboard side hold water
Q, W, P, S     = port forward, then starboard backward
Shift, I       = lift all oars
Q, I           = lift port oars
P, O           = lower starboard oars


Stroke rate
-----------
Up Arrow       = increase 1 stroke/min
Down Arrow     = decrease 1 stroke/min

Default = 25 strokes/min
Minimum = 10 strokes/min
Maximum = 50 strokes/min


Rudder
------
Left Arrow     = 10 degrees toward port
Right Arrow    = 10 degrees toward starboard

Rudder position persists and is limited to +/- 30 degrees.


Camera controls
---------------
  M = toggle full-lake overview / follow-boat view
  + = zoom in
  - = zoom out

COURSE SELECTION (updated October 2026)
------------------------------------
At the course selection menu, click a button or press:
1  Lake Maxinkuckee
2  Head of the Charles
3  Nathan Benderson Park (NBP)
4  Milwaukee River (Menomonee confluence / downtown segment)

The two new courses are built from the GeoJSON files in source_data.
Start locations and headings are approximations, not official event starts.
NBP shows its main lake and mapped piers. Milwaukee shows the mapped
Menomonee/Milwaukee waterways; bridges are visual guides only, with no
bridge pier, clearance, or structural collision constraints.
The new course geometry is in course_nbp.py and course_milwaukee.py.
