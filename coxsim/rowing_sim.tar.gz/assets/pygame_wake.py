"""Pygame-only wake history: water disturbances stay at past hull positions.

This is a visual effect. Physics, collisions, and the Godot bridge never use it.
"""

import math
from collections import deque

import settings


# =============================================================================
# VISUAL WAKE SETTINGS
# =============================================================================
WAKE_MAX_AGE = 9.0                 # s, how long a surface ripple remains visible
WAKE_MIN_SPEED = 0.65             # m/s, don't create new foam near rest
WAKE_POINT_SPACING = 0.65         # m, limit memory and drawing work
WAKE_MAX_POINTS = 110


# =============================================================================
# WORLD-SPACE WAKE HISTORY
# =============================================================================
class WakeTrail:
    def __init__(self):
        self.points = deque(maxlen=WAKE_MAX_POINTS)
        self.direction = 0
        self.last_position = None


    def record(self, boat, simulation_time):
        """Remember where the wake source actually passed, not where it points now.

        For forward motion this is the stern tip; for reverse motion it is the
        bow tip. Both include the boat's heading at the *time* of the sample.
        """
        self._discard_old(simulation_time)

        forward_speed, _ = boat.get_velocity_components()
        if boat.get_speed() < WAKE_MIN_SPEED:
            return

        # Keep the previous end during strong lateral drift instead of
        # swapping stern and bow just because the longitudinal speed is ~0.
        if forward_speed > 0.25:
            direction = 1
        elif forward_speed < -0.25:
            direction = -1
        else:
            direction = self.direction or 1
        if direction != self.direction:
            self.points.clear()
            self.last_position = None
            self.direction = direction

        geometric_center = settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS
        hull_end = geometric_center - (settings.SHELL_LENGTH / 2.0) * direction
        world_x = boat.x + hull_end * math.cos(boat.heading)
        world_y = boat.y + hull_end * math.sin(boat.heading)
        new_position = (world_x, world_y)

        if self.last_position is not None:
            distance = math.dist(self.last_position, new_position)
            if distance < WAKE_POINT_SPACING:
                return

        self.points.append((world_x, world_y, float(simulation_time), boat.get_speed()))
        self.last_position = new_position


    def _discard_old(self, simulation_time):
        while self.points and simulation_time - self.points[0][2] > WAKE_MAX_AGE:
            self.points.popleft()

        if not self.points:
            self.last_position = None


    def visible_points(self, simulation_time):
        """Return active world-space points, oldest to newest."""
        self._discard_old(simulation_time)
        return list(self.points)
