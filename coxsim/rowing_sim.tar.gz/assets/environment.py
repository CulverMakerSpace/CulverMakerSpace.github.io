import math

import settings


# =============================================================================
# WIND VELOCITY
# =============================================================================
def calculate_wind_velocity():
    # Wind direction describes where the wind comes from, so reverse it first.
    wind_toward_direction = (settings.WIND_DIRECTION + 180.0) % 360.0
    wind_toward_radians = math.radians(wind_toward_direction)

    wind_velocity_x = settings.WIND_SPEED * math.sin(wind_toward_radians)
    wind_velocity_y = settings.WIND_SPEED * math.cos(wind_toward_radians)

    return wind_velocity_x, wind_velocity_y


# =============================================================================
# RELATIVE AIR VELOCITY
# =============================================================================
def calculate_relative_air_velocity(boat):
    wind_velocity_x, wind_velocity_y = calculate_wind_velocity()


    # -------------------------------------------------------------------------
    # RELATIVE AIR VELOCITY - WORLD COORDINATES
    # -------------------------------------------------------------------------
    relative_air_velocity_x = wind_velocity_x - boat.velocity_x
    relative_air_velocity_y = wind_velocity_y - boat.velocity_y


    # -------------------------------------------------------------------------
    # CONVERT TO BOAT COORDINATES
    # -------------------------------------------------------------------------
    heading_cosine = math.cos(boat.heading)
    heading_sine = math.sin(boat.heading)

    relative_air_velocity_forward = ((relative_air_velocity_x * heading_cosine) + (relative_air_velocity_y * heading_sine))

    relative_air_velocity_sideways = ((-relative_air_velocity_x * heading_sine) + (relative_air_velocity_y * heading_cosine))

    return relative_air_velocity_forward, relative_air_velocity_sideways


# =============================================================================
# AIR FORCE FROM ONE VELOCITY COMPONENT
# =============================================================================
def calculate_air_force(relative_air_velocity, drag_coefficient, projected_area):
    # Use the drag equation for one forward or sideways air-velocity component.
    force_magnitude = (0.5 * settings.AIR_DENSITY * drag_coefficient * projected_area * relative_air_velocity**2)


    # -------------------------------------------------------------------------
    # DIRECTION
    # -------------------------------------------------------------------------
    # Force follows the relative airflow direction and opposes motion in still air.
    if relative_air_velocity > 0.0:
        return force_magnitude

    elif relative_air_velocity < 0.0:
        return -force_magnitude

    else:
        return 0.0


# =============================================================================
# FORWARD AIR FORCE
# =============================================================================
def calculate_forward_air_force(boat):
    relative_air_velocity_forward, relative_air_velocity_sideways = calculate_relative_air_velocity(boat)


    # -------------------------------------------------------------------------
    # SHELL
    # -------------------------------------------------------------------------
    shell_force = calculate_air_force(
        relative_air_velocity_forward,
        settings.SHELL_FORWARD_AIR_DRAG_COEFFICIENT,
        settings.SHELL_FORWARD_PROJECTED_AREA)


    # -------------------------------------------------------------------------
    # ROWERS
    # -------------------------------------------------------------------------
    # The shielding factor reduces the overlapping frontal area of the crew.
    effective_rower_area = (settings.NUMBER_OF_ROWERS * settings.ROWER_FORWARD_PROJECTED_AREA * settings.ROWER_FORWARD_SHIELDING_FACTOR)

    rower_force = calculate_air_force(relative_air_velocity_forward, settings.ROWER_AIR_DRAG_COEFFICIENT, effective_rower_area)


    # -------------------------------------------------------------------------
    # COXSWAIN
    # -------------------------------------------------------------------------
    coxswain_force = 0.0

    if settings.HAS_COXSWAIN:
        coxswain_force = calculate_air_force(
            relative_air_velocity_forward,
            settings.COXSWAIN_AIR_DRAG_COEFFICIENT,
            settings.COXSWAIN_FORWARD_PROJECTED_AREA)


    # -------------------------------------------------------------------------
    # TOTAL FORWARD AIR FORCE
    # -------------------------------------------------------------------------
    forward_air_force = shell_force + rower_force + coxswain_force

    return forward_air_force


# =============================================================================
# SHELL SIDE AREA FACTOR
# =============================================================================
def get_shell_side_area_factor(section):
    # Tapered bow and stern sections expose less side area than rower sections.
    if section["name"] == "bow":
        return settings.BOW_SIDE_AIR_AREA_FACTOR

    elif section["name"] == "stern":
        return settings.STERN_SIDE_AIR_AREA_FACTOR

    else:
        return settings.ROWER_SECTION_SIDE_AIR_AREA_FACTOR


# =============================================================================
# SECTION SIDE AIR FORCE
# =============================================================================
def calculate_section_side_air_force(boat, section):
    relative_air_velocity_forward, relative_air_velocity_sideways = calculate_relative_air_velocity(boat)


    # -------------------------------------------------------------------------
    # LOCAL SIDEWAYS AIR VELOCITY
    # -------------------------------------------------------------------------
    # Rotation changes the sideways air speed seen by each hull section.
    rotational_sideways_velocity = boat.angular_velocity * section["position"]
    local_relative_air_velocity_sideways = (relative_air_velocity_sideways - rotational_sideways_velocity)


    # -------------------------------------------------------------------------
    # SHELL SIDE FORCE
    # -------------------------------------------------------------------------
    shell_side_area_factor = get_shell_side_area_factor(section)

    shell_side_area = (section["length"] * settings.SHELL_HEIGHT_ABOVE_WATER * shell_side_area_factor)

    shell_force = calculate_air_force(local_relative_air_velocity_sideways, settings.SHELL_SIDE_AIR_DRAG_COEFFICIENT, shell_side_area)


    # -------------------------------------------------------------------------
    # ROWER SIDE FORCE
    # -------------------------------------------------------------------------
    number_of_rowers = len(section["rowers"])
    rower_side_area = number_of_rowers * settings.ROWER_SIDE_PROJECTED_AREA

    rower_force = calculate_air_force(local_relative_air_velocity_sideways, settings.ROWER_AIR_DRAG_COEFFICIENT, rower_side_area)


    # -------------------------------------------------------------------------
    # TOTAL SIDE AIR FORCE
    # -------------------------------------------------------------------------
    side_air_force = shell_force + rower_force

    return side_air_force


# =============================================================================
# COXSWAIN SIDE AIR FORCE
# =============================================================================
def calculate_coxswain_side_air_force(boat):
    if not settings.HAS_COXSWAIN:
        return 0.0

    relative_air_velocity_forward, relative_air_velocity_sideways = calculate_relative_air_velocity(boat)


    # -------------------------------------------------------------------------
    # LOCAL SIDEWAYS AIR VELOCITY
    # -------------------------------------------------------------------------
    rotational_sideways_velocity = (boat.angular_velocity * settings.COXSWAIN_POSITION)

    local_relative_air_velocity_sideways = (relative_air_velocity_sideways - rotational_sideways_velocity)


    # -------------------------------------------------------------------------
    # COXSWAIN SIDE FORCE
    # -------------------------------------------------------------------------
    coxswain_side_air_force = calculate_air_force(
        local_relative_air_velocity_sideways,
        settings.COXSWAIN_AIR_DRAG_COEFFICIENT,
        settings.COXSWAIN_SIDE_PROJECTED_AREA)

    return coxswain_side_air_force
