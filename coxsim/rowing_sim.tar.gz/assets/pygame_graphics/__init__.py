"""Pygame-only rendering, camera views and interface components.

Pure geometry helpers may be imported without initializing Pygame.
"""
