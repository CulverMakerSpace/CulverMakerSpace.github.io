"""Course-selection screen for the Pygame desktop and browser renderer."""

import pygame

import settings
from source_data.courses import registry as course


# =============================================================================
# COURSE SELECTION MENU
# =============================================================================
def menu_buttons():
    center = settings.WINDOW_WIDTH // 2
    course_names = list(course.COURSES)
    return {name: pygame.Rect(center - 230, 258 + index * 82, 460, 64)
            for index, name in enumerate(course_names)}


# Background is generated once, never recomputed every menu frame.
_course_menu_background = None
_course_menu_fonts = None


def draw_course_menu(screen):
    global _course_menu_background, _course_menu_fonts
    if _course_menu_background is None:
        size = screen.get_size()
        _course_menu_background = pygame.Surface(size)
        for y in range(size[1]):
            t = y / max(1, size[1] - 1)
            shade = (round(20 + 24 * t), round(43 + 42 * t), round(57 + 53 * t))
            pygame.draw.line(_course_menu_background, shade, (0, y), (size[0], y))

    screen.blit(_course_menu_background, (0, 0))
    if _course_menu_fonts is None:
        _course_menu_fonts = (pygame.font.Font(None, 57), pygame.font.Font(None, 27),
                              pygame.font.Font(None, 21))
    font, small_font, secondary_font = _course_menu_fonts
    title = font.render("COXSWAIN SIMULATOR", True, (242, 246, 243))
    screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 115)))
    subtitle = secondary_font.render("CHOOSE A COURSE TO BEGIN", True, (167, 206, 214))
    screen.blit(subtitle, subtitle.get_rect(center=(settings.WINDOW_WIDTH // 2, 156)))

    labels = {"max": "LAKE MAXINKUCKEE",
              "charles": "HEAD OF THE CHARLES",
              "nathan": "NATHAN BENDERSON PARK",
              "milwaukee": "MILWAUKEE RIVER"}
    mouse_position = pygame.mouse.get_pos()
    for index, (name, rectangle) in enumerate(menu_buttons().items()):
        hovering = rectangle.collidepoint(mouse_position)
        fill = (41, 93, 117) if hovering else (30, 72, 92)
        pygame.draw.rect(screen, (13, 34, 45), rectangle.move(3, 5), border_radius=10)
        pygame.draw.rect(screen, fill, rectangle, border_radius=10)
        pygame.draw.rect(screen, (129, 178, 185), rectangle, 1 if not hovering else 2, border_radius=10)
        pygame.draw.rect(screen, (166, 197, 158) if hovering else (88, 147, 162),
                         pygame.Rect(rectangle.left, rectangle.top + 9, 4, rectangle.height - 18), border_radius=2)
        number = small_font.render(str(index + 1), True, (157, 194, 204))
        screen.blit(number, (rectangle.left + 18, rectangle.top + 16))
        text = small_font.render(labels[name], True, (240, 247, 244))
        screen.blit(text, text.get_rect(midleft=(rectangle.left + 58, rectangle.centery)))

    help_text = secondary_font.render("PRESS R TO RESET THE ACTIVE COURSE   •   ESC TO RETURN HERE", True, (196, 221, 221))
    screen.blit(help_text, help_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 670)))
    copyright_line = secondary_font.render("v3.9-pygame", True, (132, 169, 176))
    screen.blit(copyright_line, copyright_line.get_rect(center=(settings.WINDOW_WIDTH // 2, 727)))


