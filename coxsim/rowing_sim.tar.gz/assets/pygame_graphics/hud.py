"""Pygame on-screen information, prepared commands and collision notices."""

import math
from functools import lru_cache

import pygame

import settings
from source_data.courses import registry as course
from pygame_graphics.camera import world_to_screen
from pygame_graphics.boat import COM_TRAIL_COLOR


# =============================================================================
# CENTER-OF-MASS PATH
# =============================================================================
def draw_com_trail(screen, camera, trail):
    """Thin, permanent COM route; the temporary foamy wake is drawn over it."""
    if trail is None:
        return

    world_points = trail.visible_points()
    if len(world_points) < 2:
        return

    center_x, center_y, zoom = camera.get_view()
    width, height = screen.get_size()
    # Cheap world-space culling is important after thousands of meters.
    # The square must cover the rotated viewport diagonal in follow mode.
    world_radius = math.hypot(width, height) / max(0.01, zoom)
    min_x, max_x = center_x - world_radius, center_x + world_radius
    min_y, max_y = center_y - world_radius, center_y + world_radius

    # At overview zoom, skip points smaller than a fraction of a screen pixel.
    stride = max(1, int(0.75 / max(0.04, zoom)))
    sampled = list(world_points[::stride])
    if sampled[-1] != world_points[-1]:
        sampled.append(world_points[-1])

    path_color = COM_TRAIL_COLOR
    previous_world = sampled[0]
    for current_world in sampled[1:]:
        ax, ay = previous_world
        bx, by = current_world
        if (max(ax, bx) < min_x or min(ax, bx) > max_x or
                max(ay, by) < min_y or min(ay, by) > max_y):
            previous_world = current_world
            continue
        previous = world_to_screen(ax, ay, camera)
        current = world_to_screen(bx, by, camera)
        if not (max(previous[0], current[0]) < 0 or min(previous[0], current[0]) > width or
                max(previous[1], current[1]) < 0 or min(previous[1], current[1]) > height):
            pygame.draw.line(screen, path_color, previous, current, 1)
        previous_world = current_world

    # The most recent route is faintly brighter; the transient wake drawn
    # above it blends the two into one visible water disturbance.
    recent = sampled[-min(len(sampled), 28):]
    if len(recent) > 1 and not camera.show_overview:
        recent_screen = [world_to_screen(x, y, camera) for x, y in recent]
        pygame.draw.lines(screen, (119, 174, 201), False, recent_screen, 1)


# =============================================================================
# DRAW DEBUG HUD
# =============================================================================
def draw_hud(screen, font, boat, trail=None):
    # Display the current boat state and recent average speed.
    speed = boat.get_speed()
    average_speed = boat.get_average_speed()
    heading_degrees = math.degrees(boat.heading)

    lines = [
        f"Position X: {boat.x:.2f} m",
        f"Position Y: {boat.y:.2f} m",
        f"Velocity X: {boat.velocity_x:.2f} m/s",
        f"Velocity Y: {boat.velocity_y:.2f} m/s",
        f"Speed: {speed:.2f} m/s",
        f"Average Speed (5s): {average_speed:.2f} m/s",
        f"COM Distance: {trail.distance_m:.1f} m" if trail is not None else "COM Distance: 0.0 m",
        f"Acceleration X: {boat.acceleration_x:.2f} m/s^2",
        f"Acceleration Y: {boat.acceleration_y:.2f} m/s^2",
        f"Force X: {boat.last_force_x:.2f} N",
        f"Force Y: {boat.last_force_y:.2f} N",
        f"Heading: {heading_degrees:.1f} degrees",
        f"Angular Velocity: {boat.angular_velocity:.3f} rad/s",
        f"Angular Acceleration: {boat.angular_acceleration:.3f} rad/s^2",
        f"Torque: {boat.last_torque:.2f} N*m"]

    x = 20
    y = 20
    line_spacing = 17
    width = max(font.size(line)[0] for line in lines) + 24
    panel = pygame.Surface((width, line_spacing * len(lines) + 17), pygame.SRCALPHA)
    pygame.draw.rect(panel, (14, 31, 43, 180), panel.get_rect(), border_radius=7)
    pygame.draw.rect(panel, (151, 188, 199, 75), panel.get_rect(), 1, border_radius=7)
    screen.blit(panel, (x - 11, y - 7))

    for line in lines:
        text = font.render(line, True, "white")

        screen.blit(text, (x, y))
        y += line_spacing


# =============================================================================
# HUD FONT CACHE
# =============================================================================
@lru_cache(maxsize=4)
def make_bold_hud_font(size):
    font = pygame.font.Font(None, size)
    font.set_bold(True)
    return font


# =============================================================================
# DRAW CONTROL HUD
# =============================================================================
def draw_control_hud(screen, font, control_state, boat=None, trail=None):
    # The right-side panel mirrors the Godot rowing-status HUD. The smaller
    # debug HUD on the left remains available for technical information.
    line_spacing = 24
    right_margin = 20
    y = 20

    heading_font = make_bold_hud_font(settings.CONTROL_HUD_FONT_SIZE + 5)
    heading = heading_font.render("ROWING STATUS", True, "white")

    lines = []
    for seat in range(1, settings.NUMBER_OF_ROWERS + 1):
        display_name = settings.ROWER_DISPLAY_NAMES[seat]
        rowing_state = control_state.rower_states[seat].title()
        line = f"{display_name}: {rowing_state}"
        instruction = control_state.command_manager.pending[seat]

        if instruction is not None:
            current_count = control_state.stroke_clock.completed_strokes
            if instruction.mode == "in":
                remaining = max(0, instruction.start_at - current_count)
            elif instruction.mode == "for":
                remaining = max(0, instruction.finish_at - max(current_count, instruction.start_at))
            else:
                remaining = 0
            if instruction.mode in ("in", "for"):
                line += f" ({instruction.mode.upper()} {remaining})"
        lines.append(line)

    lines.extend([
        "",
        f"Port Oars: {control_state.oar_positions['port'].title()}",
        f"Starboard Oars: {control_state.oar_positions['starboard'].title()}",
        "",
        f"Stroke Rate: {control_state.stroke_rate} spm",
    ])

    rudder_angle = control_state.rudder_angle
    if rudder_angle > 0:
        lines.append(f"Rudder: {abs(rudder_angle):.0f} degrees Port")
    elif rudder_angle < 0:
        lines.append(f"Rudder: {abs(rudder_angle):.0f} degrees Starboard")
    else:
        lines.append("Rudder: 0 degrees")

    lines.append("")
    average_speed = boat.get_average_speed() if boat is not None else 0.0
    lines.append(f"Average Speed (5s): {average_speed:.2f} m/s")
    if average_speed > 0.01:
        split_seconds = 500.0 / average_speed
        minutes, seconds = divmod(int(round(split_seconds)), 60)
        lines.append(f"500m Split: {minutes}:{seconds:02d}")
    else:
        lines.append("500m Split: --:--")
    distance = trail.distance_m if trail is not None else 0.0
    lines.append(f"COM Distance: {distance:.1f} m")

    prepared = control_state.get_prepared_text() if hasattr(control_state, "get_prepared_text") else ""
    if prepared:
        lines.extend(["", "Prepared: " + prepared])

    # Right-align the whole panel without clipping longer prepared commands.
    max_width = min(500, settings.WINDOW_WIDTH - 40)
    rendered_lines = []
    for line in lines:
        if not line.startswith("Prepared: ") or font.size(line)[0] <= max_width:
            rendered_lines.append(line)
            continue
        words = line.split()
        current_line = words[0]
        for word in words[1:]:
            candidate = current_line + " " + word
            if font.size(candidate)[0] > max_width and current_line != words[0]:
                rendered_lines.append(current_line)
                current_line = word
            else:
                current_line = candidate
        rendered_lines.append(current_line)

    panel_width = max([heading.get_width()] + [font.size(line)[0] for line in rendered_lines])
    x = max(8, settings.WINDOW_WIDTH - right_margin - panel_width)
    panel_height = max(heading.get_height() + 2, line_spacing) + len(rendered_lines) * line_spacing + 12
    backdrop = pygame.Surface((panel_width + 22, panel_height), pygame.SRCALPHA)
    pygame.draw.rect(backdrop, (14, 31, 43, 198), backdrop.get_rect(), border_radius=7)
    pygame.draw.rect(backdrop, (153, 190, 202, 85), backdrop.get_rect(), 1, border_radius=7)
    screen.blit(backdrop, (x - 11, y - 7))
    screen.blit(heading, (x, y))
    y += max(heading.get_height() + 2, line_spacing)

    for line in rendered_lines:
        if line:
            screen.blit(font.render(line, True, "white"), (x, y))
        y += line_spacing


# =============================================================================
# DRAW CAMERA LABEL
# =============================================================================
def draw_camera_label(screen, font, camera):
    # Show either the overview instructions or the current follow-mode zoom.
    if camera.show_overview:
        label = "COURSE OVERVIEW   M: FOLLOW BOAT"

    else:
        course_name = getattr(course, "COURSE_TITLE", "LAKE MAXINKUCKEE")
        label = f"{course_name}   ZOOM: {camera.zoom:.2f} px/m   M: OVERVIEW   +/-: ZOOM   B: BOX"

    text = font.render(label, True, "white")

    label_background = pygame.Surface((min(settings.WINDOW_WIDTH - 40, text.get_width() + 20), 26), pygame.SRCALPHA)
    pygame.draw.rect(label_background, (15, 32, 42, 175), label_background.get_rect(), border_radius=6)
    screen.blit(label_background, (12, settings.WINDOW_HEIGHT - 35))
    screen.blit(text, (20, settings.WINDOW_HEIGHT - 30))

# =============================================================================
# RESET BUTTON
# =============================================================================
def get_reset_button_rect():
    return pygame.Rect(settings.WINDOW_WIDTH - 120, settings.WINDOW_HEIGHT - 55, 100, 35)


def draw_reset_button(screen, font):
    # Keep reset available during normal driving, warnings, and crash freezes.
    button_rect = get_reset_button_rect()

    pygame.draw.rect(screen, (29, 58, 72), button_rect, border_radius=7)
    pygame.draw.rect(screen, (165, 191, 198), button_rect, 1, border_radius=7)

    text = font.render("RESET", True, "white")
    text_rect = text.get_rect(center=button_rect.center)
    screen.blit(text, text_rect)


# =============================================================================
# COLLISION MESSAGES
# =============================================================================
def get_warning_close_button_rect():
    return pygame.Rect((settings.WINDOW_WIDTH // 2) + 185, 78, 28, 28)


def draw_collision_messages(screen, font, warning_message=None, crash_message=None, docked=False):
    # Persistent bump/crash notices sit above the simulation without hiding the boat.
    if docked and crash_message is None:
        docked_text = font.render("DOCKED", True, "white")
        docked_rect = docked_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 35))
        background = docked_rect.inflate(24, 14)

        pygame.draw.rect(screen, (35, 110, 55), background)
        pygame.draw.rect(screen, "white", background, 2)
        screen.blit(docked_text, docked_rect)

    if crash_message is not None:
        message_rect = pygame.Rect((settings.WINDOW_WIDTH // 2) - 260, 70, 520, 110)

        pygame.draw.rect(screen, (120, 25, 25), message_rect)
        pygame.draw.rect(screen, "white", message_rect, 3)

        title = font.render("CRASH - SIMULATION FROZEN", True, "white")
        detail = font.render(crash_message, True, "white")
        reset_text = font.render("Use RESET or press R to restart.", True, "white")

        screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 96)))
        screen.blit(detail, detail.get_rect(center=(settings.WINDOW_WIDTH // 2, 128)))
        screen.blit(reset_text, reset_text.get_rect(center=(settings.WINDOW_WIDTH // 2, 156)))

    elif warning_message is not None:
        message_rect = pygame.Rect((settings.WINDOW_WIDTH // 2) - 235, 70, 470, 82)
        close_rect = get_warning_close_button_rect()

        pygame.draw.rect(screen, (145, 100, 20), message_rect)
        pygame.draw.rect(screen, "white", message_rect, 2)
        pygame.draw.rect(screen, (70, 55, 25), close_rect)
        pygame.draw.rect(screen, "white", close_rect, 1)

        title = font.render("COLLISION WARNING", True, "white")
        detail = font.render(warning_message, True, "white")
        close_text = font.render("X", True, "white")

        screen.blit(title, title.get_rect(center=(settings.WINDOW_WIDTH // 2, 93)))
        screen.blit(detail, detail.get_rect(center=(settings.WINDOW_WIDTH // 2, 124)))
        screen.blit(close_text, close_text.get_rect(center=close_rect.center))