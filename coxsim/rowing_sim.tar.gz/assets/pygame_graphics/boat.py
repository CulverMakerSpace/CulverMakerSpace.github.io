"""Pygame racing-shell, crew, blades, wake and navigation overlays."""

import math

import pygame

import settings
from pygame_graphics.camera import world_to_screen
from pygame_graphics.trails import heading_guide_world_points


# =============================================================================
# BOAT TO WORLD
# =============================================================================
def boat_to_world(boat, forward, sideways):
    # Rotate a boat-relative point into world coordinates.
    heading_cosine = math.cos(boat.heading)
    heading_sine = math.sin(boat.heading)

    world_x = (boat.x + (forward * heading_cosine) - (sideways * heading_sine))

    world_y = (boat.y + (forward * heading_sine) + (sideways * heading_cosine))

    return world_x, world_y


# =============================================================================
# BOAT DETAIL POINT
# =============================================================================
def boat_detail_point(boat, camera, forward, sideways):
    # Convert a boat-relative point directly into screen coordinates.
    world_x, world_y = boat_to_world(boat, forward, sideways)

    screen_point = world_to_screen(world_x, world_y, camera)

    return screen_point


# =============================================================================
# PYGAME-ONLY VISUAL PALETTE
# =============================================================================
# Godot reads the original settings; these colors never affect physics.
OAR_BLADE_MAROON = (111, 35, 57)
OAR_BLADE_RAISED = (190, 173, 111)       # muted ochre / yellow
OAR_BLADE_GRABBING = (112, 160, 131)     # subdued sage green
CONTACT_BARRIER_COLOR = (95, 143, 196)  # blue collision outline
HEADING_GUIDE_COLOR = (140, 207, 127)   # subtle pale green
COM_TRAIL_COLOR = (103, 162, 191)       # midpoint of old trail and collision blue
ROWER_JERSEY = (28, 62, 78)
ROWER_SKIN = (185, 147, 116)


def draw_rower(screen, boat, camera, section, seat, stroke_phase, rowing_state):
    """Render a small top-down rowing silhouette with synchronized seat motion.

    This deliberately exaggerates a few pixel-scale details at normal zoom.
    No body position is fed back to the force or collision calculations.
    """
    _, _, zoom = camera.get_view()
    if camera.show_overview or zoom < 2.3:
        return

    side = 1.0 if seat in settings.PORT_SEATS else -1.0
    seat_offset = -settings.ROWER_SEAT_FORWARD_OFFSET if seat % 2 == 0 else settings.ROWER_SEAT_FORWARD_OFFSET
    position = section["position"] + seat_offset

    # The sliding seat moves aft through the drive and returns toward the catch
    # during recovery. It is a visual cue, not an additional source of speed.
    if rowing_state in ("forward", "backward"):
        if stroke_phase < settings.DRIVE_FRACTION:
            cycle_progress = stroke_phase / settings.DRIVE_FRACTION
        else:
            cycle_progress = 1.0 - (stroke_phase - settings.DRIVE_FRACTION) / settings.RECOVERY_FRACTION
        if rowing_state == "backward":
            cycle_progress = 1.0 - cycle_progress
        slide_m = (cycle_progress - 0.5) * 0.48
    else:
        slide_m = 0.0

    # Seat track, small feet/shoes and a body-shaped silhouette.
    track_start = boat_detail_point(boat, camera, position - 0.56, side * 0.12)
    track_end = boat_detail_point(boat, camera, position + 0.53, side * 0.12)
    pygame.draw.line(screen, (99, 116, 122), track_start, track_end, max(1, round(0.035 * zoom)))
    feet = boat_detail_point(boat, camera, position + 0.45, side * 0.12)
    pygame.draw.circle(screen, (54, 65, 68), feet, max(1, round(0.11 * zoom)))

    center = boat_detail_point(boat, camera, position + slide_m, side * 0.12)
    torso_width = max(3, round(0.29 * zoom))
    torso_length = max(4, round(0.46 * zoom))
    torso = pygame.Rect(center[0] - torso_width // 2, center[1] - torso_length // 2,
                        torso_width, torso_length)
    pygame.draw.ellipse(screen, (15, 40, 51), torso.move(1, 1))
    pygame.draw.ellipse(screen, ROWER_JERSEY, torso)
    if zoom >= 4.0:
        shoulder = boat_detail_point(boat, camera, position + slide_m - 0.10, side * 0.12)
        pygame.draw.line(screen, (87, 139, 146),
                         (shoulder[0] - max(1, torso_width // 3), shoulder[1]),
                         (shoulder[0] + max(1, torso_width // 3), shoulder[1]), 1)
    head = boat_detail_point(boat, camera, position + slide_m - 0.33, side * 0.12)
    head_radius = max(2, round(0.12 * zoom))
    pygame.draw.circle(screen, (39, 52, 52), (head[0] + 1, head[1] + 1), head_radius)
    pygame.draw.circle(screen, ROWER_SKIN, head, head_radius)
    if zoom >= 5.0:
        pygame.draw.arc(screen, (47, 52, 47),
                        pygame.Rect(head[0] - head_radius, head[1] - head_radius,
                                    2 * head_radius, 2 * head_radius), 3.3, 6.2, 1)

    # A small arm extends to the oar handle. That movement helps the crew read
    # as individual rowers even when the entire hull is only ~90 px long.
    if zoom >= 3.5:
        hand_forward = position + slide_m - 0.10
        hand_sideways = side * 0.33
        hand = boat_detail_point(boat, camera, hand_forward, hand_sideways)
        shoulder = boat_detail_point(boat, camera, position + slide_m - 0.04, side * 0.09)
        pygame.draw.line(screen, ROWER_SKIN, shoulder, hand, max(1, round(0.055 * zoom)))
        pygame.draw.circle(screen, ROWER_SKIN, hand, max(1, round(0.055 * zoom)))


# =============================================================================
# DRAW OAR
# =============================================================================
def draw_oar(screen, boat, camera, section, seat, rowing_state, oar_position, stroke_phase, dock_grabbing=False):

    # The oar animation is visual only and does not alter the rowing forces.
    port_side = seat in settings.PORT_SEATS

    if port_side:
        side = 1.0

    else:
        side = -1.0


    # -------------------------------------------------------------------------
    # SWEEP ANGLE
    # -------------------------------------------------------------------------
    # Raised oars are held straight out from the shell while clearing the dock.
    if oar_position == "up":
        sweep_angle = 0.0

    elif rowing_state == "hold":
        sweep_angle = 0.0

    elif rowing_state in ("forward", "backward"):
        if stroke_phase < settings.DRIVE_FRACTION:
            drive_progress = stroke_phase / settings.DRIVE_FRACTION

            sweep_degrees = (settings.OAR_DISPLAY_MAX_SWEEP_ANGLE - (2 * settings.OAR_DISPLAY_MAX_SWEEP_ANGLE * drive_progress))

        else:
            recovery_progress = ((stroke_phase - settings.DRIVE_FRACTION) / settings.RECOVERY_FRACTION)

            sweep_degrees = (-settings.OAR_DISPLAY_MAX_SWEEP_ANGLE + (2 * settings.OAR_DISPLAY_MAX_SWEEP_ANGLE * recovery_progress))

        if rowing_state == "backward":
            sweep_degrees = -sweep_degrees

        sweep_angle = math.radians(sweep_degrees)

    else:
        sweep_angle = math.radians(settings.OAR_COAST_SWEEP_ANGLE)


    # -------------------------------------------------------------------------
    # OAR POSITION
    # -------------------------------------------------------------------------
    # Offset paired seats slightly fore/aft so both oars remain visible.
    if seat % 2 == 0:
        seat_offset = -settings.ROWER_SEAT_FORWARD_OFFSET

    else:
        seat_offset = settings.ROWER_SEAT_FORWARD_OFFSET

    position = section["position"] + seat_offset
    pivot_side = side * settings.OAR_SPAN


    # -------------------------------------------------------------------------
    # OAR LENGTH
    # -------------------------------------------------------------------------
    # Raised oars use their full horizontal reach because they are out of the water.
    if oar_position == "up":
        blade_outer_distance = (settings.OAR_RAISED_REACH - settings.OAR_SPAN)

    else:
        blade_outer_distance = settings.OAR_OUTBOARD

    blade_graphics_length = min(settings.OAR_BLADE_GRAPHICS_LENGTH, blade_outer_distance)

    blade_inner_distance = (blade_outer_distance - blade_graphics_length)


    # -------------------------------------------------------------------------
    # OAR GEOMETRY
    # -------------------------------------------------------------------------
    shaft_end_forward = (position + (blade_inner_distance * math.sin(sweep_angle)))

    shaft_end_sideways = (pivot_side + (side * blade_inner_distance * math.cos(sweep_angle)))

    blade_inner_forward = shaft_end_forward
    blade_inner_sideways = shaft_end_sideways

    blade_outer_forward = (position + (blade_outer_distance * math.sin(sweep_angle)))

    blade_outer_sideways = (pivot_side + (side * blade_outer_distance * math.cos(sweep_angle)))


    # -------------------------------------------------------------------------
    # SCREEN POINTS
    # -------------------------------------------------------------------------
    pivot = boat_detail_point(boat, camera, position, pivot_side)

    shaft_end = boat_detail_point(boat, camera, shaft_end_forward, shaft_end_sideways)

    _, _, zoom = camera.get_view()

    if zoom < 1.0:
        return


    # -------------------------------------------------------------------------
    # RIGGER, SHAFT, AND HANDLE
    # -------------------------------------------------------------------------
    if dock_grabbing and oar_position == "up":
        accent = OAR_BLADE_GRABBING
    elif oar_position == "up":
        accent = OAR_BLADE_RAISED
    else:
        accent = OAR_BLADE_MAROON

    oar_width = max(1, round(0.053 * zoom))
    if oar_position == "up":
        # The complete raised oar (shaft and spoon) changes color together.
        shaft_color = accent
        shaft_shadow = tuple(max(0, round(channel * 0.67)) for channel in accent)
        shaft_highlight = tuple(min(255, round(channel + (255 - channel) * 0.22)) for channel in accent)
    else:
        shaft_color = (47, 52, 58)
        shaft_shadow = (23, 38, 46)
        shaft_highlight = (106, 113, 115)

    pygame.draw.line(screen, shaft_shadow, (pivot[0] + 1, pivot[1] + 1),
                     (shaft_end[0] + 1, shaft_end[1] + 1), oar_width + 1)
    pygame.draw.line(screen, shaft_color, pivot, shaft_end, oar_width)
    if zoom >= 4.0:
        pygame.draw.line(screen, shaft_highlight, pivot, shaft_end, 1)

    # -------------------------------------------------------------------------
    # SPOON BLADE (TAPERED, NOT JUST A LINE)
    # -------------------------------------------------------------------------
    blade_start = boat_detail_point(boat, camera, blade_inner_forward, blade_inner_sideways)
    blade_end = boat_detail_point(boat, camera, blade_outer_forward, blade_outer_sideways)
    dx = blade_end[0] - blade_start[0]
    dy = blade_end[1] - blade_start[1]
    blade_length_pixels = max(0.001, math.hypot(dx, dy))
    nx, ny = -dy / blade_length_pixels, dx / blade_length_pixels
    half_width = max(1.8, min(5.6, 0.11 * zoom + 0.9))
    cx = (blade_start[0] * 0.45 + blade_end[0] * 0.55)
    cy = (blade_start[1] * 0.45 + blade_end[1] * 0.55)
    blade_points = [
        (blade_start[0] + nx * half_width * 0.44, blade_start[1] + ny * half_width * 0.44),
        (cx + nx * half_width, cy + ny * half_width),
        (blade_end[0] + nx * half_width * 0.73, blade_end[1] + ny * half_width * 0.73),
        (blade_end[0] - nx * half_width * 0.73, blade_end[1] - ny * half_width * 0.73),
        (cx - nx * half_width, cy - ny * half_width),
        (blade_start[0] - nx * half_width * 0.44, blade_start[1] - ny * half_width * 0.44)]
    blade_shadow = (35, 52, 59) if oar_position != "up" else tuple(
        max(0, round(channel * 0.67)) for channel in accent)
    pygame.draw.polygon(screen, blade_shadow, [(x + 1, y + 1) for x, y in blade_points])
    pygame.draw.polygon(screen, accent, blade_points)
    edge_color = (145, 188, 153) if dock_grabbing and oar_position == "up" else (
        (225, 210, 159) if oar_position == "up" else (164, 80, 100))
    if zoom >= 2.5:
        pygame.draw.line(screen, edge_color, blade_start, blade_end, 1)
    if zoom >= 4.0:
        blade_edge = shaft_shadow if oar_position == "up" else (33, 45, 49)
        pygame.draw.lines(screen, blade_edge, True, blade_points, 1)
    oarlock_color = accent if oar_position == "up" else (204, 207, 204)
    pygame.draw.circle(screen, oarlock_color, pivot, max(1, round(0.079 * zoom)))
    if zoom >= 4.0:
        pygame.draw.circle(screen, shaft_shadow, pivot, max(1, round(0.041 * zoom)))


# =============================================================================
# DRAW BOAT COLLISION BOX
# =============================================================================
def draw_boat_collision_box(screen, boat, camera, control_state):
    # Draw the fixed local collision envelope in the boat's current position.
    collision_points = []

    for forward, sideways in control_state.boat_collision_local_points:
        screen_point = boat_detail_point(boat, camera, forward, sideways)

        collision_points.append(screen_point)

    pygame.draw.lines(screen, CONTACT_BARRIER_COLOR, True, collision_points, settings.BOAT_COLLISION_LINE_WIDTH)


def draw_foamy_wake(screen, camera, wake_trail, simulation_time):
    """Draw subtle ripples at prior stern positions, following the actual route.

    Each ripple is perpendicular to its own small piece of the traveled path.
    The wake stays behind in world space even when the shell turns or drifts.
    """
    if camera.show_overview or wake_trail is None:
        return

    _, _, zoom = camera.get_view()
    if zoom < 1.3:
        return

    samples = wake_trail.visible_points(simulation_time)
    if len(samples) < 3:
        return

    # Light blue-gray, deliberately subdued against the textured water.
    water_color = (61, 132, 157)
    foam_color = (183, 220, 226)
    last_ripple_position = None

    for index in range(1, len(samples) - 1):
        x, y, timestamp, speed = samples[index]
        age = max(0.0, simulation_time - timestamp)
        fade = max(0.0, 1.0 - age / 9.0)
        if fade <= 0.0:
            continue

        before_x, before_y = samples[index - 1][:2]
        after_x, after_y = samples[index + 1][:2]
        tangent_x = after_x - before_x
        tangent_y = after_y - before_y
        tangent_length = math.hypot(tangent_x, tangent_y)
        if tangent_length < 0.02:
            continue
        tangent_x /= tangent_length
        tangent_y /= tangent_length

        # Avoid drawing hundreds of overlapping wavelets at high speed.
        if last_ripple_position is not None and math.dist(last_ripple_position, (x, y)) < 1.45:
            continue
        last_ripple_position = (x, y)

        # Ripples spread sideways over time rather than remaining attached to
        # today's heading. A small backward lean gives a soft chevron shape.
        normal_x = -tangent_y
        normal_y = tangent_x
        half_width = 0.25 + min(1.35, age * 0.20)
        strength = min(1.0, speed / 4.0) * fade
        blend = 0.45 * strength
        color = tuple(round(water + (foam - water) * blend) for water, foam in zip(water_color, foam_color))

        for side in (-1.0, 1.0):
            inner_x = x + normal_x * side * half_width * 0.20
            inner_y = y + normal_y * side * half_width * 0.20
            outer_x = x + normal_x * side * half_width - tangent_x * 0.30
            outer_y = y + normal_y * side * half_width - tangent_y * 0.30

            start = world_to_screen(inner_x, inner_y, camera)
            end = world_to_screen(outer_x, outer_y, camera)
            pygame.draw.line(screen, color, start, end, 1 if zoom < 8.0 else 2)
            if age < 3.5 and speed > 1.8 and index % 5 == 0 and zoom >= 3.0:
                # Sparse sparkle, fixed in world space instead of marching
                # along the boat's present heading.
                dot = world_to_screen(outer_x * 0.85 + x * 0.15,
                                      outer_y * 0.85 + y * 0.15, camera)
                pygame.draw.circle(screen, color, dot, 1)


# =============================================================================
# 100 METER HEADING GUIDE
# =============================================================================
def draw_heading_guide(screen, boat, camera):
    """Show a translucent pale-green line 100 m ahead of the bow.

    This is the bow heading, not a predicted trajectory: current, wind, and
    existing lateral momentum can all make the real path diverge from it.
    Clip first so even at high zoom only a tiny temporary surface is needed.
    """
    start_world, end_world = heading_guide_world_points(boat)
    start_screen = world_to_screen(*start_world, camera)
    end_screen = world_to_screen(*end_world, camera)

    visible_line = screen.get_rect().clipline(start_screen, end_screen)
    if not visible_line:
        return

    first_point, last_point = visible_line
    left = min(first_point[0], last_point[0]) - 3
    top = min(first_point[1], last_point[1]) - 3
    right = max(first_point[0], last_point[0]) + 4
    bottom = max(first_point[1], last_point[1]) + 4
    local_bounds = pygame.Rect(left, top, right - left, bottom - top).clip(screen.get_rect())
    if local_bounds.width == 0 or local_bounds.height == 0:
        return

    start_local = (first_point[0] - local_bounds.x, first_point[1] - local_bounds.y)
    end_local = (last_point[0] - local_bounds.x, last_point[1] - local_bounds.y)
    guide_layer = pygame.Surface(local_bounds.size, pygame.SRCALPHA)

    # Pale green is deliberately distinct from the blue collision barrier.
    red, green, blue = HEADING_GUIDE_COLOR
    pygame.draw.line(guide_layer, (red, green, blue, 65), start_local, end_local, 2)
    pygame.draw.aaline(guide_layer, (red, green, blue, 125), start_local, end_local)
    screen.blit(guide_layer, local_bounds.topleft)


# =============================================================================
# DRAW BOAT
# =============================================================================
def draw_boat(screen, boat, camera, control_state=None, simulation_time=0.0):
    _, _, zoom = camera.get_view()


    # -------------------------------------------------------------------------
    # DISPLAY DIMENSIONS
    # -------------------------------------------------------------------------
    # Slightly widen the drawn shell at low zoom so it remains visible. Physics
    # calculations still use the actual 0.53 m shell width from settings.py.
    minimum_visible_half_width = 2.8 / max(zoom, 0.01)

    visual_half_width = max(settings.SHELL_WIDTH / 2, minimum_visible_half_width)

    geometric_center = settings.GEOMETRIC_CENTER_FROM_CENTER_OF_MASS
    bow = geometric_center + (settings.SHELL_LENGTH / 2)
    stern = geometric_center - (settings.SHELL_LENGTH / 2)


    # -------------------------------------------------------------------------
    # OARS - DRAWN BEHIND THE HULL
    # -------------------------------------------------------------------------
    if (control_state is not None and zoom >= 1.0 and not camera.show_overview):

        stroke_fraction = control_state.stroke_clock.phase

        for section in settings.ROWER_SECTIONS:
            for seat in section["rowers"]:
                rowing_state = control_state.rower_states[seat]

                if seat in settings.PORT_SEATS:
                    oar_position = control_state.oar_positions["port"]

                else:
                    oar_position = control_state.oar_positions["starboard"]

                draw_oar(screen, boat, camera, section, seat, rowing_state, oar_position,
                         stroke_fraction, seat in getattr(control_state, "active_dock_grab_seats", set()))


    # -------------------------------------------------------------------------
    # RACING SHELL OUTLINE
    # -------------------------------------------------------------------------
    # Use a tapered polygon at both the bow and stern.
    local_points = [
        (bow, 0.0),
        (bow - 1.3, visual_half_width * 0.78),
        (bow - 3.0, visual_half_width),
        (stern + 1.9, visual_half_width),
        (stern + 0.4, visual_half_width * 0.45),
        (stern, 0.0),
        (stern + 0.4, -visual_half_width * 0.45),
        (stern + 1.9, -visual_half_width),
        (bow - 3.0, -visual_half_width),
        (bow - 1.3, -visual_half_width * 0.78)]

    hull_points = []

    for forward, sideways in local_points:
        screen_point = boat_detail_point(boat, camera, forward, sideways)

        hull_points.append(screen_point)

    # Clean, two-tone shell: a subtle edge shadow, warm white hull, and one
    # narrow open cockpit. Avoid several overlapping white/blue-gray deck lines
    # that obscured the slender hull at normal zoom.
    if zoom >= 2.5:
        shadow_points = [(x + 1, y + 1) for x, y in hull_points]
        pygame.draw.polygon(screen, (45, 91, 102), shadow_points)
    pygame.draw.polygon(screen, (242, 244, 240), hull_points)
    pygame.draw.lines(screen, (76, 94, 101), True, hull_points, 1)

    if zoom >= 2.0 and not camera.show_overview:
        cockpit_bow = boat_detail_point(boat, camera, bow - 3.1, 0.0)
        cockpit_stern = boat_detail_point(boat, camera, stern + 1.9, 0.0)
        cockpit_width = max(1, round(0.18 * zoom))
        pygame.draw.line(screen, (57, 73, 77), cockpit_bow, cockpit_stern, cockpit_width)


    # -------------------------------------------------------------------------
    # CENTERLINE AND CREW POSITIONS
    # -------------------------------------------------------------------------
    if zoom >= 2.0 and not camera.show_overview:
        if control_state is not None:
            for section in settings.ROWER_SECTIONS:
                for seat in section["rowers"]:
                    draw_rower(screen, boat, camera, section, seat,
                               control_state.stroke_clock.phase, control_state.rower_states[seat])


        # ---------------------------------------------------------------------
        # COXSWAIN POSITION
        # ---------------------------------------------------------------------
        if settings.HAS_COXSWAIN:
            coxswain_center = boat_detail_point(boat, camera, settings.COXSWAIN_POSITION, 0)

            coxswain_radius = max(2, round(0.20 * zoom))

            pygame.draw.circle(screen, (35, 49, 56),
                               (coxswain_center[0] + 1, coxswain_center[1] + 1), coxswain_radius + 1)
            pygame.draw.circle(screen, (156, 81, 69), coxswain_center, coxswain_radius)
            if zoom >= 4.0:
                pygame.draw.circle(screen, (213, 172, 135),
                                   (coxswain_center[0], coxswain_center[1] - max(1, coxswain_radius // 2)),
                                   max(1, coxswain_radius // 2))


    # -------------------------------------------------------------------------
    # RUDDER DIRECTION INDICATOR
    # -------------------------------------------------------------------------
    if (control_state is not None and zoom >= 3.0 and not camera.show_overview):

        rudder_angle = math.radians(control_state.rudder_angle)
        rudder_base = settings.STEERING_LEVER_ARM

        rudder_tip_forward = (rudder_base - (0.60 * math.cos(rudder_angle)))

        rudder_tip_sideways = 0.60 * math.sin(rudder_angle)

        rudder_start = boat_detail_point(boat, camera, rudder_base, 0)

        rudder_tip = boat_detail_point(boat, camera, rudder_tip_forward, rudder_tip_sideways)

        pygame.draw.line(screen, (228, 171, 52), rudder_start, rudder_tip, 2)


    # -------------------------------------------------------------------------
    # COLLISION BOX
    # -------------------------------------------------------------------------
    if control_state is not None and camera.show_collision_box:
        draw_boat_collision_box(screen, boat, camera, control_state)


    # -------------------------------------------------------------------------
    # OVERVIEW BOAT MARKER
    # -------------------------------------------------------------------------
    if camera.show_overview:
        marker = world_to_screen(boat.x, boat.y, camera)

        front = world_to_screen(boat.x + math.cos(boat.heading) * 12 / max(0.2, zoom),
                                boat.y + math.sin(boat.heading) * 12 / max(0.2, zoom), camera)
        heading_dx = front[0] - marker[0]
        heading_dy = front[1] - marker[1]
        length = max(1.0, math.hypot(heading_dx, heading_dy))
        nx, ny = -heading_dy / length, heading_dx / length
        arrow_points = [front,
                        (marker[0] - heading_dx * 0.48 + nx * 5, marker[1] - heading_dy * 0.48 + ny * 5),
                        (marker[0] - heading_dx * 0.48 - nx * 5, marker[1] - heading_dy * 0.48 - ny * 5)]
        pygame.draw.polygon(screen, (246, 248, 242), arrow_points)
        pygame.draw.lines(screen, (23, 62, 118), True, arrow_points, 2)


