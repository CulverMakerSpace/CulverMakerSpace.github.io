"""Pygame-only scenery for the overhead Coxswain Simulator.

Purely visual: uses the same course geometry as the physics engine but never
mutates it. Generated graphics are reused instead of recomputed every frame.
Compatible with desktop Pygame and Pygbag (no external assets or libraries).
"""

import math
import random
from pathlib import Path

import pygame

from source_data.courses import registry as course
from source_data.visual_geometry import consolidate_visual_bridges, smooth_visual_shoreline
import settings


# =============================================================================
# COLORS AND DRAWING CONSTANTS
# =============================================================================
WATER_BASE = (55, 125, 160)
LAND_BASE = (87, 114, 81)
CITY_GROUND = (111, 119, 115)
SHORE_LIGHT = (178, 215, 202)
SHORE_SAND = (181, 187, 148)
DOCK_TOP = (119, 106, 91)
DOCK_SHADOW = (53, 64, 67)
ART_ASSETS = Path(__file__).resolve().parent / "assets"

WATER_TEXTURE_ALPHA = 92
LAND_TEXTURE_ALPHA = 80
CITY_TEXTURE_ALPHA = 72
DOCK_TEXTURE_ALPHA = 88


# =============================================================================
# LIGHTWEIGHT GEOMETRY
# =============================================================================
def soften_polygon(vertices):
    """Build the same safe, visual-only shoreline used by Godot."""
    return smooth_visual_shoreline(vertices)



def simplify_closed_polygon(points, tolerance):
    """Reduce redundant visual vertices without altering source geometry.

    This is applied once per course at a few zoom levels. Splitting the closed
    ring into two arcs avoids the degenerate start/end case of a closed line.
    """
    if len(points) < 12 or tolerance <= 0.0:
        return list(points)

    def simplify_line(line):
        if len(line) < 3:
            return list(line)

        start = line[0]
        end = line[-1]
        delta_x = end[0] - start[0]
        delta_y = end[1] - start[1]
        length_squared = delta_x * delta_x + delta_y * delta_y
        largest_distance = -1.0
        split_index = 0

        for index in range(1, len(line) - 1):
            point = line[index]
            if length_squared < 1e-12:
                distance = math.dist(point, start)
            else:
                t = max(0.0, min(1.0, ((point[0] - start[0]) * delta_x +
                                             (point[1] - start[1]) * delta_y) / length_squared))
                nearest = (start[0] + delta_x * t, start[1] + delta_y * t)
                distance = math.dist(point, nearest)

            if distance > largest_distance:
                largest_distance = distance
                split_index = index

        if largest_distance <= tolerance:
            return [start, end]

        return simplify_line(line[:split_index + 1])[:-1] + simplify_line(line[split_index:])

    split_index = max(range(1, len(points)), key=lambda index: math.dist(points[0], points[index]))
    first_arc = simplify_line(points[:split_index + 1])
    second_arc = simplify_line(points[split_index:] + points[:1])
    simplified = first_arc[:-1] + second_arc[:-1]
    return simplified if len(simplified) >= 3 else list(points)


# A lower-detail shoreline is used only where the screen cannot resolve the
# additional vertices. All simulation and shoreline-collision data are intact.
SHORELINE_DETAIL_LEVELS = (0.08, 0.12, 0.16, 0.4, 1.2, 3.0, 6.0)


def polygon_from_centerline(path, half_width):
    """Create a continuous dock polygon with mitered corners, not rectangles."""
    if len(path) < 2:
        return []
    left = []
    right = []
    for index, point in enumerate(path):
        if index == 0:
            direction = (path[1][0] - point[0], path[1][1] - point[1])
            length = math.hypot(*direction)
            if length < 0.0001:
                continue
            normal = (-direction[1] / length, direction[0] / length)
            scale = half_width
        elif index == len(path) - 1:
            direction = (point[0] - path[index - 1][0], point[1] - path[index - 1][1])
            length = math.hypot(*direction)
            if length < 0.0001:
                continue
            normal = (-direction[1] / length, direction[0] / length)
            scale = half_width
        else:
            prev = (point[0] - path[index - 1][0], point[1] - path[index - 1][1])
            following = (path[index + 1][0] - point[0], path[index + 1][1] - point[1])
            first_length = max(0.0001, math.hypot(*prev))
            second_length = max(0.0001, math.hypot(*following))
            prev_normal = (-prev[1] / first_length, prev[0] / first_length)
            next_normal = (-following[1] / second_length, following[0] / second_length)
            combined = (prev_normal[0] + next_normal[0], prev_normal[1] + next_normal[1])
            combined_length = math.hypot(*combined)
            if combined_length < 0.0001:
                normal = next_normal
                scale = half_width
            else:
                normal = (combined[0] / combined_length, combined[1] / combined_length)
                projection = abs(normal[0] * next_normal[0] + normal[1] * next_normal[1])
                scale = min(half_width * 2.0, half_width / max(0.45, projection))
        left.append((point[0] + normal[0] * scale, point[1] + normal[1] * scale))
        right.append((point[0] - normal[0] * scale, point[1] - normal[1] * scale))
    return left + list(reversed(right))


def point_in_polygon(x, y, vertices):
    inside = False
    prev_x, prev_y = vertices[-1]
    for curr_x, curr_y in vertices:
        if ((curr_y > y) != (prev_y > y)) and x < curr_x + (y - curr_y) * (prev_x - curr_x) / (prev_y - curr_y):
            inside = not inside
        prev_x, prev_y = curr_x, curr_y
    return inside


def is_water(x, y, polygons, holes):
    return any(point_in_polygon(x, y, polygon) for polygon in polygons) and not any(
        point_in_polygon(x, y, hole) for hole in holes)


def rectangles_overlap(a, b):
    """Check intersection between (min_x, min_y, max_x, max_y) bounds."""
    return a[0] <= b[2] and a[2] >= b[0] and a[1] <= b[3] and a[3] >= b[1]


def bounding_rectangle(points, margin=0):
    """Screen-space bounds for a polygon with optional outer padding."""
    left = math.floor(min(x for x, _ in points)) - margin
    top = math.floor(min(y for _, y in points)) - margin
    right = math.ceil(max(x for x, _ in points)) + margin
    bottom = math.ceil(max(y for _, y in points)) + margin
    return pygame.Rect(left, top, max(1, right - left + 1), max(1, bottom - top + 1))


def on_screen(center, screen_size, margin=160):
    return -margin <= center[0] <= screen_size[0] + margin and -margin <= center[1] <= screen_size[1] + margin


# =============================================================================
# PROCEDURAL TILES (GENERATED ONCE, NO IMAGE FILES)
# =============================================================================
def make_texture_tiles():
    # Prefer the included pre-rendered high-detail textures. No third-party
    # package is needed at runtime, and no texture generation delays startup.
    try:
        return tuple(pygame.image.load(str(ART_ASSETS / name)).convert_alpha()
                     for name in ("water_surface.png", "grass_surface.png", "city_surface.png"))
    except (FileNotFoundError, pygame.error):
        pass

    rng = random.Random(1944)
    size = 256
    water = pygame.Surface((size, size), pygame.SRCALPHA)
    land = pygame.Surface((size, size), pygame.SRCALPHA)
    city = pygame.Surface((size, size), pygame.SRCALPHA)

    # Broad, very faint patches break up the flat water fill without
    # conspicuous cartoon waves. All marks are created once at startup.
    for _ in range(24):
        x = rng.randrange(size)
        y = rng.randrange(size)
        radius = rng.randrange(12, 45)
        color = (132, 206, 221, rng.randrange(7, 16)) if rng.randrange(2) else (11, 57, 87, rng.randrange(7, 16))
        pygame.draw.ellipse(water, color, (x - radius, y - radius // 3, radius * 2, radius // 2))

    # Fine, translucent ripples with irregular length and brightness.
    for _ in range(145):
        x = rng.randrange(size)
        y = rng.randrange(size)
        width = rng.randrange(5, 31)
        pygame.draw.line(water, (220, 242, 242, rng.randrange(11, 33)), (x, y), (min(size - 1, x + width), y), 1)
    for _ in range(130):
        x = rng.randrange(size)
        y = rng.randrange(size)
        pygame.draw.circle(water, (11, 61, 87, rng.randrange(8, 24)), (x, y), rng.choice((1, 2)))

    # Grass/mottled soil. Small marks read as foliage from normal zoom.
    for _ in range(850):
        x = rng.randrange(size)
        y = rng.randrange(size)
        color = (174, 194, 131, rng.randrange(9, 40)) if rng.randrange(3) else (31, 67, 43, rng.randrange(10, 43))
        pygame.draw.circle(land, color, (x, y), rng.choice((1, 1, 2, 3)))

    # Concrete/city grid mottling, deliberately subdued.
    for _ in range(1000):
        x = rng.randrange(size)
        y = rng.randrange(size)
        color = (230, 226, 206, rng.randrange(5, 23)) if rng.randrange(2) else (35, 50, 57, rng.randrange(5, 24))
        pygame.draw.rect(city, color, (x, y, rng.randrange(1, 4), rng.randrange(1, 4)))
    return water, land, city


def world_texture_angle(camera):
    """Return the image rotation that follows the WORLD, not the boat.

    World +X points right and +Y points up in overview. The follow camera
    keeps the boat's bow up, so the map rotates 90 degrees minus its heading.
    """
    if camera.show_overview:
        return 0.0
    return 90.0 - math.degrees(camera.heading)


def world_tile_centers(view_x, view_y, zoom, screen_size, tile_size):
    """Generate only tile centers needed to cover the visible world region.

    The repeat interval is defined in world meters; the same coordinates are
    used when the camera translates or turns. This is a visual calculation.
    """
    tile_meters = tile_size / max(zoom, 1e-6)
    half_diagonal_meters = math.hypot(*screen_size) * 0.5 / max(zoom, 1e-6)
    radius = half_diagonal_meters + tile_meters
    minimum_x = math.floor((view_x - radius) / tile_meters)
    maximum_x = math.ceil((view_x + radius) / tile_meters)
    minimum_y = math.floor((view_y - radius) / tile_meters)
    maximum_y = math.ceil((view_y + radius) / tile_meters)

    for grid_y in range(minimum_y, maximum_y + 1):
        for grid_x in range(minimum_x, maximum_x + 1):
            yield ((grid_x + 0.5) * tile_meters,
                   (grid_y + 0.5) * tile_meters)


# =============================================================================
# COURSE-SPECIFIC DECORATIONS
# =============================================================================
class PygameScenery:
    def __init__(self):
        self.course_id = None
        self.tiles = None
        self.wood_tile = None
        self.water_polygons = []
        self.land_holes = []
        self.smoothed_water = []
        self.smoothed_holes = []
        self.water_detail_levels = {}
        self.hole_detail_levels = {}
        self.dock_polygons = []
        self.dock_bounds = []
        self.visual_bridges = []
        self.buildings = []
        self.trees = []
        self.roads = []
        self.urban = False
        self.frame_water = None
        self.frame_mask = None
        self.frame_docks = None
        self.frame_dock_shape = None
        self.frame_wood = None
        self.frame_size = None
        # A small LRU avoids rerotating textures on every rendered frame.
        self.rotated_textures = {}
        self.prepared_texture_tiles = {}

    def prepare(self):
        course_id = course.active_course_name
        if self.course_id == course_id:
            return
        self.course_id = course_id
        self.urban = course_id in ("charles", "milwaukee")
        self.water_polygons = list(getattr(course, "WATER_POLYGONS", [course.LAKE_SHORELINE]))
        self.land_holes = list(getattr(course, "LAND_HOLES", []))
        self.smoothed_water = [soften_polygon(p) for p in self.water_polygons]
        self.smoothed_holes = [soften_polygon(p) for p in self.land_holes]
        self.water_detail_levels = {
            tolerance: [simplify_closed_polygon(polygon, tolerance) for polygon in self.smoothed_water]
            for tolerance in SHORELINE_DETAIL_LEVELS
        }
        self.hole_detail_levels = {
            tolerance: [simplify_closed_polygon(polygon, tolerance) for polygon in self.smoothed_holes]
            for tolerance in SHORELINE_DETAIL_LEVELS
        }
        self.dock_polygons = [polygon_from_centerline(path, settings.DOCK_DISPLAY_WIDTH / 2.0)
                              for path in course.DOCK_PATHS]
        self.dock_bounds = [
            (min(x for x, _ in polygon), min(y for _, y in polygon),
             max(x for x, _ in polygon), max(y for _, y in polygon))
            if polygon else None for polygon in self.dock_polygons
        ]
        self.visual_bridges = consolidate_visual_bridges(getattr(course, "BRIDGE_PATHS", []), course.LAKE_SHORELINE)
        self.buildings = []
        self.trees = []
        self.roads = []
        rng = random.Random(2100 + sum(ord(ch) for ch in course_id))

        # Roads/buildings/foliage are decorative and generated on the LAND side
        # of a real shoreline. They are not mapped structures/collision objects.
        for shoreline in self.water_polygons:
            for index, a in enumerate(shoreline):
                b = shoreline[(index + 1) % len(shoreline)]
                dx = b[0] - a[0]
                dy = b[1] - a[1]
                length = math.hypot(dx, dy)
                if length < 5.0:
                    continue
                tangent = (dx / length, dy / length)
                normal = (-tangent[1], tangent[0])
                midpoint = ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)
                if is_water(midpoint[0] + normal[0] * 12, midpoint[1] + normal[1] * 12,
                            self.water_polygons, self.land_holes):
                    normal = (-normal[0], -normal[1])

                if self.urban:
                    road_a = (a[0] + normal[0] * 16, a[1] + normal[1] * 16)
                    road_b = (b[0] + normal[0] * 16, b[1] + normal[1] * 16)
                    self.roads.append((road_a, road_b))

                spacing = 36.0 if self.urban else 58.0
                for sample in range(max(1, math.ceil(length / spacing))):
                    ratio = (sample + 0.5) / max(1, math.ceil(length / spacing))
                    shore_x = a[0] + dx * ratio
                    shore_y = a[1] + dy * ratio
                    distance = rng.uniform(27, 64) if self.urban else rng.uniform(13, 55)
                    center = (shore_x + normal[0] * distance, shore_y + normal[1] * distance)
                    if is_water(*center, self.water_polygons, self.land_holes):
                        continue
                    if self.urban:
                        if rng.random() < 0.11:
                            continue
                        width = rng.uniform(10, 25)
                        depth = rng.uniform(12, 29)
                        corners = []
                        for along, across in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                            corners.append((center[0] + tangent[0] * width * along / 2 + normal[0] * depth * across / 2,
                                            center[1] + tangent[1] * width * along / 2 + normal[1] * depth * across / 2))
                        tone = rng.randrange(4)
                        self.buildings.append((center, corners, tone))
                    else:
                        self.trees.append((center, rng.uniform(3, 7), rng.randrange(3)))
                        if rng.random() < 0.6:
                            second_center = (center[0] + rng.uniform(-8, 8), center[1] + rng.uniform(-8, 8))
                            if not is_water(*second_center, self.water_polygons, self.land_holes):
                                self.trees.append((second_center, rng.uniform(2, 6), rng.randrange(3)))

    def ensure_buffers(self, size):
        if self.tiles is None:
            self.tiles = make_texture_tiles()
            try:
                self.wood_tile = pygame.image.load(str(ART_ASSETS / "wood_surface.png")).convert_alpha()
            except (FileNotFoundError, pygame.error):
                self.wood_tile = None
        if self.frame_size != size:
            self.frame_water = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_mask = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_docks = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_dock_shape = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_wood = pygame.Surface(size, pygame.SRCALPHA)
            self.frame_size = size

    def rotated_world_tile(self, tile, ground_color, tile_size, angle, texture_alpha):
        """Reuse prepared materials when the camera heading changes.

        Rescaling, transparency compositing and wrapping are done only once
        per material and zoom. Rotation results have their own bounded cache.
        """
        angle = round(angle * 2.0) / 2.0
        material_key = (id(tile), ground_color, tile_size, texture_alpha)
        rotation_key = (material_key, angle)
        cached = self.rotated_textures.get(rotation_key)
        if cached is not None:
            return cached

        material = self.prepared_texture_tiles.get(material_key)
        if material is None:
            base = pygame.Surface((tile_size, tile_size), pygame.SRCALPHA)
            base.fill((*ground_color, 255))

            if tile.get_size() == (tile_size, tile_size):
                textured = tile.copy()
            else:
                textured = pygame.transform.smoothscale(tile, (tile_size, tile_size))
            textured.set_alpha(texture_alpha)
            base.blit(textured, (0, 0))

            padding = 6
            material = pygame.Surface((tile_size + 2 * padding, tile_size + 2 * padding), pygame.SRCALPHA)
            for offset_y in (-tile_size, 0, tile_size):
                for offset_x in (-tile_size, 0, tile_size):
                    material.blit(base, (padding + offset_x, padding + offset_y))

            self.prepared_texture_tiles[material_key] = material
            if len(self.prepared_texture_tiles) > 6:
                old_key = next(iter(self.prepared_texture_tiles))
                self.prepared_texture_tiles.pop(old_key)

        rotated = pygame.transform.rotate(material, angle)
        self.rotated_textures[rotation_key] = rotated
        if len(self.rotated_textures) > 16:
            self.rotated_textures.pop(next(iter(self.rotated_textures)))
        return rotated

    def draw_world_texture(self, destination, texture, ground_color, camera, convert, texture_alpha,
                           clip_rect=None):
        """Draw world-anchored material, optionally restricted to a visible area.

        The texture's world origin, zoom scaling and rotation are unchanged.
        Clipping only avoids unnecessary alpha blending outside visible shapes.
        """
        view_x, view_y, zoom = camera.get_view()
        # Keep overview and very distant zoom levels inexpensive; normal zoom
        # retains the source image's physical scale (5 pixels per meter).
        native_size = round(texture.get_width() * zoom / settings.PIXELS_PER_METER)
        tile_size = max(128, min(760, native_size))
        angle = world_texture_angle(camera)
        rotated = self.rotated_world_tile(texture, ground_color, tile_size, angle, texture_alpha)
        width, height = destination.get_size()
        visible_area = pygame.Rect(0, 0, width, height)
        if clip_rect is not None:
            visible_area = visible_area.clip(clip_rect)
        if visible_area.width == 0 or visible_area.height == 0:
            return

        previous_clip = destination.get_clip()
        destination.set_clip(visible_area)
        try:
            for world_x, world_y in world_tile_centers(view_x, view_y, zoom, (width, height), tile_size):
                position = convert(world_x, world_y, camera)
                tile_rectangle = rotated.get_rect(center=position)
                if tile_rectangle.colliderect(visible_area):
                    destination.blit(rotated, tile_rectangle)
        finally:
            destination.set_clip(previous_clip)

    def draw_ground(self, screen, camera, convert):
        self.prepare()
        self.ensure_buffers(screen.get_size())
        water_texture, land_texture, city_texture = self.tiles
        ground = CITY_GROUND if self.urban else LAND_BASE
        screen.fill(ground)
        # Texture tiles rotate *with the world* as the boat-follow camera turns.
        self.draw_world_texture(screen, city_texture if self.urban else land_texture,
                                ground, camera, convert, CITY_TEXTURE_ALPHA if self.urban else LAND_TEXTURE_ALPHA)

        if self.urban:
            for a, b in self.roads:
                start = convert(*a, camera)
                end = convert(*b, camera)
                if not on_screen(start, screen.get_size(), 300) and not on_screen(end, screen.get_size(), 300):
                    continue
                street_width = max(3, min(52, int(8 * camera.get_view()[2])))
                pygame.draw.line(screen, (86, 94, 95), (start[0] + 1, start[1] + 1),
                                 (end[0] + 1, end[1] + 1), street_width + 3)
                pygame.draw.line(screen, (160, 164, 157), start, end, street_width + 2)
                pygame.draw.line(screen, (98, 103, 104), start, end, street_width)
                if camera.get_view()[2] >= 1.5:
                    pygame.draw.line(screen, (169, 164, 139), start, end, 1)
            for center, corners, tone in self.buildings:
                screen_center = convert(*center, camera)
                if not on_screen(screen_center, screen.get_size()):
                    continue
                poly = [convert(*corner, camera) for corner in corners]
                shadow = [(x + 1, y + 2) for x, y in poly]
                pygame.draw.polygon(screen, (102, 110, 110), shadow)
                roof_colors = [(176, 181, 175), (164, 169, 168), (187, 178, 163), (146, 157, 161)]
                pygame.draw.polygon(screen, roof_colors[tone], poly)
                pygame.draw.lines(screen, (88, 98, 101), True, poly, 1)
                if camera.get_view()[2] >= 2.0:
                    # Parapet, mechanical room and vents give roofs scale,
                    # without introducing thousands of additional sprites.
                    mx = sum(point[0] for point in poly) / len(poly)
                    my = sum(point[1] for point in poly) / len(poly)
                    inset = [(mx + (x - mx) * 0.85, my + (y - my) * 0.85) for x, y in poly]
                    pygame.draw.lines(screen, (199, 197, 190), True, inset, 1)
                    unit_width = max(2, round(camera.get_view()[2] * 1.1))
                    unit = pygame.Rect(int(mx - unit_width), int(my - unit_width), 2 * unit_width, 2 * unit_width)
                    pygame.draw.rect(screen, (97, 109, 109), unit)
                    pygame.draw.rect(screen, (174, 180, 174), unit, 1)
                    if unit_width >= 4:
                        pygame.draw.line(screen, (62, 77, 83), (unit.centerx, unit.top),
                                         (unit.centerx, unit.bottom), 1)
        else:
            for center, radius_m, shade in self.trees:
                screen_center = convert(*center, camera)
                if not on_screen(screen_center, screen.get_size(), 40):
                    continue
                radius = max(1, int(radius_m * camera.get_view()[2]))
                if radius > 70:
                    continue
                # Layered asymmetrical crowns, a soft cast shadow, and a
                # highlight look less like isolated green dots from overhead.
                pygame.draw.circle(screen, (61, 83, 64), (screen_center[0] + 1, screen_center[1] + 2), radius)
                base = [(89, 115, 78), (97, 121, 84), (80, 106, 80)][shade]
                pygame.draw.circle(screen, base, screen_center, radius)
                if radius >= 4:
                    pygame.draw.circle(screen, (92, 126, 71), (screen_center[0] - radius // 3,
                                                             screen_center[1] - radius // 4), max(2, radius * 2 // 3))
                    pygame.draw.circle(screen, (50, 88, 54), (screen_center[0] + radius // 3,
                                                            screen_center[1] + radius // 4), max(2, radius // 2))
                if radius >= 7:
                    pygame.draw.circle(screen, (133, 151, 86), (screen_center[0] - radius // 3,
                                                              screen_center[1] - radius // 3), max(1, radius // 4))

    def shoreline_geometry_for_zoom(self, zoom):
        """Select up to one pixel of shoreline simplification at the current zoom.

        The smallest tolerance supports the maximum user zoom; there is no
        abrupt switch to the full, 1,000+ vertex shoreline above 6.25 px/m.
        """
        allowed_tolerance = 1.0 / max(zoom, 0.01)
        selected = None
        for tolerance in SHORELINE_DETAIL_LEVELS:
            if tolerance <= allowed_tolerance:
                selected = tolerance

        if selected is None:
            return self.smoothed_water, self.smoothed_holes
        return self.water_detail_levels[selected], self.hole_detail_levels[selected]

    # -------------------------------------------------------------------------
    # VISIBLE GEOMETRY
    # -------------------------------------------------------------------------
    @staticmethod
    def visible_world_bounds(camera, screen_size, margin_pixels=0):
        """Conservative world-aligned bounds for either camera orientation."""
        view_x, view_y, zoom = camera.get_view()
        radius = (math.hypot(*screen_size) * 0.5 + margin_pixels) / max(zoom, 1e-6)
        return (view_x - radius, view_y - radius, view_x + radius, view_y + radius)

    @staticmethod
    def visible_water_bounds(polygons, screen_size):
        """Find the screen region occupied by the shoreline's outer polygon."""
        vertices = [point for polygon in polygons for point in polygon]
        if not vertices:
            return None
        bounds = bounding_rectangle(vertices)
        visible_bounds = bounds.clip(pygame.Rect((0, 0), screen_size))
        return visible_bounds if visible_bounds.width and visible_bounds.height else None

    def draw_water(self, screen, camera, convert):
        self.frame_water.fill((0, 0, 0, 0))
        self.frame_mask.fill((0, 0, 0, 0))
        self.frame_docks.fill((0, 0, 0, 0))
        self.frame_dock_shape.fill((0, 0, 0, 0))
        _, _, zoom = camera.get_view()
        water_geometry, hole_geometry = self.shoreline_geometry_for_zoom(zoom)
        water_points = []
        for polygon in water_geometry:
            points = [convert(x, y, camera) for x, y in polygon]
            water_points.append(points)
            if len(points) >= 3:
                pygame.draw.polygon(self.frame_water, (*WATER_BASE, 255), points)
                pygame.draw.polygon(self.frame_mask, (255, 255, 255, 255), points)
        hole_points = []
        for polygon in hole_geometry:
            points = [convert(x, y, camera) for x, y in polygon]
            hole_points.append(points)
            if len(points) >= 3:
                pygame.draw.polygon(self.frame_water, (0, 0, 0, 0), points)
                pygame.draw.polygon(self.frame_mask, (0, 0, 0, 0), points)

        # Texture only the visible water bounds. The material is still
        # world-locked and the original shoreline mask still defines its shape.
        visible_water_bounds = self.visible_water_bounds(water_points, screen.get_size())
        if visible_water_bounds is not None:
            water_texture = self.tiles[0]
            self.draw_world_texture(self.frame_water, water_texture, WATER_BASE, camera, convert,
                                    WATER_TEXTURE_ALPHA, clip_rect=visible_water_bounds)
            water_position = visible_water_bounds.topleft
            self.frame_water.blit(self.frame_mask, water_position, area=visible_water_bounds,
                                  special_flags=pygame.BLEND_RGBA_MULT)
            screen.blit(self.frame_water, water_position, area=visible_water_bounds)

        for points in water_points:
            if len(points) >= 3:
                pygame.draw.lines(screen, (71, 131, 145), True, points, 7)
                pygame.draw.lines(screen, (109, 176, 174), True, points, 4)
                pygame.draw.lines(screen, SHORE_LIGHT, True, points, 2)
        for points in hole_points:
            if len(points) >= 3:
                pygame.draw.polygon(screen, CITY_GROUND if self.urban else LAND_BASE, points)
                pygame.draw.lines(screen, SHORE_SAND, True, points, 2)

    def draw_docks(self, screen, camera, convert):
        _, _, zoom = camera.get_view()
        if not self.dock_polygons:
            return

        # Cull in WORLD coordinates before transforming any dock vertices.
        # At high zoom most of the course is off screen, so this avoids almost
        # all work on distant docks and skips the wood layer completely if none
        # are visible.
        visible_docks = []
        world_bounds = self.visible_world_bounds(camera, screen.get_size(), margin_pixels=120)
        visible_bounds = None
        for polygon, dock_bounds in zip(self.dock_polygons, self.dock_bounds):
            if len(polygon) < 3 or dock_bounds is None or not rectangles_overlap(dock_bounds, world_bounds):
                continue

            screen_points = [convert(x, y, camera) for x, y in polygon]
            screen_bounds = bounding_rectangle(screen_points, margin=2)
            if not screen_bounds.colliderect(screen.get_rect()):
                continue

            visible_docks.append(screen_points)
            visible_bounds = screen_bounds if visible_bounds is None else visible_bounds.union(screen_bounds)

        if not visible_docks:
            return

        visible_bounds = visible_bounds.clip(screen.get_rect())
        dock_position = visible_bounds.topleft

        for screen_points in visible_docks:
            pygame.draw.polygon(self.frame_docks, (*DOCK_TOP, 255), screen_points)
            pygame.draw.polygon(self.frame_dock_shape, (255, 255, 255, 255), screen_points)

        # Cached woodgrain covers the joined polygons and is then masked.
        # Since the outlines are not drawn for each constituent rectangle,
        # intersecting/T-shaped piers remain visually continuous.
        if self.wood_tile is not None:
            self.frame_wood.fill((0, 0, 0, 0), visible_bounds)
            self.draw_world_texture(self.frame_wood, self.wood_tile, DOCK_TOP, camera, convert,
                                    DOCK_TEXTURE_ALPHA, clip_rect=visible_bounds)
            self.frame_wood.blit(self.frame_dock_shape, dock_position, area=visible_bounds,
                                 special_flags=pygame.BLEND_RGBA_MULT)
            self.frame_docks.blit(self.frame_wood, dock_position, area=visible_bounds)

        # All dock shapes are filled before any plank detailing: no outlines
        # between overlapping segments of the same pier or a T-join.
        if zoom > 1.5:
            for path in course.DOCK_PATHS:
                for a, b in zip(path, path[1:]):
                    begin = convert(*a, camera)
                    end = convert(*b, camera)
                    dx = end[0] - begin[0]
                    dy = end[1] - begin[1]
                    length = math.hypot(dx, dy)
                    if length < 8:
                        continue
                    if (max(begin[0], end[0]) < -80 or min(begin[0], end[0]) > screen.get_width() + 80 or
                            max(begin[1], end[1]) < -80 or min(begin[1], end[1]) > screen.get_height() + 80):
                        continue
                    ux = dx / length
                    uy = dy / length
                    nx = -uy
                    ny = ux
                    spacing = max(10.0, 0.85 * zoom)
                    for index in range(1, min(90, int(length / spacing))):
                        amount = index * spacing
                        x = begin[0] + ux * amount
                        y = begin[1] + uy * amount
                        half_width = settings.DOCK_DISPLAY_WIDTH * zoom * 0.36
                        pygame.draw.line(self.frame_docks, (158, 146, 130, 135),
                                         (x - nx * half_width, y - ny * half_width),
                                         (x + nx * half_width, y + ny * half_width), 1)

        self.frame_docks.blit(self.frame_mask, dock_position, area=visible_bounds,
                              special_flags=pygame.BLEND_RGBA_MULT)
        screen.blit(self.frame_docks, dock_position, area=visible_bounds)


    # -------------------------------------------------------------------------
    # SINGLE-SURFACE BRIDGES
    # -------------------------------------------------------------------------
    def draw_bridges(self, screen, camera, convert):
        """Draw one filled, outlined deck for each grouped bridge span."""
        _, _, zoom = camera.get_view()
        for bridge in self.visual_bridges:
            polygon = [convert(x, y, camera) for x, y in bridge["polygon"]]
            if not any(on_screen(point, screen.get_size(), 250) for point in polygon):
                continue

            kind = bridge["kind"]
            if kind == "rail":
                deck_color = (133, 124, 115)
            elif kind == "pedestrian":
                deck_color = (183, 177, 165)
            else:
                deck_color = (151, 156, 151)

            # The bridge is a single deck, not overlapping centerline strokes.
            shadow = [(x + 2, y + 3) for x, y in polygon]
            pygame.draw.polygon(screen, (76, 95, 101), shadow)
            pygame.draw.polygon(screen, deck_color, polygon)
            pygame.draw.lines(screen, (98, 106, 107), True, polygon, max(1, round(zoom * 0.3)))

            if zoom < 1.3:
                continue

            # The two long sides are continuous bridge railings/parapets.
            pygame.draw.line(screen, (205, 202, 192), polygon[0], polygon[1], 1)
            pygame.draw.line(screen, (205, 202, 192), polygon[2], polygon[3], 1)

            if kind == "road":
                start = ((polygon[0][0] + polygon[3][0]) * 0.5,
                         (polygon[0][1] + polygon[3][1]) * 0.5)
                end = ((polygon[1][0] + polygon[2][0]) * 0.5,
                       (polygon[1][1] + polygon[2][1]) * 0.5)
                pygame.draw.line(screen, (207, 199, 176), start, end, 1)


SCENERY = PygameScenery()
