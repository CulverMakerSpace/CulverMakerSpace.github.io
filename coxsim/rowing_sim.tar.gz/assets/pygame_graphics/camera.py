"""Camera projection and drawing of the selected rowing course."""

import math

import pygame

import settings
from source_data.courses import registry as course
from pygame_graphics.scenery import SCENERY


# =============================================================================
# CAMERA
# =============================================================================
class Camera:
    def __init__(self):
        # Start in follow mode using the normal world-to-screen scale.
        self.x = 0.0
        self.y = 0.0
        self.heading = 0.0
        self.heading_cosine = 1.0
        self.heading_sine = 0.0
        self.zoom = settings.PIXELS_PER_METER
        self.show_overview = False
        self.show_collision_box = True


    # =========================================================================
    # FOLLOW BOAT
    # =========================================================================
    def follow(self, boat):
        # Keep the boat centered and store its heading so the follow view can rotate with it.
        self.x = boat.x
        self.y = boat.y
        self.heading = boat.heading
        self.heading_cosine = math.cos(self.heading)
        self.heading_sine = math.sin(self.heading)


    # =========================================================================
    # CHANGE ZOOM
    # =========================================================================
    def change_zoom(self, multiplier):
        # Manual zoom always returns the camera to normal follow mode.
        self.show_overview = False
        self.zoom *= multiplier

        self.zoom = max(settings.CAMERA_MIN_ZOOM, min(settings.CAMERA_MAX_ZOOM, self.zoom))


    # =========================================================================
    # TOGGLE OVERVIEW
    # =========================================================================
    def toggle_overview(self):
        self.show_overview = not self.show_overview


    # =========================================================================
    # GET CURRENT VIEW
    # =========================================================================
    def get_view(self):
        # Normal mode uses the camera position and user-selected zoom.
        if not self.show_overview:
            return self.x, self.y, self.zoom


        # ---------------------------------------------------------------------
        # FULL-LAKE OVERVIEW
        # ---------------------------------------------------------------------
        map_width = course.MAX_X - course.MIN_X
        map_height = course.MAX_Y - course.MIN_Y

        horizontal_zoom = (settings.WINDOW_WIDTH - 140) / map_width
        vertical_zoom = (settings.WINDOW_HEIGHT - 100) / map_height
        overview_zoom = min(horizontal_zoom, vertical_zoom)

        center_x = (course.MIN_X + course.MAX_X) / 2
        center_y = (course.MIN_Y + course.MAX_Y) / 2

        return center_x, center_y, overview_zoom


# =============================================================================
# WORLD TO SCREEN
# =============================================================================
def world_to_screen(x, y, camera):
    # Convert world coordinates into either the rotating follow view or the fixed north-up overview.
    center_x, center_y, zoom = camera.get_view()

    if camera.show_overview:
        screen_x = (settings.WINDOW_WIDTH / 2) + ((x - center_x) * zoom)
        screen_y = (settings.WINDOW_HEIGHT / 2) - ((y - center_y) * zoom)

    else:
        relative_x = x - camera.x
        relative_y = y - camera.y

        heading_cosine = camera.heading_cosine
        heading_sine = camera.heading_sine

        forward = (relative_x * heading_cosine) + (relative_y * heading_sine)
        sideways = (-relative_x * heading_sine) + (relative_y * heading_cosine)

        screen_x = (settings.WINDOW_WIDTH / 2) - (sideways * zoom)
        screen_y = (settings.WINDOW_HEIGHT / 2) - (forward * zoom)

    return int(round(screen_x)), int(round(screen_y))


# =============================================================================
# DRAW COURSE
# =============================================================================
def draw_course(screen, camera):
    # All scenery is visual only; the course module and its collision data
    # remain unchanged. Procedural textures/shorelines are cached per course.
    SCENERY.draw_ground(screen, camera, world_to_screen)
    SCENERY.draw_water(screen, camera, world_to_screen)
    SCENERY.draw_docks(screen, camera, world_to_screen)
    # Bridges are drawn after the boat so the shell passes visually underneath.

    # Course markers and start/finish lines are always legible above scenery.
    _, _, zoom = camera.get_view()
    for marker in getattr(course, "COURSE_MARKERS", []):
        if "point" not in marker:
            continue
        marker_screen = world_to_screen(*marker["point"], camera)
        pygame.draw.circle(screen, marker["color"], marker_screen, max(4, round(1.5 * zoom)))
        pygame.draw.circle(screen, "white", marker_screen, max(4, round(1.5 * zoom)), 1)

    for marker in getattr(course, "COURSE_MARKERS", []):
        if "start" not in marker or "end" not in marker:
            continue
        start = world_to_screen(*marker["start"], camera)
        end = world_to_screen(*marker["end"], camera)
        if marker.get("style") == "checkered":
            length = math.hypot(end[0] - start[0], end[1] - start[1])
            sections = max(2, round(length / 8))
            for section in range(sections):
                ratio_start = section / sections
                ratio_end = (section + 1) / sections
                point_a = (start[0] + (end[0] - start[0]) * ratio_start,
                           start[1] + (end[1] - start[1]) * ratio_start)
                point_b = (start[0] + (end[0] - start[0]) * ratio_end,
                           start[1] + (end[1] - start[1]) * ratio_end)
                color = (255, 255, 255) if section % 2 == 0 else (30, 30, 30)
                pygame.draw.line(screen, color, point_a, point_b, 5)
        else:
            pygame.draw.line(screen, marker["color"], start, end, 3)




# =============================================================================
# BRIDGE OVERPASS LAYER
# =============================================================================
def draw_bridge_overpasses(screen, camera):
    """Draw elevated bridge decks over the boat and wake (visual only)."""
    SCENERY.draw_bridges(screen, camera, world_to_screen)
