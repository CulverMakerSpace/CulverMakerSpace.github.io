"""Fixed-step rendering clock and lightweight position interpolation.

The physics engine still owns all movement. These helpers only control how
Pygame advances that engine and displays snapshots between fixed updates.
"""

import math
from dataclasses import dataclass


# =============================================================================
# FIXED-STEP CLOCK
# =============================================================================
@dataclass
class FrameClock:
    step_seconds: float = 1.0 / 60.0
    maximum_frame_seconds: float = 0.25
    maximum_steps_per_frame: int = 8
    remaining_seconds: float = 0.0

    def advance(self, elapsed_seconds, update_physics):
        """Run bounded fixed updates and return the interpolation fraction.

        Excess time after severe stalls is discarded to avoid a spiral of
        continuously late frames. Ordinary frames conserve their remainder.
        """
        elapsed_seconds = min(max(0.0, elapsed_seconds), self.maximum_frame_seconds)
        self.remaining_seconds += elapsed_seconds

        step_count = 0
        while self.remaining_seconds + 1e-10 >= self.step_seconds and step_count < self.maximum_steps_per_frame:
            update_physics(self.step_seconds)
            self.remaining_seconds -= self.step_seconds
            step_count += 1

        if step_count == self.maximum_steps_per_frame and self.remaining_seconds >= self.step_seconds:
            self.remaining_seconds = math.fmod(self.remaining_seconds, self.step_seconds)

        self.remaining_seconds = max(0.0, self.remaining_seconds)
        return min(1.0, self.remaining_seconds / self.step_seconds), step_count

    def reset(self):
        self.remaining_seconds = 0.0


# =============================================================================
# VISUAL BOAT POSE
# =============================================================================
@dataclass(frozen=True)
class BoatPose:
    x: float
    y: float
    heading: float

    @classmethod
    def capture(cls, boat):
        return cls(boat.x, boat.y, boat.heading)


def interpolate_pose(previous, current, fraction):
    """Interpolate heading along its shortest arc, including across +/- pi."""
    fraction = min(1.0, max(0.0, fraction))
    heading_change = (current.heading - previous.heading + math.pi) % (2.0 * math.pi) - math.pi

    return BoatPose(
        previous.x + (current.x - previous.x) * fraction,
        previous.y + (current.y - previous.y) * fraction,
        previous.heading + heading_change * fraction,
    )
