import math
from collections import deque

import settings


# =============================================================================
# BOAT
# =============================================================================
class Boat:
    def __init__(self):
        # ---------------------------------------------------------------------
        # MASS
        # ---------------------------------------------------------------------
        self.mass = settings.TOTAL_MASS
        self.moment_of_inertia = settings.MOMENT_OF_INERTIA


        # ---------------------------------------------------------------------
        # POSITION
        # ---------------------------------------------------------------------
        self.x = 0.0                    # m
        self.y = 0.0                    # m
        self.heading = 0.0              # rad


        # ---------------------------------------------------------------------
        # VELOCITY
        # ---------------------------------------------------------------------
        self.velocity_x = 0.0           # m/s
        self.velocity_y = 0.0           # m/s
        self.angular_velocity = 0.0     # rad/s


        # ---------------------------------------------------------------------
        # ACCELERATION
        # ---------------------------------------------------------------------
        self.acceleration_x = 0.0       # m/s^2
        self.acceleration_y = 0.0       # m/s^2
        self.angular_acceleration = 0.0 # rad/s^2


        # ---------------------------------------------------------------------
        # FORCE AND TORQUE
        # ---------------------------------------------------------------------
        self.net_force_x = 0.0          # N
        self.net_force_y = 0.0          # N
        self.net_torque = 0.0           # N*m

        self.last_force_x = 0.0         # N
        self.last_force_y = 0.0         # N
        self.last_torque = 0.0          # N*m


        # ---------------------------------------------------------------------
        # SPEED HISTORY
        # ---------------------------------------------------------------------
        self.speed_samples = deque()
        self.speed_history_time = 0.0
        self.speed_history_distance = 0.0


    # =========================================================================
    # APPLY FORCE
    # =========================================================================
    def apply_force(self, force_forward, force_sideways, application_forward=0.0, application_sideways=0.0):

        # ---------------------------------------------------------------------
        # CONVERT BOAT FORCE TO WORLD COORDINATES
        # ---------------------------------------------------------------------
        heading_cosine = math.cos(self.heading)
        heading_sine = math.sin(self.heading)

        force_x = ((force_forward * heading_cosine) - (force_sideways * heading_sine))

        force_y = ((force_forward * heading_sine) + (force_sideways * heading_cosine))


        # ---------------------------------------------------------------------
        # ADD FORCE
        # ---------------------------------------------------------------------
        self.net_force_x += force_x
        self.net_force_y += force_y


        # ---------------------------------------------------------------------
        # ADD TORQUE ABOUT THE CENTER OF MASS
        # ---------------------------------------------------------------------
        torque = ((application_forward * force_sideways) - (application_sideways * force_forward))

        self.net_torque += torque


    # =========================================================================
    # GET SPEED
    # =========================================================================
    def get_speed(self):
        speed = math.sqrt(self.velocity_x**2 + self.velocity_y**2)

        return speed


    # =========================================================================
    # GET VELOCITY COMPONENTS
    # =========================================================================
    def get_velocity_components(self):
        heading_cosine = math.cos(self.heading)
        heading_sine = math.sin(self.heading)

        velocity_forward = ((self.velocity_x * heading_cosine) + (self.velocity_y * heading_sine))

        velocity_sideways = ((-self.velocity_x * heading_sine) + (self.velocity_y * heading_cosine))

        return velocity_forward, velocity_sideways


    # =========================================================================
    # RECORD SPEED HISTORY
    # =========================================================================
    def record_speed_history(self, dt, distance):
        # Store frame-by-frame time and distance for the rolling average.
        if dt <= 0.0:
            return

        self.speed_samples.append((dt, distance))
        self.speed_history_time += dt
        self.speed_history_distance += distance


        # ---------------------------------------------------------------------
        # REMOVE SAMPLES OUTSIDE THE AVERAGING WINDOW
        # ---------------------------------------------------------------------
        # Keep a partial oldest frame when the time boundary falls inside it.
        while self.speed_history_time > settings.SPEED_HISTORY_WINDOW and self.speed_samples:
            excess_time = self.speed_history_time - settings.SPEED_HISTORY_WINDOW
            oldest_dt, oldest_distance = self.speed_samples.popleft()

            if excess_time >= oldest_dt:
                self.speed_history_time -= oldest_dt
                self.speed_history_distance -= oldest_distance

            else:
                remaining_time = oldest_dt - excess_time
                remaining_fraction = remaining_time / oldest_dt
                remaining_distance = oldest_distance * remaining_fraction

                self.speed_samples.appendleft((remaining_time, remaining_distance))
                self.speed_history_time -= excess_time
                self.speed_history_distance -= oldest_distance - remaining_distance


    # =========================================================================
    # GET AVERAGE SPEED
    # =========================================================================
    def get_average_speed(self):
        # Average speed is total distance divided by time in the current window.
        if self.speed_history_time <= 0.0:
            return 0.0

        return self.speed_history_distance / self.speed_history_time


    # =========================================================================
    # UPDATE BOAT STATE
    # =========================================================================
    def update(self, dt):
        # ---------------------------------------------------------------------
        # STORE CURRENT FORCE AND TORQUE FOR THE DEBUG HUD
        # ---------------------------------------------------------------------
        self.last_force_x = self.net_force_x
        self.last_force_y = self.net_force_y
        self.last_torque = self.net_torque


        # ---------------------------------------------------------------------
        # CALCULATE ACCELERATION
        # ---------------------------------------------------------------------
        self.acceleration_x = self.net_force_x / self.mass
        self.acceleration_y = self.net_force_y / self.mass
        self.angular_acceleration = self.net_torque / self.moment_of_inertia


        # ---------------------------------------------------------------------
        # UPDATE ROTATION
        # ---------------------------------------------------------------------
        self.angular_velocity += self.angular_acceleration * dt
        self.heading += self.angular_velocity * dt
        self.heading %= 2 * math.pi


        # ---------------------------------------------------------------------
        # UPDATE VELOCITY
        # ---------------------------------------------------------------------
        self.velocity_x += self.acceleration_x * dt
        self.velocity_y += self.acceleration_y * dt


        # ---------------------------------------------------------------------
        # UPDATE POSITION
        # ---------------------------------------------------------------------
        self.x += self.velocity_x * dt
        self.y += self.velocity_y * dt


        # ---------------------------------------------------------------------
        # RESET FORCE AND TORQUE FOR THE NEXT FRAME
        # ---------------------------------------------------------------------
        self.net_force_x = 0.0
        self.net_force_y = 0.0
        self.net_torque = 0.0
